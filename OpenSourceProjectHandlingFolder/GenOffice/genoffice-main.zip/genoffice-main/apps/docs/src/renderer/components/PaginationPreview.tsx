import { useEffect, useMemo, useState } from 'react'
import type {
  HeaderFooter,
  HfImage,
  HfPartInfo,
  SectionInfo,
  SectionSettings,
} from '@genoffice/docx-engine'
import {
  appendEndnotesBlock,
  appendFloatSpillBlock,
  assignSections,
  effectiveBottomPx,
  effectiveHfRefs,
  effectiveTopPx,
  formatPageNumber,
  liveSections,
  measureBlocks,
  pageNumbers,
  pinnedFloatPage,
  sectionBidi,
  sectionColGeom,
  sectionFirstPages,
  sectionGeoms,
  sectionPageBox,
  sliceWithLineSplit,
  type BlockBox,
  type BlockMetaOf,
  type PageNoteItem,
  type PageSlice,
  type SectionHfHeights,
} from '../pagination'
import { estimateHfHeight, hfHeaderGeom, FOOTNOTE_SEPARATOR_H } from '../line-metrics'
import { toRoman } from '../note-format'
import { useI18n } from '../i18n/locale'
import { hfFloatPagePos } from '../editor/hf-dom'
import { HeaderFooterArea } from './HeaderFooterArea'

const twipsToPx = (twips: number) => (twips / 1440) * 96

/** Snapshot of one top-level canvas block for pruned per-page clones (virtual gapless coordinates, layout px) */
export interface CloneChild {
  html: string
  vTop: number
  vBottom: number
  /** CSS margins (layout px): spacer heights must exclude them to keep flow positions exact */
  mt: number
  mb: number
  /** zero-height marker (hidden bookmarks etc.): always kept, never worth pruning */
  zero: boolean
}

/**
 * Per-page full-document clones cost pages × doc DOM; past this budget (top-level
 * blocks × pages) a 300+-page document OOMs the renderer during preview/export
 * ("Promise was collected"), so pages switch to pruned clones: blocks outside the
 * page window collapse into fixed-height spacers.
 */
const CLONE_PRUNE_BUDGET = 150_000
/** window slack around a page (px): keeps neighbours whose floats/overflow bleed into the page */
const CLONE_PRUNE_PAD = 2000

/**
 * Canvas block → clone HTML. Phantom table rows (page-gap / repeated-header
 * widgets) are removed and rowspans restored to their source values
 * (data-base-rowspan): the canvas grows rowspans to bridge the phantom rows,
 * but the clone hides/drops them, so the grown spans would swallow real rows.
 */
function cloneBlockHtml(el: HTMLElement): string {
  if (!el.querySelector('tr.page-gap, tr.page-repeat-header, [data-base-rowspan]')) {
    return el.outerHTML
  }
  const tmp = el.cloneNode(true) as HTMLElement
  for (const tr of Array.from(tmp.querySelectorAll('tr.page-gap, tr.page-repeat-header'))) {
    tr.remove()
  }
  for (const td of Array.from(tmp.querySelectorAll('[data-base-rowspan]'))) {
    td.setAttribute('rowspan', td.getAttribute('data-base-rowspan')!)
  }
  return tmp.outerHTML
}

/** pruned clone for one page window: blocks intersecting [from-pad, to+pad] verbatim, pruned runs as spacers */
export function prunedCloneHtml(kids: CloneChild[], from: number, to: number): string {
  const lo = from - CLONE_PRUNE_PAD
  const hi = to + CLONE_PRUNE_PAD
  const parts: string[] = []
  let lastKept: CloneChild | null = null
  let pruned = false
  for (const c of kids) {
    if (!c.zero && (c.vBottom <= lo || c.vTop >= hi)) {
      pruned = true
      continue
    }
    if (pruned) {
      // spacer replaces the pruned run; its height re-derives the next block's
      // border-box top from the previous kept block's margin edge (spacers
      // suppress margin collapse, so both adjacent margins apply in full)
      const base = lastKept ? lastKept.vBottom + lastKept.mb : 0
      const h = Math.max(0, c.vTop - c.mt - base)
      parts.push(
        `<div class="pv-prune-spacer" style="margin:0;border:0;padding:0;height:${h}px"></div>`,
      )
      pruned = false
    }
    parts.push(c.html)
    // zero-height markers anchor positions too: skipping them here made every
    // following marker's spacer re-span the full distance from the last real
    // block, inflating the clone flow (blank pages past the drift)
    lastKept = c
  }
  return parts.join('')
}

/**
 * Page-pinned boxes (cover art) ride the full-document clone onto every page at
 * the same page coordinates; only the copy on the owning page (data-pin-page,
 * stamped on the canvas wrapper before cloning) may stay visible. Expressed as
 * CSS rules because React re-assigns each clone's innerHTML on every re-render
 * (the {__html} wrapper is a fresh object), wiping any imperative DOM fixup.
 * visibility (not display): a stray-run wrapper carries flow height the slices
 * were measured with, and hidden ink must not emit glyphs into the PDF layer.
 */
export function pinnedCloneCss(pageCount: number): string {
  const rules: string[] = []
  for (let i = 0; i < pageCount; i++) {
    rules.push(
      `.pv-page[data-pv-page="${i}"] .doc-protected-pagepinned[data-pin-page]:not([data-pin-page="${i}"]){visibility:hidden;}`,
    )
  }
  return rules.join('\n')
}

export interface HfSet {
  header: HeaderFooter | null
  footer: HeaderFooter | null
  headerFirst: HeaderFooter | null
  footerFirst: HeaderFooter | null
  headerEven: HeaderFooter | null
  footerEven: HeaderFooter | null
  titlePg: boolean
  evenOddHf: boolean
  /** images in each variant part (logos etc., display-only) */
  images?: Partial<
    Record<
      'header' | 'footer' | 'headerFirst' | 'footerFirst' | 'headerEven' | 'footerEven',
      HfImage[]
    >
  >
}

/**
 * Pagination preview: a read-only snapshot of real page slicing over the canvas's continuous
 * flow. Each page = a full content clone + overflow clipping + negative-margin offset; the
 * clone is fixed at the canvas content width (line breaks from measurement must not change),
 * and paper size/margins render per each page's section (mixed portrait/landscape across
 * sections is real). Headers/footers render per page by Word variant rules (first page /
 * odd-even), with real page numbers.
 */
export function PaginationPreview({
  section,
  sections,
  delSectBreaks,
  hfParts,
  colFlow,
  colMode,
  zoom,
  hf,
  watermark,
  blockMetaOf,
  pageFootnotesOf,
  endnoteItems,
  sectionHfOverride,
  clearPageGaps,
  onExportPdf,
  onClose,
  suppressEscape,
}: {
  /** Canvas geometry (final section): for the measurement origin / clone width */
  section: SectionSettings
  /** All sections: for per-page paper geometry (empty array = single section per `section`) */
  sections: SectionInfo[]
  /** section-break paragraphs whose mark is a tracked deletion (no break in markup views) */
  delSectBreaks?: Set<number>
  /** rId → header/footer parts (multi-section picks by each section's references) */
  hfParts: Record<string, HfPartInfo>
  /** Canvas column-flow geometry (non-null when the canvas column CSS is active): shared by the measuring state / clone wrap width */
  colFlow: { cols: number; colWidthPx: number; gapPx: number } | null
  /** canvas column mode: 'uniform' = whole-page CSS multicol, 'mixed' = per-block layout decorations */
  colMode: 'none' | 'uniform' | 'mixed'
  zoom: number
  hf: HfSet
  watermark: string | null
  /** docxIndex → parse-layer pagination constraints (keepNext/widow/table-row flags) */
  blockMetaOf?: BlockMetaOf
  /** Per-page footnote collection (referencing page → entry list), for page-bottom rendering */
  pageFootnotesOf?: (blocks: BlockBox[], slices: PageSlice[]) => PageNoteItem[][]
  /** Endnote entries (placed together at the document end, take part in slicing, may continue across pages) */
  endnoteItems?: PageNoteItem[]
  /** Multi-section: unsaved per-section header/footer edit overrides (default variant) */
  sectionHfOverride?: (sectionIndex: number, kind: 'header' | 'footer') => HeaderFooter | null
  /**
   * Clears the canvas page-gap decorations before the snapshot measure. In-table
   * gap/repeated-header widgets are extra <tr>s that consume rowspan slots, so a
   * vMerge-heavy table measures with collapsed columns (exploding row heights)
   * while they are present; the canvas rebuilds them on its next debounced
   * remeasure after the snapshot.
   */
  clearPageGaps?: () => void
  onExportPdf: () => void
  onClose: () => void
  /** While true (e.g. the print dialog is stacked on top), Escape must not close the preview */
  suppressEscape?: boolean
}) {
  const { t } = useI18n()
  const [slices, setSlices] = useState<PageSlice[]>([])
  const [pageNotes, setPageNotes] = useState<PageNoteItem[][]>([])
  /** Top Y of the endnote area (virtual coordinates); null = no endnotes */
  const [endnotesTop, setEndnotesTop] = useState<number | null>(null)
  const [html, setHtml] = useState('')
  /** non-null = pruned-clone mode (large documents): per-page windows instead of full clones */
  const [cloneKids, setCloneKids] = useState<CloneChild[] | null>(null)
  /** Live section list: a section whose break block was deleted (unsaved) merges into the next, matching the canvas */
  const [secs, setSecs] = useState<SectionInfo[]>(sections)

  const canvasContentW = twipsToPx(section.pageWidth - section.marginLeft - section.marginRight)
  // canvas content-area top = effective top margin after header push-down (matches --page-pad)
  const canvasMTop = effectiveTopPx(
    section,
    estimateHfHeight(hf.header, canvasContentW, hf.images?.header, hfHeaderGeom(section)),
  )
  /** Settings of the page's section (single-section documents fall back to the canvas geometry) */
  const settingsOf = (slice: PageSlice): SectionSettings =>
    secs[Math.min(slice.section, secs.length - 1)]?.settings ?? section
  /** Clone wrap width = the section's measurement width (columned canvas = column width);
   *  differing-width sections wrap at their own content width (per-block width decorations ride the clone) */
  const wrapWOf = (sectionIdx: number): number =>
    colFlow?.colWidthPx ??
    sectionPageBox(secs[Math.min(sectionIdx, Math.max(secs.length - 1, 0))]?.settings ?? section)
      .contentWidth

  useEffect(() => {
    const pm = document.querySelector('.editor-scroll .ProseMirror') as HTMLElement | null
    if (!pm) return
    clearPageGaps?.()
    const factor = zoom / 100
    // switch the columned canvas to the single-flow measuring state (uniform: CSS columns
    // off, width = column width; mixed: block translates off), matching engine column-flow
    // coordinates. vAlign documents carry the same visual translates on the canvas
    // (vAlignShiftSpecs) and the preview applies its own vOffset, so they must be
    // neutralized here too or the shifted rects double-apply.
    const measureNeutralize =
      colMode !== 'none' ||
      section.vAlign === 'center' ||
      section.vAlign === 'bottom' ||
      sections.some((s) => s.settings.vAlign === 'center' || s.settings.vAlign === 'bottom')
    if (measureNeutralize) pm.classList.add('measuring-columns')
    try {
      const origin = pm.getBoundingClientRect().top + canvasMTop * factor
      const { blocks, totalHeight, floats, sectBreaks } = measureBlocks(pm, origin, factor)
      const live = liveSections(sections, blocks, sectBreaks, delSectBreaks)
      setSecs(live)
      if (live.length > 0) assignSections(blocks, live)
      const withEndnotes = appendEndnotesBlock(
        blocks,
        totalHeight,
        endnoteItems ?? [],
        FOOTNOTE_SEPARATOR_H,
      )
      // floating boxes below the flow end still need pages to land on; bottom-
      // margin overhang stays on the page (same allowance as the canvas)
      const lastSec = live.length > 0 ? live[live.length - 1].settings : section
      const flowWithFloats = appendFloatSpillBlock(
        blocks,
        withEndnotes?.totalHeight ?? totalHeight,
        floats,
        lastSec ? twipsToPx(lastSec.marginBottom) : 0,
      )
      const flowH = flowWithFloats ?? withEndnotes?.totalHeight ?? totalHeight
      setEndnotesTop(withEndnotes?.top ?? null)
      let computed: PageSlice[]
      if (live.length > 0) {
        // each section's default-variant header/footer estimated heights → body push-down (matching the canvas)
        const refs = effectiveHfRefs(live)
        const hfHs: SectionHfHeights[] = live.map((s, i) => {
          const set = s.settings
          const w = twipsToPx(set.pageWidth - set.marginLeft - set.marginRight)
          const pick = (kind: 'header' | 'footer'): HeaderFooter | null => {
            if (i === live.length - 1) return kind === 'header' ? hf.header : hf.footer
            const ov = sectionHfOverride?.(i, kind)
            if (ov) return ov
            const rId = refs[i]?.[kind]?.default
            const part = rId ? hfParts[rId] : undefined
            return part
              ? { text: part.text, pageNumber: part.hasPageNumber, paras: part.paras }
              : null
          }
          const imagesOf = (kind: 'header' | 'footer') => {
            const rId = refs[i]?.[kind]?.default
            const fromPart = rId ? hfParts[rId]?.images : undefined
            if (fromPart?.length) return fromPart
            return i === live.length - 1 ? hf.images?.[kind] : undefined
          }
          return {
            headerPx: estimateHfHeight(pick('header'), w, imagesOf('header'), hfHeaderGeom(set)),
            footerPx: estimateHfHeight(pick('footer'), w, imagesOf('footer')),
          }
        })
        const geoms = sectionGeoms(live, hfHs)
        // when the canvas column layout is inactive, measure as full-width single flow; the geometry drops column flow to match
        if (colMode === 'none') for (const g of geoms) if (g.cols) g.cols = undefined
        computed = sliceWithLineSplit(blocks, geoms, flowH, factor, blockMetaOf)
      } else {
        const contentH =
          twipsToPx(section.pageHeight) -
          effectiveTopPx(
            section,
            estimateHfHeight(hf.header, canvasContentW, hf.images?.header, hfHeaderGeom(section)),
          ) -
          effectiveBottomPx(section, estimateHfHeight(hf.footer, canvasContentW, hf.images?.footer))
        computed = sliceWithLineSplit(
          blocks,
          [
            {
              contentHeight: contentH,
              forceBreak: false,
              ...(colFlow ? { cols: colFlow.cols } : {}),
            },
          ],
          flowH,
          factor,
          blockMetaOf,
        )
      }
      // stamp each page-pinned box's owning page on its canvas wrapper before
      // cloning so the per-page CSS rules can hide the copies on other pages
      for (const f of floats) {
        if (!f.pinned) continue
        const wrap = f.el.closest<HTMLElement>('.doc-protected-pagepinned')
        if (wrap) wrap.dataset.pinPage = String(pinnedFloatPage(computed, f.anchorTop))
      }
      setSlices(computed)
      setPageNotes(pageFootnotesOf ? pageFootnotesOf(blocks, computed) : [])
      // Per-page full clones explode on large documents (pages × doc DOM →
      // renderer OOM / "Promise was collected" during printToPDF). Past the
      // budget, snapshot per-block geometry and render pruned windows instead.
      const kidEls = Array.from(pm.children) as HTMLElement[]
      if (computed.length * kidEls.length >= CLONE_PRUNE_BUDGET) {
        const metas: CloneChild[] = []
        let gapAccum = 0
        for (const el of kidEls) {
          const rect = el.getBoundingClientRect()
          if (el.classList.contains('page-gap') || el.classList.contains('page-float-host')) {
            gapAccum += rect.height
            continue
          }
          let innerGap = 0
          for (const g of el.querySelectorAll('.page-gap-inline'))
            innerGap += g.getBoundingClientRect().height
          const cs = window.getComputedStyle(el)
          const vTop = (rect.top - origin - gapAccum) / factor
          const h = (rect.height - innerGap) / factor
          gapAccum += innerGap
          metas.push({
            html: cloneBlockHtml(el),
            vTop,
            vBottom: vTop + h,
            mt: parseFloat(cs.marginTop) || 0,
            mb: parseFloat(cs.marginBottom) || 0,
            zero: rect.height <= 0,
          })
        }
        setCloneKids(metas)
        setHtml('')
      } else {
        setCloneKids(null)
        setHtml(Array.from(pm.children, (c) => cloneBlockHtml(c as HTMLElement)).join(''))
      }
    } finally {
      if (measureNeutralize) pm.classList.remove('measuring-columns')
    }
    // snapshot: measure once on open; deps intentionally empty
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    // stopPropagation cannot shield this window-level listener from the print
    // dialog's own Escape handler (same target, same phase), so the dialog
    // suppresses it via prop while it is stacked on top
    if (suppressEscape) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onClose()
      }
    }
    window.addEventListener('keydown', onKey, true)
    return () => window.removeEventListener('keydown', onKey, true)
  }, [onClose, suppressEscape])

  const multiSection = secs.length > 1
  const effRefs = useMemo(() => effectiveHfRefs(secs), [secs])
  // single-section also uses pageNumbers: pgNumType w:start renumbering applies to single-section documents too
  const nums = useMemo(
    () => (secs.length > 0 ? pageNumbers(slices, secs) : slices.map((_, i) => i + 1)),
    [slices, secs],
  )
  const firsts = useMemo(() => sectionFirstPages(slices), [slices])

  // line positions of endnote entries in virtual coordinates (matching appendEndnotesBlock's line boxes)
  const endnoteRows = useMemo(() => {
    if (endnotesTop === null || !endnoteItems || endnoteItems.length === 0) return []
    let off = endnotesTop
    return endnoteItems.map((item, i) => {
      const height = (i === 0 ? FOOTNOTE_SEPARATOR_H : 0) + item.height
      const row = { item, top: off, height, withSeparator: i === 0 }
      off += height
      return row
    })
  }, [endnotesTop, endnoteItems])

  const toHf = (rId: string | undefined): HeaderFooter | null => {
    const part = rId ? hfParts[rId] : undefined
    if (!part) return null
    return {
      text: part.text,
      pageNumber: part.hasPageNumber,
      paras: part.paras.length > 0 ? part.paras : undefined,
    }
  }

  /** Single section: reuse the editing state (unsaved header edits are visible); multi-section: pick parts by each section's references */
  const hfFor = (
    i: number,
  ): {
    header: HeaderFooter | null
    footer: HeaderFooter | null
    headerImages?: HfImage[]
    footerImages?: HfImage[]
  } => {
    const pageNo = nums[i]
    if (!multiSection) {
      if (hf.titlePg && i === 0) {
        return {
          header: hf.headerFirst,
          footer: hf.footerFirst,
          headerImages: hf.images?.headerFirst,
          footerImages: hf.images?.footerFirst,
        }
      }
      if (hf.evenOddHf && pageNo % 2 === 0) {
        return {
          header: hf.headerEven,
          footer: hf.footerEven,
          headerImages: hf.images?.headerEven,
          footerImages: hf.images?.footerEven,
        }
      }
      return {
        header: hf.header,
        footer: hf.footer,
        headerImages: hf.images?.header,
        footerImages: hf.images?.footer,
      }
    }
    const slice = slices[i]
    const sec = secs[Math.min(slice.section, secs.length - 1)]
    const refs = effRefs[Math.min(slice.section, effRefs.length - 1)]
    const variant =
      sec.titlePg && firsts[i] ? 'first' : hf.evenOddHf && pageNo % 2 === 0 ? 'even' : 'default'
    // unsaved per-section header/footer edits take priority over document parts (default variant)
    const ovHeader = variant === 'default' ? sectionHfOverride?.(slice.section, 'header') : null
    const ovFooter = variant === 'default' ? sectionHfOverride?.(slice.section, 'footer') : null
    const headerRId = refs.header[variant]
    const footerRId = refs.footer[variant]
    return {
      header: ovHeader ?? toHf(headerRId),
      footer: ovFooter ?? toHf(footerRId),
      headerImages: headerRId ? hfParts[headerRId]?.images : undefined,
      footerImages: footerRId ? hfParts[footerRId]?.images : undefined,
    }
  }

  return (
    <div className="pagination-preview">
      <div className="pv-toolbar">
        <span className="pv-title">{t('appPaginationPreview')}</span>
        <span className="pv-count">{t('appTotalPagesN', { n: slices.length })}</span>
        <span className="pv-hint">{t('appPvHint')}</span>
        <button className="pv-close" data-tip={t('appPvExportTip')} onClick={onExportPdf}>
          {t('appExportPdf')}
        </button>
        <button className="pv-close" onClick={onClose}>
          {t('appClose')}
        </button>
      </div>
      <style>{pinnedCloneCss(slices.length)}</style>
      <div className="pv-scroll">
        {slices.map((slice, i) => {
          const parts = hfFor(i)
          const s = settingsOf(slice)
          const pageBox = sectionPageBox(s)
          const pageW = pageBox.width
          const pageH = pageBox.height
          const secContentW = pageBox.contentWidth
          // effective margins after this page's variant header/footer push-down (an over-tall header pushes the body down)
          const mTop = effectiveTopPx(
            s,
            estimateHfHeight(parts.header, secContentW, parts.headerImages, hfHeaderGeom(s)),
          )
          const mBottom = effectiveBottomPx(
            s,
            estimateHfHeight(parts.footer, secContentW, parts.footerImages),
          )
          const contentH = pageH - mTop - mBottom
          // page vertical alignment (sectPr w:vAlign): content of non-full pages shifts down as a whole
          const usedH = Math.min(slice.end - slice.start, contentH)
          const vSpare = Math.max(0, contentH - usedH)
          const vOffset = s.vAlign === 'center' ? vSpare / 2 : s.vAlign === 'bottom' ? vSpare : 0
          // page numbers display in the owning section's number format (w:pgNumType w:fmt)
          const pageNoText = formatPageNumber(
            nums[i],
            secs[Math.min(slice.section, secs.length - 1)]?.pageNumberFmt,
          )
          return (
            <div
              key={i}
              className="pv-page"
              data-pv-page={i}
              style={
                {
                  width: pageW,
                  height: pageH,
                  '--pv-page-h': `${pageH}px`,
                  '--page-w': `${pageW}px`,
                  '--page-h': `${pageH}px`,
                  '--section-content-w': `${secContentW}px`,
                  '--header-dist': `${pageBox.headerDist}px`,
                  '--footer-dist': `${pageBox.footerDist}px`,
                  '--pv-mr': `${twipsToPx(s.marginRight)}px`,
                  '--pv-ml': `${twipsToPx(s.marginLeft)}px`,
                  padding: `${mTop}px ${twipsToPx(s.marginRight)}px ${mBottom}px ${twipsToPx(s.marginLeft)}px`,
                } as React.CSSProperties
              }
            >
              {watermark && (
                <div className="page-watermark" aria-hidden="true">
                  {watermark}
                </div>
              )}
              {(parts.headerImages ?? [])
                .filter((img) => img.floating)
                .map((img, k) => {
                  // picture watermark (anchored image in the header): drawn once
                  // per page behind the body (negative z-index; .pv-page isolates)
                  const pos = hfFloatPagePos(img, {
                    pageW,
                    pageH,
                    marginLeft: twipsToPx(s.marginLeft),
                    marginRight: twipsToPx(s.marginRight),
                    marginTop: mTop,
                    marginBottom: mBottom,
                    headerDist: pageBox.headerDist,
                    sectMarginTop: twipsToPx(s.marginTop),
                  })
                  return (
                    <img
                      key={`wm${k}`}
                      className="pv-watermark-img"
                      src={img.dataUrl}
                      alt=""
                      aria-hidden="true"
                      style={{
                        left: pos.x,
                        top: pos.y,
                        transform: `translate(${pos.translateX}%, ${pos.translateY}%)`,
                        ...(img.widthPx ? { width: img.widthPx } : {}),
                        ...(img.heightPx ? { height: img.heightPx } : {}),
                        ...(img.washout ? { filter: 'brightness(1.6) contrast(0.35)' } : {}),
                      }}
                    />
                  )
                })}
              {parts.header && (
                <HeaderFooterArea
                  kind="header"
                  value={parts.header}
                  images={parts.headerImages?.filter((img) => !img.floating)}
                  readOnly
                  onCommit={() => {}}
                  pageNo={pageNoText}
                  pageTotal={slices.length}
                />
              )}
              {slice.repeatHeader && !slice.regions && (
                // tblHeader repeated headers: a broken table's page first renders a clone of the source table's header rows
                // (the engine already reserved repeatHeader.height on this page)
                <div className="pv-clip" style={{ height: slice.repeatHeader.height }}>
                  <div
                    className="pv-offset"
                    style={{ marginTop: -slice.repeatHeader.top, width: wrapWOf(slice.section) }}
                  >
                    <div
                      className="doc-page pv-content"
                      dangerouslySetInnerHTML={{
                        __html: cloneKids
                          ? prunedCloneHtml(
                              cloneKids,
                              slice.repeatHeader.top,
                              slice.repeatHeader.top + slice.repeatHeader.height,
                            )
                          : html,
                      }}
                    />
                  </div>
                </div>
              )}
              {slice.regions ? (
                // column flow: regions stack vertically; within a region, columns are narrow-clipped side by side (column-leading repeated headers follow their column)
                slice.regions.map((region, ri) => {
                  const rSec = secs[Math.min(region.section, secs.length - 1)]
                  const rg = rSec
                    ? sectionColGeom(rSec)
                    : (colFlow ?? { cols: 1, colWidthPx: canvasContentW, gapPx: 0 })
                  const extent =
                    ri + 1 < slice.regions!.length
                      ? slice.regions![ri + 1].top - region.top
                      : undefined
                  const multi = rg.cols > 1
                  const rtl = multi && rSec != null && sectionBidi(rSec)
                  const geo = rg as Partial<{ widths: number[]; gaps: number[] }> & typeof rg
                  // per-column width/gap (w:equalWidth="0" lists differ per column);
                  // gaps ride the columns as margins so unequal spaces work too
                  const widthOf = (ci: number) =>
                    multi ? (geo.widths?.[ci] ?? rg.colWidthPx) : undefined
                  const gapAfter = (ci: number) =>
                    multi && ci < region.columns.length - 1 ? (geo.gaps?.[ci] ?? rg.gapPx) : 0
                  return (
                    <div
                      key={ri}
                      className="pv-region"
                      style={{
                        ...(extent !== undefined ? { height: extent } : {}),
                        // RTL section (w:bidi): columns fill right-to-left
                        ...(rtl ? { flexDirection: 'row-reverse' as const } : {}),
                      }}
                    >
                      {region.columns.map((col, ci) => (
                        <div
                          key={ci}
                          className="pv-col"
                          style={{
                            width: widthOf(ci),
                            ...(rtl ? { marginLeft: gapAfter(ci) } : { marginRight: gapAfter(ci) }),
                          }}
                        >
                          {col.repeatHeader && (
                            <div className="pv-clip" style={{ height: col.repeatHeader.height }}>
                              <div
                                className="pv-offset"
                                style={{
                                  marginTop: -col.repeatHeader.top,
                                  width: wrapWOf(region.section),
                                }}
                              >
                                <div
                                  className="doc-page pv-content"
                                  dangerouslySetInnerHTML={{
                                    __html: cloneKids
                                      ? prunedCloneHtml(
                                          cloneKids,
                                          col.repeatHeader.top,
                                          col.repeatHeader.top + col.repeatHeader.height,
                                        )
                                      : html,
                                  }}
                                />
                              </div>
                            </div>
                          )}
                          <div
                            className="pv-clip"
                            style={{
                              height: Math.min(
                                col.end - col.start,
                                region.height - (col.repeatHeader?.height ?? 0),
                              ),
                            }}
                          >
                            <div
                              className="pv-offset"
                              style={{ marginTop: -col.start, width: wrapWOf(region.section) }}
                            >
                              <div
                                className="doc-page pv-content"
                                dangerouslySetInnerHTML={{
                                  __html: cloneKids
                                    ? prunedCloneHtml(cloneKids, col.start, col.end)
                                    : html,
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                })
              ) : (
                <div
                  className="pv-clip"
                  style={{
                    // last page opens to full capacity: slice bounds can drift a few
                    // lines short of the clone's real height (page-crossing tables),
                    // silently dropping the document tail from export/print;
                    // past the real content bottom the window is empty anyway
                    height:
                      i === slices.length - 1 && vOffset <= 0.5
                        ? contentH - (slice.repeatHeader?.height ?? 0)
                        : Math.min(
                            slice.end - slice.start,
                            contentH - (slice.repeatHeader?.height ?? 0),
                          ),
                    ...(vOffset > 0.5 ? { marginTop: vOffset } : {}),
                  }}
                >
                  {/* the offset lives on a separate wrapper: print rules zero out .doc-page's margin;
                      width is fixed to the section's wrap width so the clone never reflows against the paper */}
                  <div
                    className="pv-offset"
                    style={{ marginTop: -slice.start, width: wrapWOf(slice.section) }}
                  >
                    <div
                      className="doc-page pv-content"
                      dangerouslySetInnerHTML={{
                        __html: cloneKids
                          ? prunedCloneHtml(
                              cloneKids,
                              slice.start,
                              // last page opens its clip to full capacity; the window must cover it
                              i === slices.length - 1 ? slice.start + contentH : slice.end,
                            )
                          : html,
                      }}
                    />
                  </div>
                </div>
              )}
              {(pageNotes[i]?.length ?? 0) > 0 && (
                // page-bottom footnotes (Word behavior: placed at the bottom of the page's content area, separator on top)
                <div
                  className="pv-footnotes"
                  style={{
                    left: twipsToPx(s.marginLeft),
                    width: pageW - twipsToPx(s.marginLeft) - twipsToPx(s.marginRight),
                    bottom: twipsToPx(s.marginBottom),
                    height:
                      pageNotes[i]!.reduce((sum, n) => sum + n.height, 0) + FOOTNOTE_SEPARATOR_H,
                  }}
                >
                  {pageNotes[i]!.map((n) => (
                    // entries get fixed heights from the estimates, strictly matching the engine's reservation
                    <div key={n.id} className="pv-footnote" style={{ height: n.height }}>
                      <sup>{n.no}</sup>
                      {n.richParas
                        ? n.richParas.map((para, pi) => (
                            <span key={pi}>
                              {pi > 0 && <br />}
                              {para.map((run, ri) => (
                                <span
                                  key={ri}
                                  style={{
                                    fontWeight: run.bold ? 600 : undefined,
                                    fontStyle: run.italic ? 'italic' : undefined,
                                    textDecoration:
                                      [run.underline && 'underline', run.strike && 'line-through']
                                        .filter(Boolean)
                                        .join(' ') || undefined,
                                    color: run.color ? `#${run.color}` : undefined,
                                    fontSize: run.sizeHalfPoints
                                      ? `${run.sizeHalfPoints / 2}pt`
                                      : undefined,
                                    textTransform: run.caps === 'all' ? 'uppercase' : undefined,
                                    fontVariantCaps:
                                      run.caps === 'small' ? 'small-caps' : undefined,
                                  }}
                                >
                                  {run.text}
                                </span>
                              ))}
                            </span>
                          ))
                        : n.text}
                    </div>
                  ))}
                </div>
              )}
              {(() => {
                // endnotes: immediately after the body's end, placed on pages per the slices, may continue across pages
                const rows = endnoteRows.filter(
                  (r) => r.top >= slice.start - 0.5 && r.top < slice.end - 0.5,
                )
                if (rows.length === 0) return null
                return (
                  <div
                    className={`pv-endnotes${rows[0].withSeparator ? ' with-separator' : ''}`}
                    style={{
                      left: twipsToPx(s.marginLeft),
                      width: pageW - twipsToPx(s.marginLeft) - twipsToPx(s.marginRight),
                      top: mTop + (slice.repeatHeader?.height ?? 0) + (rows[0].top - slice.start),
                    }}
                  >
                    {rows.map(({ item: n, height, withSeparator }) => (
                      <div key={n.id} className="pv-footnote" style={{ height }}>
                        {withSeparator && <div className="pv-endnote-separator" />}
                        <sup>{toRoman(n.no)}</sup>
                        {n.richParas
                          ? n.richParas.map((para, pi) => (
                              <span key={pi}>
                                {pi > 0 && <br />}
                                {para.map((run, ri) => (
                                  <span
                                    key={ri}
                                    style={{
                                      fontWeight: run.bold ? 600 : undefined,
                                      fontStyle: run.italic ? 'italic' : undefined,
                                      textDecoration:
                                        [run.underline && 'underline', run.strike && 'line-through']
                                          .filter(Boolean)
                                          .join(' ') || undefined,
                                      color: run.color ? `#${run.color}` : undefined,
                                      fontSize: run.sizeHalfPoints
                                        ? `${run.sizeHalfPoints / 2}pt`
                                        : undefined,
                                      textTransform: run.caps === 'all' ? 'uppercase' : undefined,
                                      fontVariantCaps:
                                        run.caps === 'small' ? 'small-caps' : undefined,
                                    }}
                                  >
                                    {run.text}
                                  </span>
                                ))}
                              </span>
                            ))
                          : n.text}
                      </div>
                    ))}
                  </div>
                )
              })()}
              {parts.footer && (
                <HeaderFooterArea
                  kind="footer"
                  value={parts.footer}
                  images={parts.footerImages?.filter((img) => !img.floating)}
                  readOnly
                  onCommit={() => {}}
                  pageNo={pageNoText}
                  pageTotal={slices.length}
                />
              )}
              <div className="pv-pageno">{i + 1}</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

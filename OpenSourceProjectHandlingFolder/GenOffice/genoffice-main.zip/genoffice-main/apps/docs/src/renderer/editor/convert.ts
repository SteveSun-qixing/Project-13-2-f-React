import {
  mergePPrFormat,
  setPPrChange,
  stripPPrChange,
  ommlToLatex,
  patchFieldParagraphXml,
  applyImageWrap,
  applyImageZOrder,
  patchImageParagraphXml,
  patchMathTokens,
  patchTableCellTexts,
  type CellTextsPatch,
  patchDrawingExtent,
  patchTextboxSizes,
  patchShapeStyles,
  type ShapeStylePatch,
  type TextboxSizePatch,
  patchTextboxParas,
  generateTableModelXml,
  type Block,
  type CellBorder,
  type ChartDisplay,
  type ChartPatch,
  type ChartSeriesPatch,
  type FieldDisplay,
  type FieldTextPatch,
  type FormulaDisplay,
  type GeneratedBlock,
  type ImageWrap,
  type NewChart,
  type NewImage,
  type ParaFormat,
  type Run,
  type SaveBlock,
  type SdtShell,
  type SectionInfo,
  type TableCell,
  type TableModel,
  type TableParagraph,
  type TextboxDisplay,
  type TextboxParaPatch,
  type TextboxParasPatchSet,
} from '@genoffice/docx-engine'
import { t } from '../i18n/locale'
import { charScaleEm, maxWordWidthPx, textHasComplexScript } from '../line-metrics'
import { firstStrongDir } from './direction'
import { inlineMathML } from './equation'
import { isStraightLineKind } from './shape-svg'

/** minimal ProseMirror JSON shapes */
export interface PmMark {
  type: string
  attrs?: Record<string, unknown>
}
export interface PmNode {
  type: string
  attrs?: Record<string, unknown>
  content?: PmNode[]
  text?: string
  marks?: PmMark[]
}

// ---- Block[] -> ProseMirror doc ----

export function blocksToPmDoc(blocks: Block[], sections?: SectionInfo[]): PmNode {
  const content: PmNode[] = []
  for (const block of blocks) {
    if (block.hidden) continue
    content.push(
      blockToPmNode(
        block,
        sectionRowCapTwips(sections, block.docxIndex),
        sectionWidthBudget(sections, block.docxIndex),
      ),
    )
  }
  if (content.length === 0) {
    content.push({
      type: 'docParagraph',
      attrs: { docxIndex: null, styleId: null, aiChanged: false },
    })
  }
  return { type: 'doc', content }
}

/** Word lays out RTL-script / run-rtl paragraphs with an RTL base direction even
 * without w:bidi (HTML-converted docs omit it). The first strong character wins
 * (dir=auto semantics); run w:rtl only decides weak-only text. Render-only: never
 * written back, and never subject to the explicit-bidi jc left/right swap. */
export function inferredBidi(format: ParaFormat | undefined, runs: Run[] | undefined): boolean {
  if (format?.bidi || !runs?.length) return false
  const strong = firstStrongDir(runs.map((r) => r.text).join(''))
  if (strong) return strong === 'rtl'
  return runs.some((r) => r.rtl)
}

function formatAttrs(format: ParaFormat | undefined, runs?: Run[]): Record<string, unknown> {
  return {
    align: format?.align ?? null,
    lineSpacing: format?.lineSpacing ?? null,
    lineRule: format?.lineRule ?? null,
    lineRawTwips: format?.lineRawTwips ?? null,
    indentLeft: format?.indentLeft ?? null,
    indentRight: format?.indentRight ?? null,
    indentFirstLine: format?.indentFirstLine ?? null,
    spaceBefore: format?.spaceBefore ?? null,
    spaceAfter: format?.spaceAfter ?? null,
    spaceBeforeAuto: format?.spaceBeforeAuto ?? null,
    spaceAfterAuto: format?.spaceAfterAuto ?? null,
    contextualSpacing: format?.contextualSpacing ?? null,
    pageBreakBefore: format?.pageBreakBefore ?? false,
    shadingFill: format?.shadingFill ?? null,
    borders: format?.borders ?? null,
    borderLines: format?.borderLines ? JSON.stringify(format.borderLines) : null,
    tabStops: format?.tabStops ? JSON.stringify(format.tabStops) : null,
    dropCap: format?.dropCap ? JSON.stringify(format.dropCap) : null,
    bidi: format?.bidi ?? false,
    bidiInferred: inferredBidi(format, runs),
    autoSpace: format?.autoSpace ?? null,
    snapToGrid: format?.snapToGrid ?? null,
    emptyRunSize: format?.emptyRunSizeHalfPoints ?? null,
    emptyRunFont: format?.emptyRunFontFamily ?? null,
  }
}

/** Effective row-height ceiling: one page of section content (Word truncates taller rows within the page) */
function sectionRowCapTwips(
  sections: SectionInfo[] | undefined,
  docxIndex: number | null,
): number | null {
  if (!sections?.length || docxIndex == null) return null
  const sec =
    sections.find((s) => docxIndex >= s.firstBlockIndex && docxIndex <= s.lastBlockIndex) ??
    sections[sections.length - 1]
  const cap = sec.settings.pageHeight - sec.settings.marginTop - sec.settings.marginBottom
  return cap > 0 ? cap : null
}

/** table width budget: Word fixed layout lets over-wide tables overflow the
 * text column — left-aligned ones spill right up to the paper edge (avail =
 * left page margin to the paper's right edge), centered ones spill both
 * margins symmetrically (paper = full page width, the hard compression cap);
 * fit = text column width, the target autofit growth is reclaimed back to */
export interface TableWidthBudget {
  avail: number
  fit: number
  paper: number
}
function sectionWidthBudget(
  sections: SectionInfo[] | undefined,
  docxIndex: number | null,
): TableWidthBudget | null {
  if (!sections?.length || docxIndex == null) return null
  const sec =
    sections.find((s) => docxIndex >= s.firstBlockIndex && docxIndex <= s.lastBlockIndex) ??
    sections[sections.length - 1]
  const paper = sec.settings.pageWidth
  const avail = paper - sec.settings.marginLeft
  if (avail <= 0) return null
  const fit = avail - sec.settings.marginRight
  return { avail, fit: fit > 0 ? fit : avail, paper }
}

/** centered tables spill both margins, so their growth bound is the paper width */
function budgetAvail(model: TableModel, budget: TableWidthBudget): number {
  return model.align === 'center' ? budget.paper : budget.avail
}

/** Cap declared row heights (incl. nested tables); returns the input model when nothing exceeds the cap */
export function capTableRowHeights(model: TableModel, capTwips: number): TableModel {
  let changed = false
  const rowHeightsTwips = model.rowHeightsTwips?.map((h) => {
    if (h != null && h > capTwips) {
      changed = true
      return capTwips
    }
    return h
  })
  const rows = model.rows.map((row) =>
    row.map((cell) => {
      if (!cell.nestedTables?.length) return cell
      const nested = cell.nestedTables.map((nt) => capTableRowHeights(nt, capTwips))
      if (nested.every((nt, i) => nt === cell.nestedTables![i])) return cell
      changed = true
      return { ...cell, nestedTables: nested }
    }),
  )
  return changed ? { ...model, rows, rowHeightsTwips } : model
}

const DEFAULT_CELL_MAR = 108
/** render-side column floor (24px, see tableModelToPmNode) */
const MIN_COL_TWIPS = 360

function tableIndentTwips(model: TableModel): number {
  return model.align !== 'center' && model.align !== 'right' && (model.indentTwips ?? 0) > 0
    ? model.indentTwips!
    : 0
}

/** nested tables are bounded by their cell's content width (grid slice minus
 * side padding); without a usable grid the outer budget still bounds them */
function mapNestedTables(
  model: TableModel,
  widths: number[] | undefined,
  budget: number,
  transform: (nt: TableModel, availTwips: number) => TableModel,
): { rows: TableModel['rows']; changed: boolean } {
  let changed = false
  const rows = model.rows.map((row) => {
    let column = 0
    let cellChanged = false
    const cells = row.map((cell) => {
      const start = column
      const span = cell.colSpan ?? 1
      column += span
      if (!cell.nestedTables?.length) return cell
      const cols = widths?.slice(start, start + span) ?? []
      const mar = cell.cellMarTwips ?? model.cellMarTwips
      const pad = (mar?.left ?? DEFAULT_CELL_MAR) + (mar?.right ?? DEFAULT_CELL_MAR)
      const cellWidth = cols.length === span ? cols.reduce((a, b) => a + b, 0) - pad : budget
      if (cellWidth <= 0) return cell
      const nested = cell.nestedTables.map((nt) => transform(nt, cellWidth))
      if (nested.every((nt, i) => nt === cell.nestedTables![i])) return cell
      cellChanged = true
      return { ...cell, nestedTables: nested }
    })
    if (!cellChanged) return row
    changed = true
    return cells
  })
  return { rows, changed }
}

function withColWidths(
  model: TableModel,
  rows: TableModel['rows'],
  widths: number[] | undefined,
): TableModel {
  if (!widths) return { ...model, rows }
  const total = widths.reduce((a, b) => a + b, 0)
  return {
    ...model,
    rows,
    colWidthsTwips: widths,
    ...(total > 0 ? { colWidthsPct: widths.map((w) => (w / total) * 100) } : {}),
  }
}

/**
 * Last-resort display clamp for grids wider than the hard cap (the paper width
 * for top-level tables, the cell content width for nested ones — Word lets
 * over-wide tables spill into the page margins, clipped at the paper, so
 * merely exceeding the text column must not narrow columns and wrap their
 * text onto extra lines). The cut comes proportionally out of the surplus
 * over each column's min-content, so a garbage gridCol absorbs it while real
 * columns keep their words unbroken. Fixed table layout grows past
 * width/max-width to the sum of absolute column widths, so an unclamped
 * garbage gridCol pushes content megapixels off page. Display-only like
 * capTableRowHeights: untouched tables still save their original bytes, and
 * structural rebuilds already regenerate the grid from these display widths
 * (same as user column resizes, which are clamped too).
 */
export function clampTableColWidths(model: TableModel, capTwips: number): TableModel {
  const budget = capTwips - tableIndentTwips(model)
  let widths = model.colWidthsTwips
  let widthsChanged = false
  if (widths && budget > 0 && widths.reduce((a, b) => a + b, 0) > budget) {
    const mins = minContentColTwips(model, widths.length).map((m, i) =>
      Math.min(Math.max(m, MIN_COL_TWIPS), budget, widths![i]),
    )
    const overflow = widths.reduce((a, b) => a + b, 0) - budget
    const surplus = widths.map((w, i) => w - mins[i])
    const totalSurplus = surplus.reduce((a, b) => a + b, 0)
    if (totalSurplus > 0) {
      const take = Math.min(overflow, totalSurplus)
      widths = widths.map((w, i) => w - Math.round((surplus[i] / totalSurplus) * take))
    }
    // min-contents alone can exceed the cap: compress proportionally
    const sum = widths.reduce((a, b) => a + b, 0)
    if (sum > budget) {
      const scale = budget / sum
      widths = widths.map((w) => Math.max(1, Math.round(w * scale)))
    }
    widthsChanged = true
  }
  const { rows, changed: rowsChanged } = mapNestedTables(model, widths, budget, clampTableColWidths)
  if (!widthsChanged && !rowsChanged) return model
  return withColWidths(model, rows, widthsChanged ? widths : undefined)
}

/**
 * Browser fallback faces run wider than the 0.52em heuristic average (Arial /
 * Helvetica digits and most lowercase advance 0.556em, +7%); an under-floored
 * column re-shatters the very word the floor exists for (RFP sample: two-digit
 * row numbers broke one digit per line; Word grants that column ~11% over the
 * estimate).
 */
const MIN_CONTENT_SLACK = 1.08

/** per grid column (twips): widest unbreakable word in single-span cells, plus side padding */
function minContentColTwips(model: TableModel, colCount: number): number[] {
  const mins = new Array<number>(colCount).fill(0)
  for (const row of model.rows) {
    let column = 0
    for (const cell of row) {
      const start = column
      column += cell.colSpan ?? 1
      if ((cell.colSpan ?? 1) !== 1 || start >= colCount) continue
      // merged-away and vertical-text cells don't demand word width
      if (cell.vMerge === 'continue' || cell.textDirection) continue
      const wordPx = cellMaxWordPx(cell)
      if (wordPx <= 0) continue
      const mar = cell.cellMarTwips ?? model.cellMarTwips
      const pad = (mar?.left ?? DEFAULT_CELL_MAR) + (mar?.right ?? DEFAULT_CELL_MAR)
      mins[start] = Math.max(mins[start], Math.ceil(wordPx * MIN_CONTENT_SLACK * 15) + pad)
    }
  }
  return mins
}

/** paragraph indent inside a cell eats line width like the word itself does;
 * list fallbacks mirror the .doc-li per-level CSS defaults (0.55in + 0.3in/level) */
function paraIndentPx(para: TableParagraph): number {
  const leftTw = para.indentLeft ?? (para.list ? 792 + 432 * (para.list.ilvl || 0) : 0)
  const firstTw = Math.max(para.indentFirstLine ?? 0, 0)
  return Math.max(leftTw + firstTw, 0) / 15
}

function cellMaxWordPx(cell: TableCell): number {
  let max = 0
  if (cell.richParas?.length) {
    for (const para of cell.richParas) {
      const runs: Parameters<typeof maxWordWidthPx>[0] = []
      for (const r of para.runs) {
        if (!r.text) continue
        runs.push({
          text: r.text,
          ...(r.font ? { fontFamily: r.font } : {}),
          ...(r.sizeHalfPoints ? { sizeHalfPoints: r.sizeHalfPoints } : {}),
          ...(r.bold ? { bold: true } : {}),
          ...(r.italic ? { italic: true } : {}),
        })
      }
      if (!runs.length) continue
      max = Math.max(max, maxWordWidthPx(runs) + paraIndentPx(para))
    }
  } else {
    for (const text of cell.paras) {
      if (!text) continue
      max = Math.max(max, maxWordWidthPx([{ text, ...(cell.bold ? { bold: true } : {}) }]))
    }
  }
  return max
}

/**
 * Word autofit (tblW auto/absent, no fixed tblLayout): a column grows to its
 * min-content — the widest unbreakable word — so narrow declared widths don't
 * shatter words char by char (heuristic estimate, see maxWordWidthPx). Growth
 * past the fit width (or the declared total, if that was already wider) is
 * reclaimed proportionally from columns with surplus over their own
 * min-content; any remainder spills and is bounded by clampTableColWidths.
 * Display-only, like the clamp.
 */
export function expandAutofitColWidths(
  model: TableModel,
  availTwips: number,
  fitTwips: number = availTwips,
): TableModel {
  const indent = tableIndentTwips(model)
  const budget = availTwips - indent
  let widths = model.colWidthsTwips
  let widthsChanged = false
  // pct-width autofit tables: the min-content floor applies to the resolved
  // widths (Word never wraps below the widest word even when w:tblW is a tiny
  // percentage); growth converts the table to absolute widths for display.
  // pct resolves against the full text column — the render path draws
  // width:N% of the content box and applies the indent as a margin
  let resolvedPct = false
  if (model.autoLayout && model.widthPct && model.colWidthsPct?.length && budget > 0) {
    const tableW = (Math.min(fitTwips, availTwips) * model.widthPct) / 100
    if (tableW > 0) {
      widths = model.colWidthsPct.map((p) => Math.round((p / 100) * tableW))
      resolvedPct = true
    }
  }
  if (model.autoLayout && (resolvedPct || !model.widthPct) && widths?.length && budget > 0) {
    const mins = minContentColTwips(model, widths.length).map((m) => Math.min(m, budget))
    if (mins.some((m, i) => m > widths![i])) {
      const declared = widths.reduce((a, b) => a + b, 0)
      const grown = widths.map((w, i) => Math.max(w, mins[i]))
      const target = Math.max(Math.min(fitTwips, availTwips) - indent, declared)
      const overflow = grown.reduce((a, b) => a + b, 0) - target
      if (overflow > 0) {
        const floors = grown.map((w, i) => Math.max(mins[i], Math.min(w, MIN_COL_TWIPS)))
        const surplus = grown.map((w, i) => Math.max(0, w - floors[i]))
        const totalSurplus = surplus.reduce((a, b) => a + b, 0)
        if (totalSurplus > 0) {
          const take = Math.min(overflow, totalSurplus)
          for (let i = 0; i < grown.length; i++)
            grown[i] -= Math.round((surplus[i] / totalSurplus) * take)
        }
        // min-contents alone can exceed the budget (one huge unbreakable
        // token): compress proportionally like Word instead of handing the
        // excess to clampTableColWidths, which zeroes trailing columns
        const sum = grown.reduce((a, b) => a + b, 0)
        if (sum > target) {
          const scale = target / sum
          for (let i = 0; i < grown.length; i++)
            grown[i] = Math.max(1, Math.round(grown[i] * scale))
        }
      }
      widths = grown
      widthsChanged = true
    }
  }
  const { rows, changed: rowsChanged } = mapNestedTables(
    model,
    widths,
    budget,
    expandAutofitColWidths,
  )
  if (!widthsChanged && !rowsChanged) return model
  const result = withColWidths(model, rows, widthsChanged ? widths : undefined)
  if (widthsChanged && resolvedPct) delete result.widthPct
  return result
}

function displayTable(
  table: TableModel | null,
  rowCapTwips: number | null,
  budget: TableWidthBudget | null,
): TableModel | null {
  if (!table) return null
  let t = table
  if (rowCapTwips != null) t = capTableRowHeights(t, rowCapTwips)
  if (budget != null) {
    t = expandAutofitColWidths(t, budgetAvail(t, budget), budget.fit)
    t = clampTableColWidths(t, budget.paper)
  }
  return t
}

function blockToPmNode(
  block: Block,
  rowCapTwips: number | null = null,
  budget: TableWidthBudget | null = null,
): PmNode {
  switch (block.type) {
    case 'heading':
      return {
        type: 'docHeading',
        attrs: {
          docxIndex: block.docxIndex,
          styleId: block.styleId ?? null,
          aiChanged: false,
          level: block.level ?? 1,
          bookmarks: block.bookmarks ?? null,
          hiddenBookmarks: block.hiddenBookmarks ?? null,
          commentStarts: block.commentStarts ?? null,
          commentEnds: block.commentEnds ?? null,
          pPrChange: block.pPrChangeInfo ? JSON.stringify(block.pPrChangeInfo) : null,
          paraMarkDel: block.paraMarkDel ? JSON.stringify(block.paraMarkDel) : null,
          blockRevision: block.blockRevision ?? null,
          ...formatAttrs(block.format, block.runs),
        },
        content: runsToInline(block.runs ?? []),
      }
    case 'listItem':
      return {
        type: 'docListItem',
        attrs: {
          docxIndex: block.docxIndex,
          styleId: block.styleId ?? null,
          aiChanged: false,
          kind: block.list?.kind ?? 'bullet',
          numId: block.list?.numId ?? null,
          ilvl: block.list?.ilvl ?? 0,
          bookmarks: block.bookmarks ?? null,
          hiddenBookmarks: block.hiddenBookmarks ?? null,
          commentStarts: block.commentStarts ?? null,
          commentEnds: block.commentEnds ?? null,
          pPrChange: block.pPrChangeInfo ? JSON.stringify(block.pPrChangeInfo) : null,
          paraMarkDel: block.paraMarkDel ? JSON.stringify(block.paraMarkDel) : null,
          blockRevision: block.blockRevision ?? null,
          ...formatAttrs(block.format, block.runs),
        },
        content: runsToInline(block.runs ?? []),
      }
    case 'paragraph':
      return {
        type: 'docParagraph',
        attrs: {
          docxIndex: block.docxIndex,
          styleId: block.styleId ?? null,
          aiChanged: false,
          bookmarks: block.bookmarks ?? null,
          hiddenBookmarks: block.hiddenBookmarks ?? null,
          commentStarts: block.commentStarts ?? null,
          commentEnds: block.commentEnds ?? null,
          sdtShell: block.sdtShell ? JSON.stringify(block.sdtShell) : null,
          moveRevision: block.moveRevision ?? null,
          pPrChange: block.pPrChangeInfo ? JSON.stringify(block.pPrChangeInfo) : null,
          paraMarkDel: block.paraMarkDel ? JSON.stringify(block.paraMarkDel) : null,
          blockRevision: block.blockRevision ?? null,
          ...formatAttrs(block.format, block.runs),
        },
        content: runsToInline(block.runs ?? []),
      }
    case 'table': {
      const table = block.table ?? { rows: [[{ paras: [''] }]] }
      const node = tableModelToPmNode(
        table,
        block.docxIndex,
        block.blockRevision ?? null,
        rowCapTwips,
        budget ? budgetAvail(table, budget) : null,
        budget?.fit ?? null,
        budget?.paper ?? null,
      )
      // content-control member tables need the shell for chrome hit-testing
      if (block.sdtShell) node.attrs = { ...node.attrs, sdtShell: JSON.stringify(block.sdtShell) }
      return node
    }
    default:
      // image / passthrough: protected whole-unit blocks
      return {
        type: 'docProtected',
        attrs: {
          docxIndex: block.docxIndex,
          blockRevision: block.blockRevision ?? null,
          blockType: block.type,
          styleId: block.styleId ?? null,
          label: block.label ?? block.type,
          previewText: block.previewText ?? '',
          imageDataUrl: block.imageDataUrl ?? null,
          oleProgId: block.oleProgId ?? null,
          imageWidthPx: block.imageWidthPx ?? null,
          imageHeightPx: block.imageHeightPx ?? null,
          imageCrop: block.imageCrop ?? null,
          imageFillRect: block.imageFillRect ?? null,
          imageLeadingText: block.imageLeadingText ?? null,
          imageLeadingFont: block.imageLeadingFont ?? null,
          imageLeadingExplicitSpaceWidthPx: block.imageLeadingExplicitSpaceWidthPx ?? null,
          imageLeadingImplicitSpaceCount: block.imageLeadingImplicitSpaceCount ?? null,
          imageParagraphIndentLeft: block.imageParagraphIndentLeft ?? null,
          imageParagraphIndentRight: block.imageParagraphIndentRight ?? null,
          imageParagraphIndentFirstLine: block.imageParagraphIndentFirstLine ?? null,
          imageAlign: block.imageAlign ?? null,
          imageWrap: block.imageWrap ?? null,
          imageWrapDistTopEmu: block.imageWrapDistTopEmu ?? null,
          imageWrapDistBottomEmu: block.imageWrapDistBottomEmu ?? null,
          imageWrapDistLeftEmu: block.imageWrapDistLeftEmu ?? null,
          imageWrapDistRightEmu: block.imageWrapDistRightEmu ?? null,
          imageZOrder: block.imageZOrder ?? null,
          imageOffsetXEmu: block.imageOffsetXEmu ?? null,
          imageOffsetYEmu: block.imageOffsetYEmu ?? null,
          imageAnchorLocked: block.imageAnchorLocked ?? false,
          imagePosH: block.imagePosH ?? null,
          imagePosV: block.imagePosV ?? null,
          imageRotDeg: block.imageRotDeg ?? null,
          imageFlipH: block.imageFlipH ?? false,
          imageFlipV: block.imageFlipV ?? false,
          imageBorder: block.imageBorder ?? null,
          table: displayTable(block.table ?? null, rowCapTwips, budget),
          fieldDisplay: block.fieldDisplay ?? null,
          diagramDisplay: block.diagramDisplay ?? null,
          decorative: block.decorative ?? false,
          ruleColorHex: block.ruleColorHex ?? null,
          ruleThicknessPx: block.ruleThicknessPx ?? null,
          ruleWidthPx: block.ruleWidthPx ?? null,
          brokenImage: block.brokenImage ?? false,
          invisibleMarker: block.invisibleMarker ?? false,
          textboxes: block.textboxes ?? null,
          strayRuns: block.strayRuns ?? null,
          strayStyleId: block.strayStyleId ?? null,
          formulaDisplay: block.formulaDisplay ?? null,
          chartDisplay: block.chartDisplay ?? null,
        },
      }
  }
}

function cellRowSpan(model: TableModel, row: number, cell: number, positions: number[][]): number {
  const current = model.rows[row][cell]
  if (current.vMerge !== 'restart') return 1
  const gridColumn = positions[row][cell]
  let span = 1
  for (let r = row + 1; r < model.rows.length; r++) {
    const index = positions[r].indexOf(gridColumn)
    if (index === -1 || model.rows[r][index].vMerge !== 'continue') break
    span++
  }
  return span
}

function cellBorderPx(b: CellBorder | undefined): number {
  if (!b || b.style === 'none' || b.style === 'nil') return 0
  return Math.max(1, Math.round(((b.szEighths ?? 4) / 8 / 72) * 96))
}

/** Inner clip-box height (twips) for cells of hRule="exact" rows — Word clips overflow
 *  instead of growing the row. null = not exact, or the cell spans rows (its clip height
 *  would be the sum of the spanned rows; not handled yet). */
export function cellClipTwips(
  model: TableModel,
  rowIndex: number,
  cell: TableCell,
  rowSpan: number,
): number | null {
  if (rowSpan > 1 || model.rowHeightRules?.[rowIndex] !== 'exact') return null
  const h = model.rowHeightsTwips?.[rowIndex]
  if (!h) return null
  const padTop = cell.cellMarTwips?.top ?? model.cellMarTwips?.top ?? 0
  const padBottom = cell.cellMarTwips?.bottom ?? model.cellMarTwips?.bottom ?? 0
  // collapsed borders straddle the row edges: half of each eats into the row height
  const bTop = cell.borders?.top ?? (rowIndex === 0 ? model.borders?.top : model.borders?.insideH)
  const bBottom =
    cell.borders?.bottom ??
    (rowIndex === model.rows.length - 1 ? model.borders?.bottom : model.borders?.insideH)
  const borderTwips = Math.round(((cellBorderPx(bTop) + cellBorderPx(bBottom)) / 2) * 15)
  return Math.max(0, h - padTop - padBottom - borderTwips)
}

export function tableModelToPmNode(
  model: TableModel,
  docxIndex: number | null = null,
  blockRevision: Block['blockRevision'] | null = null,
  rowCapTwips: number | null = null,
  availTwips: number | null = null,
  fitTwips: number | null = null,
  paperTwips: number | null = null,
): PmNode {
  if (rowCapTwips != null) model = capTableRowHeights(model, rowCapTwips)
  if (availTwips != null) {
    model = expandAutofitColWidths(model, availTwips, fitTwips ?? availTwips)
    model = clampTableColWidths(model, paperTwips ?? availTwips)
  }
  const positions = model.rows.map((row) => {
    let column = 0
    return row.map((cell) => {
      const at = column
      column += cell.colSpan ?? 1
      return at
    })
  })
  // 1 px = 15 twips (96dpi); use real values when absolute grid widths exist, fall back to percentage approximation otherwise
  const widthPx = model.colWidthsTwips
    ? model.colWidthsTwips.map((width) => Math.max(24, Math.round(width / 15)))
    : model.colWidthsPct?.map((width) => Math.max(24, Math.round(width * 6.24)))
  const hasHeaderRow =
    model.rows.length > 1 && model.rows[0].every((cell) => cell.bold || cell.fill !== undefined)
  // w:tblpPr tables taller than any single page cannot float: Word flows/splits
  // them across pages, while the zero-flow-height float model collapses the
  // whole document to one page (137-row glossary, LO batch2 sample 0219).
  // Minimum height = one 12pt line per row; 12960 twips ≈ the shortest common
  // usable page (Letter, 1in margins).
  const minHeightTwips = model.rows.reduce(
    (sum, _row, i) => sum + Math.max(model.rowHeightsTwips?.[i] ?? 0, 240),
    0,
  )
  const tblFloatSource = model.floatSide ?? null
  const tblFloatSuppressed = minHeightTwips > 12960 && tblFloatSource !== null
  const tblFloat = tblFloatSuppressed ? null : tblFloatSource
  const table: PmNode = {
    type: 'docTable',
    attrs: {
      docxIndex,
      blockRevision,
      colWidthsPct: model.colWidthsPct ?? null,
      widthPx:
        !model.widthPct && model.colWidthsTwips && widthPx
          ? widthPx.reduce((sum, width) => sum + width, 0)
          : null,
      widthPct: model.widthPct ?? null,
      cellMar: model.cellMarTwips ?? null,
      cellSpacingTwips: model.cellSpacingTwips ?? null,
      tblFill: model.fill ?? null,
      cellMarEdited: false,
      borders: model.borders ?? null,
      tblAlign: model.align ?? null,
      tblFloat,
      tblFloatSource,
      tblFloatSuppressed,
      tblFloatXTwips: model.floatPos?.xTwips ?? null,
      tblFloatYTwips: model.floatPos?.yTwips ?? null,
      tblFloatHorzAnchor: model.floatPos?.horzAnchor ?? null,
      tblFloatVertAnchor: model.floatPos?.vertAnchor ?? null,
      tblFloatDistance: model.floatPos?.distanceTwips ?? null,
      tblFloatWidthPx:
        tblFloatSource && widthPx ? widthPx.reduce((sum, width) => sum + width, 0) : null,
      tblFloatEdited: false,
      tblAutoFit: model.autoFit ?? (model.autoLayout ? 'contents' : 'fixed'),
      tblAutoFitEdited: false,
      indentTwips: model.indentTwips ?? null,
      tblStyleId: model.tblStyleId ?? null,
      tblLook: model.tableLook ?? null,
      tblLookEdited: false,
      bidiVisual: model.bidiVisual ?? false,
      originalStructure: null,
      originalFormatting: null,
    },
    content: model.rows.map((row, rowIndex) => ({
      type: 'docTableRow',
      attrs: {
        heightTwips: model.rowHeightsTwips?.[rowIndex] ?? null,
        heightRule: model.rowHeightRules?.[rowIndex] ?? null,
        repeatHeader: model.repeatHeaderRows?.[rowIndex] ?? false,
        repeatHeaderEdited: false,
        rawTrPr: model.rawTrPrs?.[rowIndex] ?? null,
        rowRevision: model.rowRevisions?.[rowIndex] ?? null,
      },
      content: row.flatMap((cell, cellIndex) => {
        if (cell.vMerge === 'continue') return []
        const start = positions[rowIndex][cellIndex]
        const colspan = cell.colSpan ?? 1
        const rowspan = cellRowSpan(model, rowIndex, cellIndex, positions)
        return [
          {
            type: hasHeaderRow && rowIndex === 0 ? 'docTableHeader' : 'docTableCell',
            attrs: {
              colspan,
              rowspan,
              clipHeightTwips: cellClipTwips(model, rowIndex, cell, rowspan),
              colwidth: widthPx ? widthPx.slice(start, start + colspan) : null,
              gridGap: cell.gridGap ?? false,
              cellMar: cell.cellMarTwips ?? null,
              textDirection: cell.textDirection ?? null,
              fill: cell.fill ?? null,
              color: cell.color ?? null,
              bold: cell.bold ?? false,
              align: cell.align ?? null,
              vAlign: cell.vAlign ?? null,
              borders: cell.borders ?? null,
              rawTcPr: cell.rawTcPr ?? null,
              cellRevision: cell.cellRevision ?? null,
            },
            content: cellContentNodes(cell),
          },
        ]
      }),
    })),
  }
  table.attrs!.originalStructure = tableStructureSignature(table)
  table.attrs!.originalFormatting = tableFormattingSignature(table)
  return table
}

/** cell paragraphs with nested tables (read-only atoms) spliced in at their anchors */
function cellContentNodes(cell: TableCell): PmNode[] {
  const paraNodes: PmNode[] = (
    cell.richParas?.length
      ? cell.richParas
      : (cell.paras.length > 0 ? cell.paras : ['']).map((text) => ({
          align: cell.align,
          runs: text === '' ? [] : [{ text, bold: cell.bold, color: cell.color }],
        }))
  ).map((paragraph) => {
    const list = 'list' in paragraph ? paragraph.list : undefined
    const styleId = ('styleId' in paragraph ? paragraph.styleId : undefined) ?? null
    return list
      ? {
          type: 'docListItem',
          attrs: {
            ...formatAttrs(paragraph, paragraph.runs),
            styleId,
            kind: list.kind,
            numId: list.numId,
            ilvl: list.ilvl,
          },
          content: runsToInline(paragraph.runs),
        }
      : {
          type: 'docParagraph',
          attrs: { ...formatAttrs(paragraph, paragraph.runs), styleId },
          content: runsToInline(paragraph.runs),
        }
  })
  // fidelity on save comes from the outer table's bytes; reverse insertion keeps anchors valid
  const inserts: Array<{ at: number; node: PmNode }> = []
  const nested = cell.nestedTables ?? []
  for (let i = 0; i < nested.length; i++) {
    inserts.push({
      at: Math.min(cell.nestedTableAnchors?.[i] ?? paraNodes.length, paraNodes.length),
      node: { type: 'docNestedTable', attrs: { model: nested[i] } },
    })
  }
  // anchored shapes/textboxes (display-only): a zero-width float strut before
  // each group's anchor paragraph, so the boxes' positionV offsets resolve from
  // that paragraph like Word and the row grows to max(text, boxes)
  const boxes = cell.anchoredBoxes ?? []
  const boxGroups = new Map<number, TextboxDisplay[]>()
  for (let i = 0; i < boxes.length; i++) {
    const at = Math.min(cell.anchoredBoxAnchors?.[i] ?? 0, paraNodes.length)
    const group = boxGroups.get(at)
    if (group) group.push(boxes[i])
    else boxGroups.set(at, [boxes[i]])
  }
  for (const [at, group] of boxGroups) {
    inserts.push({ at, node: { type: 'docCellBoxes', attrs: { boxes: group } } })
  }
  const content = [...paraNodes]
  inserts.sort((a, b) => a.at - b.at)
  for (let i = inserts.length - 1; i >= 0; i--) {
    content.splice(inserts[i].at, 0, inserts[i].node)
  }
  return content
}

export function tableStructureSignature(table: PmNode): string {
  return JSON.stringify({
    widths: table.attrs?.colWidthsPct ?? null,
    widthPx: table.attrs?.widthPx ?? null,
    widthPct: table.attrs?.widthPct ?? null,
    autoFit: table.attrs?.tblAutoFit ?? null,
    autoFitEdited: table.attrs?.tblAutoFitEdited ?? false,
    cellMar: table.attrs?.cellMar ?? null,
    cellMarEdited: table.attrs?.cellMarEdited ?? false,
    tblStyle: table.attrs?.tblStyleId ?? null,
    tblAlign: table.attrs?.tblAlign ?? null,
    tblFloat: table.attrs?.tblFloat ?? null,
    tblFloatXTwips: table.attrs?.tblFloatXTwips ?? null,
    tblFloatYTwips: table.attrs?.tblFloatYTwips ?? null,
    tblFloatHorzAnchor: table.attrs?.tblFloatHorzAnchor ?? null,
    tblFloatVertAnchor: table.attrs?.tblFloatVertAnchor ?? null,
    tblFloatDistance: table.attrs?.tblFloatDistance ?? null,
    tblFloatEdited: table.attrs?.tblFloatEdited ?? false,
    tblLook: table.attrs?.tblLook ?? null,
    tblLookEdited: table.attrs?.tblLookEdited ?? false,
    rows: (table.content ?? []).map((row) => [
      row.attrs?.heightTwips ?? null,
      row.attrs?.repeatHeader ?? false,
      row.attrs?.repeatHeaderEdited ?? false,
      // accepting/rejecting revisions strips records from trPr/tcPr: include them in the signature to trigger regeneration (works for empty rows too)
      row.attrs?.rawTrPr ?? null,
      row.attrs?.rowRevision ?? null,
      ...(row.content ?? []).map((cell) => [
        cell.type,
        cell.attrs?.colspan ?? 1,
        cell.attrs?.rowspan ?? 1,
        cell.attrs?.colwidth ?? null,
        cell.attrs?.fill ?? null,
        cell.attrs?.color ?? null,
        cell.attrs?.bold ?? false,
        cell.attrs?.align ?? null,
        cell.attrs?.vAlign ?? null,
        cell.attrs?.borders ?? null,
        cell.attrs?.rawTcPr ?? null,
        cell.attrs?.cellRevision ?? null,
      ]),
    ]),
  })
}

function inlineFormattingSignature(content: PmNode[] | undefined): string[] {
  const styles: string[] = []
  for (const node of content ?? []) {
    const style =
      node.type === 'text'
        ? JSON.stringify((node.marks ?? []).map((mark) => [mark.type, mark.attrs ?? null]))
        : node.type
    if (styles[styles.length - 1] !== style) styles.push(style)
  }
  return styles
}

export function tableFormattingSignature(table: PmNode): string {
  return JSON.stringify(
    (table.content ?? []).map((row) =>
      (row.content ?? []).map((cell) =>
        (cell.content ?? []).map((paragraph) => [
          normalizedFormat(nodeFormat(paragraph)),
          // list toggles must force regeneration (the text patch keeps old pPr)
          paragraph.type === 'docListItem'
            ? [paragraph.attrs?.kind, paragraph.attrs?.numId, paragraph.attrs?.ilvl]
            : null,
          inlineFormattingSignature(paragraph.content),
        ]),
      ),
    ),
  )
}

function paragraphText(node: PmNode): string {
  return inlineToRuns(node.content ?? [])
    .map((run) => run.text)
    .join('')
}

function unwrapBlockRevisionXml(xml: string): string {
  const match = /^<w:(ins|del)\b[^>]*>([\s\S]*)<\/w:\1>$/.exec(xml)
  return match ? match[2] : xml
}

/** Convert native table cells back to the physical OOXML-style TableModel grid. */
export function pmTableToModel(table: PmNode): TableModel {
  type ActiveSpan = {
    remaining: number
    span: number
    cell: Omit<TableModel['rows'][number][number], 'paras'>
  }
  let active = new Map<number, ActiveSpan>()
  const rows: TableModel['rows'] = []
  let maximumColumns = 0

  const rowHeightsTwips: Array<number | null> = []
  const rowHeightRules: NonNullable<TableModel['rowHeightRules']> = []
  const repeatHeaderRows: Array<boolean | null> = []
  const rawTrPrs: Array<string | null> = []
  const rowRevisions: TableModel['rowRevisions'] = []
  for (const rowNode of table.content ?? []) {
    rowHeightsTwips.push((rowNode.attrs?.heightTwips as number | null) ?? null)
    rowHeightRules.push(
      (rowNode.attrs?.heightRule as NonNullable<TableModel['rowHeightRules']>[number]) ?? null,
    )
    repeatHeaderRows.push(
      rowNode.attrs?.repeatHeaderEdited || table.attrs?.docxIndex == null
        ? !!rowNode.attrs?.repeatHeader
        : null,
    )
    rawTrPrs.push((rowNode.attrs?.rawTrPr as string | null) ?? null)
    rowRevisions.push(
      (rowNode.attrs?.rowRevision as NonNullable<TableModel['rowRevisions']>[number]) ?? null,
    )
    const entries: Array<{ column: number; cell: TableModel['rows'][number][number] }> = []
    const occupied = new Set<number>()
    for (const [column, span] of active) {
      entries.push({
        column,
        cell: {
          ...span.cell,
          paras: [''],
          colSpan: span.span > 1 ? span.span : undefined,
          vMerge: 'continue',
        },
      })
      for (let i = 0; i < span.span; i++) occupied.add(column + i)
    }

    const added = new Map<number, ActiveSpan>()
    let cursor = 0
    for (const cellNode of rowNode.content ?? []) {
      while (occupied.has(cursor)) cursor++
      const colspan = Math.max(1, Number(cellNode.attrs?.colspan) || 1)
      const rowspan = Math.max(1, Number(cellNode.attrs?.rowspan) || 1)
      const style = {
        fill: (cellNode.attrs?.fill as string | null) ?? undefined,
        color: (cellNode.attrs?.color as string | null) ?? undefined,
        bold: cellNode.attrs?.bold ? true : undefined,
        align: (cellNode.attrs?.align as TableModel['rows'][number][number]['align']) ?? undefined,
        vAlign: (cellNode.attrs?.vAlign as TableCell['vAlign'] | null) ?? undefined,
        borders: (cellNode.attrs?.borders as TableCell['borders'] | null) ?? undefined,
        rawTcPr: (cellNode.attrs?.rawTcPr as string | null) ?? undefined,
        gridGap: cellNode.attrs?.gridGap ? true : undefined,
      }
      const cellParas = (cellNode.content ?? []).filter(
        (n) => n.type === 'docParagraph' || n.type === 'docListItem',
      )
      // nested tables round-trip with the model: text edits use the surgical patch, structural regeneration emits the whole table (nested tables no longer dropped)
      const nestedModels: TableModel[] = []
      const nestedAnchors: number[] = []
      let paraCount = 0
      const cellBoxes: TextboxDisplay[] = []
      const cellBoxAnchors: number[] = []
      for (const n of cellNode.content ?? []) {
        if (n.type === 'docParagraph' || n.type === 'docListItem') paraCount++
        else if (n.type === 'docNestedTable' && n.attrs?.model) {
          nestedModels.push(n.attrs.model as TableModel)
          nestedAnchors.push(paraCount)
        } else if (n.type === 'docCellBoxes' && Array.isArray(n.attrs?.boxes)) {
          for (const box of n.attrs.boxes as TextboxDisplay[]) {
            cellBoxes.push(box)
            cellBoxAnchors.push(paraCount)
          }
        }
      }
      entries.push({
        column: cursor,
        cell: {
          ...style,
          paras: cellParas.map(paragraphText),
          richParas: cellParas.map((paragraph) => ({
            ...nodeFormat(paragraph),
            ...(paragraph.type === 'docListItem' && paragraph.attrs?.numId
              ? {
                  list: {
                    kind: (paragraph.attrs.kind as 'bullet' | 'ordered') ?? 'bullet',
                    numId: String(paragraph.attrs.numId),
                    ilvl: Number(paragraph.attrs.ilvl) || 0,
                  },
                }
              : {}),
            runs: inlineToRuns(paragraph.content ?? []),
          })),
          ...(nestedModels.length > 0
            ? { nestedTables: nestedModels, nestedTableAnchors: nestedAnchors }
            : {}),
          ...(cellBoxes.length > 0
            ? { anchoredBoxes: cellBoxes, anchoredBoxAnchors: cellBoxAnchors }
            : {}),
          colSpan: colspan > 1 ? colspan : undefined,
          vMerge: rowspan > 1 ? 'restart' : undefined,
        },
      })
      if (rowspan > 1) added.set(cursor, { remaining: rowspan - 1, span: colspan, cell: style })
      for (let i = 0; i < colspan; i++) occupied.add(cursor + i)
      cursor += colspan
    }
    maximumColumns = Math.max(maximumColumns, occupied.size)
    rows.push(entries.sort((a, b) => a.column - b.column).map((entry) => entry.cell))

    const next = new Map<number, ActiveSpan>()
    for (const [column, span] of active) {
      if (span.remaining > 1) next.set(column, { ...span, remaining: span.remaining - 1 })
    }
    for (const [column, span] of added) next.set(column, span)
    active = next
  }

  let colWidthsPct = (table.attrs?.colWidthsPct as number[] | null) ?? undefined
  let colWidthsTwips: number[] | undefined
  const firstRow = table.content?.[0]?.content ?? []
  const explicit = firstRow.flatMap((cell) => (cell.attrs?.colwidth as number[] | null) ?? [])
  if (explicit.length === maximumColumns && explicit.every((width) => width > 0)) {
    const total = explicit.reduce((sum, width) => sum + width, 0)
    colWidthsPct = explicit.map((width) => (width / total) * 100)
    colWidthsTwips = explicit.map((width) => Math.round(width * 15))
  } else if (colWidthsPct?.length !== maximumColumns) {
    colWidthsPct = Array.from({ length: maximumColumns }, () => 100 / maximumColumns)
  }
  const tblStyleAttr = table.attrs?.tblStyleId as string | null | undefined
  const isNew = table.attrs?.docxIndex == null
  const tablePropsEdited = (name: string): boolean => isNew || table.attrs?.[name] === true
  const visibleFloat =
    table.attrs?.tblFloat === 'left' || table.attrs?.tblFloat === 'right'
      ? (table.attrs.tblFloat as 'left' | 'right')
      : null
  const suppressedFloat =
    table.attrs?.tblFloatSuppressed &&
    (table.attrs?.tblFloatSource === 'left' || table.attrs?.tblFloatSource === 'right')
      ? (table.attrs.tblFloatSource as 'left' | 'right')
      : null
  const floatSide = visibleFloat ?? suppressedFloat
  const floatPosition =
    floatSide && (table.attrs?.tblFloatXTwips != null || table.attrs?.tblFloatYTwips != null)
      ? {
          xTwips: Number(table.attrs?.tblFloatXTwips) || 0,
          yTwips: Number(table.attrs?.tblFloatYTwips) || 0,
          ...(table.attrs?.tblFloatHorzAnchor
            ? {
                horzAnchor: table.attrs.tblFloatHorzAnchor as NonNullable<
                  TableModel['floatPos']
                >['horzAnchor'],
              }
            : {}),
          ...(table.attrs?.tblFloatVertAnchor
            ? {
                vertAnchor: table.attrs.tblFloatVertAnchor as NonNullable<
                  TableModel['floatPos']
                >['vertAnchor'],
              }
            : {}),
          ...(table.attrs?.tblFloatDistance
            ? {
                distanceTwips: table.attrs.tblFloatDistance as NonNullable<
                  TableModel['floatPos']
                >['distanceTwips'],
              }
            : {}),
        }
      : undefined
  return {
    rows,
    ...(colWidthsPct ? { colWidthsPct } : {}),
    ...(colWidthsTwips ? { colWidthsTwips } : {}),
    ...(table.attrs?.cellSpacingTwips
      ? { cellSpacingTwips: Number(table.attrs.cellSpacingTwips) }
      : {}),
    ...(table.attrs?.tblFill ? { fill: String(table.attrs.tblFill) } : {}),
    ...(rowHeightsTwips.some((h) => h !== null) ? { rowHeightsTwips, rowHeightRules } : {}),
    ...(repeatHeaderRows.some((value) => value !== null) ? { repeatHeaderRows } : {}),
    ...(rawTrPrs.some((r) => r !== null) ? { rawTrPrs } : {}),
    ...(rowRevisions.some((revision) => revision !== null) ? { rowRevisions } : {}),
    // null (cleared) → '' removes explicitly; undefined leaves it alone
    ...(tblStyleAttr !== undefined ? { tblStyleId: tblStyleAttr ?? '' } : {}),
    // explicit only when set ('left' = remove w:jc); null leaves the original
    // tblPr untouched so unmapped w:jc values (e.g. 'start') survive rebuilds
    ...(table.attrs?.tblAlign ? { align: table.attrs.tblAlign as TableModel['align'] } : {}),
    ...(tablePropsEdited('tblAutoFitEdited')
      ? { autoFit: table.attrs?.tblAutoFit as NonNullable<TableModel['autoFit']> }
      : {}),
    ...(tablePropsEdited('cellMarEdited') && table.attrs?.cellMar
      ? { cellMarTwips: table.attrs.cellMar as NonNullable<TableModel['cellMarTwips']> }
      : {}),
    ...(tablePropsEdited('tblFloatEdited')
      ? { floatSide, ...(floatPosition ? { floatPos: floatPosition } : {}) }
      : {}),
    ...(tablePropsEdited('tblLookEdited') && table.attrs?.tblLook
      ? { tableLook: table.attrs.tblLook as NonNullable<TableModel['tableLook']> }
      : {}),
  }
}

export function runsToInline(runs: Run[]): PmNode[] {
  const nodes: PmNode[] = []
  for (const run of runs) {
    if (run.math) {
      nodes.push({
        type: 'docInlineMath',
        attrs: {
          omml: run.math.omml,
          mathml: inlineMathML(run.math.omml),
          // recovered LaTeX makes parsed formulas re-editable; null = atom only
          latex: ommlToLatex(run.math.omml),
          text: run.text,
        },
      })
      continue
    }
    if (run.ruby) {
      nodes.push({
        type: 'docRuby',
        attrs: { base: run.text, rt: run.ruby.rt, xml: run.ruby.xml },
      })
      continue
    }
    if (run.noteRef) {
      nodes.push({
        type: 'docNoteRef',
        attrs: {
          kind: run.noteRef.kind,
          id: run.noteRef.id,
          num: parseInt(run.text, 10) || 1,
        },
      })
      continue
    }
    const marks = runMarks(run)
    // \n = soft line break, \f = in-paragraph page break, \v = column break
    for (const segment of run.text.split(/([\n\f\v])/)) {
      if (segment === '\n') nodes.push({ type: 'hardBreak' })
      else if (segment === '\f') nodes.push({ type: 'hardBreak', attrs: { pageBreak: true } })
      else if (segment === '\v') nodes.push({ type: 'hardBreak', attrs: { colBreak: true } })
      else if (segment !== '') {
        nodes.push({ type: 'text', text: segment, ...(marks.length > 0 ? { marks } : {}) })
      }
    }
    // A run can carry both w:t text and a w:drawing; generate.ts writes the
    // text before the drawing, so emit the image after the text segments
    if (run.image) {
      nodes.push({
        type: 'docInlineImage',
        attrs: {
          dataUrl: run.image.dataUrl,
          widthPx: run.image.widthPx ?? null,
          heightPx: run.image.heightPx ?? null,
          xml: run.image.xml,
          wrap: run.image.wrap ?? null,
          offsetXEmu: run.image.offsetXEmu ?? null,
          offsetYEmu: run.image.offsetYEmu ?? null,
          wrapDistTopEmu: run.image.wrapDistTopEmu ?? null,
          wrapDistBottomEmu: run.image.wrapDistBottomEmu ?? null,
          wrapDistLeftEmu: run.image.wrapDistLeftEmu ?? null,
          wrapDistRightEmu: run.image.wrapDistRightEmu ?? null,
          border: run.image.border ?? null,
          lineCenterV: run.image.lineCenterV ?? false,
        },
      })
    }
    if (run.xeTerm !== undefined) {
      nodes.push({ type: 'docXeMark', attrs: { term: run.xeTerm } })
    }
  }
  return nodes
}

function runMarks(run: Run): PmMark[] {
  const marks: PmMark[] = []
  if (run.bold) marks.push({ type: 'bold' })
  if (run.italic) marks.push({ type: 'italic' })
  if (run.underline) marks.push({ type: 'underline' })
  if (run.strike) marks.push({ type: 'strike' })
  if (run.link)
    marks.push({
      type: 'link',
      attrs: { href: run.link.href, rId: run.link.rId ?? null, tooltip: run.link.tooltip ?? null },
    })
  if (run.refField !== undefined) marks.push({ type: 'refField', attrs: { name: run.refField } })
  if (run.instrField !== undefined)
    marks.push({
      type: 'instrField',
      attrs: { instr: run.instrField, beginXml: run.fldBeginXml ?? null },
    })
  if (run.commentIds?.length)
    marks.push({ type: 'comment', attrs: { ids: run.commentIds.join(' ') } })
  if (run.ins) {
    marks.push({
      type: 'ins',
      attrs: { author: run.ins.author, date: run.ins.date ?? null, id: run.ins.id ?? null },
    })
  }
  if (run.del) {
    marks.push({
      type: 'del',
      attrs: { author: run.del.author, date: run.del.date ?? null, id: run.del.id ?? null },
    })
  }
  if (run.rPrChange) {
    marks.push({
      type: 'rprChange',
      attrs: {
        author: run.rPrChange.author,
        date: run.rPrChange.date ?? null,
        id: run.rPrChange.id ?? null,
        old: run.rPrChange.old ?? null,
      },
    })
  }
  if (
    run.color ||
    run.sizeHalfPoints ||
    run.font ||
    run.fontAscii ||
    run.charSpacingTwips ||
    run.charScalePct ||
    run.highlight ||
    run.shading ||
    run.vertAlign ||
    run.em ||
    run.bold === false ||
    run.italic === false ||
    run.caps ||
    run.cs ||
    run.styleId ||
    run.rawRPr
  ) {
    marks.push({
      type: 'docTextStyle',
      attrs: {
        color: run.color ?? null,
        sizeHalfPoints: run.sizeHalfPoints ?? null,
        font: run.font ?? null,
        eaSlotEmpty: run.eaSlotEmpty ?? null,
        fontAscii: run.fontAscii ?? null,
        // cs chain only kicks in for complex-script text (Word's w:cs semantics)
        csFont: run.csFont && textHasComplexScript(run.text) ? run.csFont : null,
        charSpacingTwips: run.charSpacingTwips ?? null,
        charScaleEm: run.charScalePct ? charScaleEm(run.text, run.charScalePct) : null,
        highlight: run.highlight ?? null,
        shading: run.shading ?? null,
        vertAlign: run.vertAlign ?? null,
        em: run.em ?? null,
        boldOff: run.bold === false || null,
        italicOff: run.italic === false || null,
        caps: run.caps ?? null,
        cs: run.cs ?? null,
        styleId: run.styleId ?? null,
        rawRPr: run.rawRPr ?? null,
      },
    })
  }
  return marks
}

// ---- ProseMirror doc -> SaveBlock[] (dirty detection via content signatures) ----

export interface SavePlan {
  saveBlocks: SaveBlock[]
  /**
   * Chart data edits. These patch the chart's own zip part, not the body
   * paragraph (which stays byte-identical); App applies patchChartPartXml
   * and hands the result to saveDocx via options.partXml.
   */
  chartPatches: Array<{ partPath: string; patch: ChartPatch }>
  /**
   * docxIndex of an original block -> its index in saveBlocks. Ink
   * annotations anchor by docxIndex and the engine wants finalBlocks indexes.
   */
  saveBlockIndexByDocx: Map<number, number>
  /** count of blocks whose content was regenerated */
  changedCount: number
  /** count of original blocks removed */
  deletedCount: number
  totalOriginal: number
}

export function pmDocToSavePlan(doc: PmNode, originalBlocks: Block[]): SavePlan {
  const originalByIndex = new Map<number, Block>()
  for (const block of originalBlocks) {
    if (!block.hidden && block.docxIndex !== null) originalByIndex.set(block.docxIndex, block)
  }

  // Mixed-encoding guard: parse compresses wild producer relativeHeight values
  // (LibreOffice writes 1, 2, …) to compact ranks, but the raw XML keeps the
  // wild bytes. Word paints by the raw value, so rewriting ONE anchor to the
  // base+rank encoding while wild siblings survive would invert the saved
  // paint order. Once any wrap/z-order edit exists, every normalized anchor is
  // rewritten to base+rank; untouched documents still keep their bytes.
  const hasZOrderEdit = (nodes: PmNode[] | undefined): boolean => {
    for (const n of nodes ?? []) {
      if (n.type === 'docProtected' && n.attrs?.blockType === 'image') {
        const idx = n.attrs.docxIndex as number | null | undefined
        const orig = idx !== null && idx !== undefined ? originalByIndex.get(idx) : undefined
        if (orig) {
          const wrap = (n.attrs.imageWrap as ImageWrap | null) ?? null
          const z = n.attrs.imageZOrder != null ? Number(n.attrs.imageZOrder) : undefined
          if (wrap !== (orig.imageWrap ?? null) || (z !== undefined && z !== orig.imageZOrder))
            return true
        }
      }
      if (hasZOrderEdit(n.content)) return true
    }
    return false
  }
  const harmonizeZOrders =
    originalBlocks.some((b) => b.imageZOrderNormalized) && hasZOrderEdit(doc.content)

  // Multi-block sdt groups (one w:sdt split into N blocks): the shell open/close
  // bytes live on the first/last member. Track which surviving member emits
  // them so deleting or regenerating a boundary member never unbalances the sdt.
  const sdtGroupOf = new Map<number, number>()
  const sdtGroupShells = new Map<number, SdtShell>()
  // first/last original member per group: nested content controls leave wrapper
  // fragments on MIDDLE members' closeXml, so "emits closeXml" alone no longer
  // means "emits the group close" — only the boundary members do
  const sdtGroupFirst = new Map<number, number>()
  const sdtGroupLast = new Map<number, number>()
  for (const block of originalBlocks) {
    const shell = block.sdtShell
    if (block.hidden || block.docxIndex === null || shell?.group === undefined) continue
    sdtGroupOf.set(block.docxIndex, shell.group)
    if (!sdtGroupFirst.has(shell.group)) sdtGroupFirst.set(shell.group, block.docxIndex)
    sdtGroupLast.set(shell.group, block.docxIndex)
    const agg = sdtGroupShells.get(shell.group)
    if (!agg) sdtGroupShells.set(shell.group, { ...shell })
    else {
      if (shell.openXml) agg.openXml = shell.openXml
      if (shell.closeXml) agg.closeXml = shell.closeXml
    }
  }
  const sdtGroupEmits = new Map<
    number,
    Array<{ at: number; idx: number; open: boolean; close: boolean }>
  >()

  const saveBlocks: SaveBlock[] = []
  const chartPatches: Array<{ partPath: string; patch: ChartPatch }> = []
  const saveBlockIndexByDocx = new Map<number, number>()
  let changedCount = 0
  const usedIndexes = new Set<number>()
  /** record where an original anchor ended up in saveBlocks (set before push) */
  const mapAnchor = (idx: number) => saveBlockIndexByDocx.set(idx, saveBlocks.length)

  const recordSdtEmit = (node: PmNode, sb: SaveBlock, at: number) => {
    const idx = node.attrs?.docxIndex as number | null | undefined
    if (idx === null || idx === undefined) return
    if (saveBlockIndexByDocx.get(idx) !== at) return
    const group = sdtGroupOf.get(idx)
    if (group === undefined) return
    const shell = sdtGroupShells.get(group)!
    let open = false
    let close = false
    if (sb.kind === 'original') {
      const original = originalByIndex.get(idx)
      open = !!original?.sdtShell?.openXml
      close = !!original?.sdtShell?.closeXml
    } else if (sb.kind === 'generated') {
      open = !!sb.block.sdtShell?.openXml
      close = !!sb.block.sdtShell?.closeXml
    } else if (sb.kind === 'xml') {
      open = !!shell.openXml && sb.xml.startsWith(shell.openXml)
      close = !!shell.closeXml && sb.xml.endsWith(shell.closeXml)
    }
    // middle members may emit nested wrapper fragments; only the boundary
    // members' bytes are the group open/close the rebalance below cares about
    open = open && sdtGroupFirst.get(group) === idx
    close = close && sdtGroupLast.get(group) === idx
    let emits = sdtGroupEmits.get(group)
    if (!emits) sdtGroupEmits.set(group, (emits = []))
    emits.push({ at, idx, open, close })
  }

  for (const node of doc.content ?? []) {
    const revision = node.attrs?.blockRevision as {
      kind: 'ins' | 'del'
      author: string
      date?: string
      id?: string
    } | null
    const pushBlock = (block: SaveBlock) => {
      recordSdtEmit(node, block, saveBlocks.length)
      saveBlocks.push(revision ? { ...block, revision } : block)
    }
    if (node.type === 'docTable') {
      const idx = node.attrs?.docxIndex as number | null
      const original =
        idx !== null && idx !== undefined && !usedIndexes.has(idx)
          ? originalByIndex.get(idx)
          : undefined
      const model = pmTableToModel(node)
      if (original?.type === 'table') {
        usedIndexes.add(idx!)
        mapAnchor(idx!)
        const structurallyUnchanged =
          node.attrs?.originalStructure === tableStructureSignature(node)
        const formattingUnchanged =
          node.attrs?.originalFormatting === tableFormattingSignature(node)
        if (
          original.blockRevision &&
          !revision &&
          structurallyUnchanged &&
          formattingUnchanged &&
          original.originalXml
        ) {
          changedCount++
          pushBlock({ kind: 'xml', xml: unwrapBlockRevisionXml(original.originalXml) })
          continue
        }
        const tableTexts =
          structurallyUnchanged && formattingUnchanged
            ? tableTextsPatchFromModel(model, original)
            : null
        if (structurallyUnchanged && formattingUnchanged && tableTexts && original.originalXml) {
          changedCount++
          pushBlock({ kind: 'xml', xml: patchTableCellTexts(original.originalXml, tableTexts) })
        } else if (structurallyUnchanged && formattingUnchanged) {
          pushBlock({ kind: 'original', docxIndex: idx! })
        } else {
          changedCount++
          pushBlock({
            kind: 'xml',
            xml: generateTableModelXml(model, original.originalXml ?? undefined),
          })
        }
      } else {
        changedCount++
        pushBlock({ kind: 'xml', xml: generateTableModelXml(model) })
      }
      continue
    }
    if (node.type === 'docProtected') {
      const idx = node.attrs?.docxIndex as number | null
      if (idx !== null && idx !== undefined && originalByIndex.has(idx) && !usedIndexes.has(idx)) {
        usedIndexes.add(idx)
        mapAnchor(idx)
        const original = originalByIndex.get(idx)!
        if (original.blockRevision && !revision && original.originalXml) {
          changedCount++
          pushBlock({ kind: 'xml', xml: unwrapBlockRevisionXml(original.originalXml) })
          continue
        }
        const imagePatch = imagePatchOf(node, original)
        const tableTexts = tableTextsPatch(node, original)
        const textboxTexts = textboxParasPatch(node, original)
        const textboxSizes = textboxSizesPatch(node, original)
        const textboxStyles = textboxStylesPatch(node, original)
        const textboxOffsetX =
          node.attrs?.imageOffsetXEmu != null ? Number(node.attrs.imageOffsetXEmu) : undefined
        const textboxOffsetY =
          node.attrs?.imageOffsetYEmu != null ? Number(node.attrs.imageOffsetYEmu) : undefined
        const textboxPositionChanged =
          !!original.textboxes?.length &&
          textboxOffsetX !== undefined &&
          textboxOffsetY !== undefined &&
          (textboxOffsetX !== original.imageOffsetXEmu ||
            textboxOffsetY !== original.imageOffsetYEmu)
        const fieldText = fieldTextPatch(node, original)
        const formulaTokens = formulaTokensPatch(node, original)
        // chart data edits live in the chart's own part; the body block stays original
        const chartPatch = chartPatchOf(node, original)
        if (chartPatch) {
          changedCount++
          chartPatches.push(chartPatch)
        }
        // chart resize rewrites the body drawing's extent
        const chartDisplay = node.attrs?.chartDisplay as ChartDisplay | null
        const chartSize =
          chartDisplay?.widthPx &&
          chartDisplay.heightPx &&
          (chartDisplay.widthPx !== original.chartDisplay?.widthPx ||
            chartDisplay.heightPx !== original.chartDisplay?.heightPx)
            ? { w: chartDisplay.widthPx, h: chartDisplay.heightPx }
            : null
        const imageReplace =
          original.type === 'image'
            ? (node.attrs?.imageReplace as { base64: string; mime: string } | null)
            : null
        if ((imagePatch || imageReplace) && original.originalXml) {
          changedCount++
          let xml = imagePatch
            ? patchImageParagraphXml(original.originalXml, imagePatch)
            : original.originalXml
          if (imagePatch?.wrap !== undefined) {
            const posOffset =
              imagePatch.posOffsetX !== undefined && imagePatch.posOffsetY !== undefined
                ? { x: imagePatch.posOffsetX, y: imagePatch.posOffsetY }
                : undefined
            const marginAlign =
              posOffset === undefined && imagePatch.posH && imagePatch.posV
                ? { h: imagePatch.posH, v: imagePatch.posV }
                : undefined
            // a wrap-only change must not reset an existing stacking rank: the
            // patch carries zOrder only when the rank itself changed
            xml = applyImageWrap(
              xml,
              imagePatch.wrap,
              posOffset,
              marginAlign,
              imagePatch.zOrder ?? original.imageZOrder,
            )
          } else if (
            imagePatch?.zOrder !== undefined &&
            (node.attrs?.imageWrap as ImageWrap | null) != null
          ) {
            // z-order changed without a wrap-mode change on a still-floating
            // image: re-encode ONLY relativeHeight — a full anchor rebuild
            // would reset the position basis (relativeFrom) and distances
            xml = applyImageZOrder(xml, imagePatch.zOrder)
          } else if (
            imagePatch &&
            (imagePatch.posOffsetX !== undefined || imagePatch.posOffsetY !== undefined)
          ) {
            // posOffset changed without wrap change: patchImageParagraphXml already rewrote it
          } else if (
            harmonizeZOrders &&
            original.type === 'image' &&
            original.imageZOrderNormalized &&
            (node.attrs?.imageWrap as ImageWrap | null) != null
          ) {
            // geometry-only edit (resize/align/rotate) on a sibling that still
            // carries a wild producer relativeHeight: re-encode base+rank on
            // top of the geometry patch — relativeHeight only, the anchor's
            // position basis and wrap bytes must survive (see applyImageZOrder)
            xml = applyImageZOrder(xml, original.imageZOrder)
          }
          pushBlock({
            kind: 'xml',
            xml,
            ...(imageReplace
              ? {
                  replaceImage: {
                    base64: imageReplace.base64,
                    mime: imageReplace.mime as NewImage['mime'],
                  },
                }
              : {}),
          })
        } else if (tableTexts && original.originalXml) {
          changedCount++
          pushBlock({ kind: 'xml', xml: patchTableCellTexts(original.originalXml, tableTexts) })
        } else if (
          (textboxTexts || textboxSizes || textboxStyles || textboxPositionChanged) &&
          original.originalXml
        ) {
          changedCount++
          let xml = original.originalXml
          if (textboxTexts) xml = patchTextboxParas(xml, textboxTexts)
          if (textboxSizes) xml = patchTextboxSizes(xml, textboxSizes)
          if (textboxStyles) xml = patchShapeStyles(xml, textboxStyles)
          if (textboxPositionChanged) {
            const wrap =
              (node.attrs?.imageWrap as ImageWrap | null) ?? original.imageWrap ?? 'square-left'
            xml = applyImageWrap(xml, wrap, { x: textboxOffsetX!, y: textboxOffsetY! })
          }
          pushBlock({ kind: 'xml', xml })
        } else if (fieldText && original.originalXml) {
          changedCount++
          pushBlock({ kind: 'xml', xml: patchFieldParagraphXml(original.originalXml, fieldText) })
        } else if (formulaTokens && original.originalXml) {
          changedCount++
          pushBlock({ kind: 'xml', xml: patchMathTokens(original.originalXml, formulaTokens) })
        } else if (chartSize && original.originalXml) {
          changedCount++
          pushBlock({
            kind: 'xml',
            xml: patchDrawingExtent(original.originalXml, chartSize.w, chartSize.h),
          })
        } else if (
          harmonizeZOrders &&
          original.type === 'image' &&
          original.imageZOrderNormalized &&
          original.imageWrap &&
          original.originalXml
        ) {
          // untouched anchor still carrying a wild producer relativeHeight:
          // re-encode ONLY that attribute to base+rank so it stays ordered
          // against the anchors this session re-encoded (harmonizeZOrders
          // pre-scan). Position/wrap bytes stay untouched — the picture must
          // not shift from a reorder it wasn't even part of.
          changedCount++
          pushBlock({
            kind: 'xml',
            xml: applyImageZOrder(original.originalXml, original.imageZOrder),
          })
        } else {
          pushBlock({ kind: 'original', docxIndex: idx })
        }
      } else if (idx !== null && idx !== undefined && originalByIndex.has(idx)) {
        // pasted copy: the anchor is consumed by the first occurrence, so clone from the block's own data
        const original = originalByIndex.get(idx)!
        const image = imageFromProtectedAttrs(node)
        if (image) {
          changedCount++
          pushBlock({ kind: 'image', image })
        } else if (original.originalXml) {
          changedCount++
          pushBlock({ kind: 'xml', xml: stripAnchorMarkers(original.originalXml) })
        } else {
          console.warn('dropping unclonable copy of protected block', node.attrs?.label)
        }
      } else if (node.attrs?.genXml) {
        // editor-created table or other self-contained fragment
        changedCount++
        let xml = String(node.attrs.genXml)
        const table = node.attrs?.table as TableModel | null
        if (table && node.attrs?.blockType === 'table') {
          xml = patchTableCellTexts(
            xml,
            table.rows.map((row) => row.map((cell) => cell.paras)),
          )
        }
        // editor-generated TOC lines: write the auto-refreshed page number back
        // (right only — the title is already in the genXml, and a left+right
        // patch bails out entirely when the title text nodes don't line up)
        const genField = node.attrs?.fieldDisplay as FieldDisplay | null
        if (genField?.kind === 'tocLine' && genField.right) {
          xml = patchFieldParagraphXml(xml, { right: genField.right })
        }
        // patch textbox paragraphs for newly-inserted textboxes/shapes with text
        const genTextboxes = node.attrs?.textboxes as TextboxDisplay[] | null
        const hasNonEmptyTextbox =
          genTextboxes != null &&
          genTextboxes.length > 0 &&
          genTextboxes.some((box) => box.paras.some((p) => p.runs.some((r) => r.text !== '')))
        if (hasNonEmptyTextbox) {
          // editor-built XML has exactly one txbxContent per box, in box order
          xml = patchTextboxParas(xml, {
            byIndex: genTextboxes!.map((box) =>
              box.paras.map((p) => ({ runs: mergeRuns(p.runs), align: p.align ?? null })),
            ),
          })
        }
        // persist resize/autogrow of newly-inserted single-box shapes/lines;
        // horizontal lines keep their zero-height extent (display box is a grab band)
        const genBox = genTextboxes?.length === 1 ? genTextboxes[0] : null
        if (genBox && (genBox.widthPx || genBox.heightPx)) {
          xml = patchTextboxSizes(xml, [
            {
              wPx: genBox.widthPx ?? null,
              hPx: isStraightLineKind(genBox.prst) ? null : (genBox.heightPx ?? null),
            },
          ])
        }
        if (genBox) {
          xml = patchShapeStyles(xml, [
            { fillHex: genBox.fill ?? null, borderHex: genBox.borderColor ?? null },
          ])
        }
        // apply wrap changes for floating textboxes/shapes
        const genWrap = node.attrs?.imageWrap as ImageWrap | null
        const genOffsetX =
          node.attrs?.imageOffsetXEmu != null ? Number(node.attrs.imageOffsetXEmu) : undefined
        const genOffsetY =
          node.attrs?.imageOffsetYEmu != null ? Number(node.attrs.imageOffsetYEmu) : undefined
        if (genWrap !== undefined && genWrap !== null) {
          const posOffset =
            genOffsetX !== undefined && genOffsetY !== undefined
              ? { x: genOffsetX, y: genOffsetY }
              : undefined
          xml = applyImageWrap(xml, genWrap, posOffset)
        }
        pushBlock({ kind: 'xml', xml })
      } else if (node.attrs?.genImage) {
        changedCount++
        const image = { ...(node.attrs.genImage as NewImage) }
        if (node.attrs.imageWidthPx) image.widthPx = Number(node.attrs.imageWidthPx)
        if (node.attrs.imageHeightPx) image.heightPx = Number(node.attrs.imageHeightPx)
        const align = node.attrs.imageAlign as NewImage['align'] | null
        if (align) image.align = align
        const wrap = node.attrs.imageWrap as ImageWrap | null
        if (wrap) image.wrap = wrap
        if (node.attrs.imageZOrder != null) image.zOrder = Number(node.attrs.imageZOrder)
        if (node.attrs.imageRotDeg) image.rotDeg = Number(node.attrs.imageRotDeg)
        if (node.attrs.imageFlipH) image.flipH = true
        if (node.attrs.imageFlipV) image.flipV = true
        pushBlock({ kind: 'image', image })
      } else if (node.attrs?.genChart) {
        // in-place edits live in chartDisplay; the saved part reflects them
        changedCount++
        const spec = { ...(node.attrs.genChart as NewChart) }
        const display = node.attrs.chartDisplay as ChartDisplay | null
        if (display) {
          if (display.title !== undefined) spec.title = display.title
          spec.categories = display.categories
          spec.series = display.series.map((s, i) => ({
            name: s.name ?? spec.series[i]?.name ?? t('editorChartSeries', { num: i + 1 }),
            values: s.values,
          }))
        }
        pushBlock({
          kind: 'chart',
          chart: spec,
          ...(display?.widthPx && display.heightPx
            ? { extentPx: { w: display.widthPx, h: display.heightPx } }
            : {}),
        })
      } else {
        // picture that traveled through clipboard HTML (r136 cross-document
        // paste): no anchor and no genImage — rebuild from the preview bytes
        // or it silently vanishes on save
        const image = imageFromProtectedAttrs(node)
        if (image) {
          changedCount++
          pushBlock({ kind: 'image', image })
        }
      }
      // any other protected node without an anchor or generated payload cannot be regenerated; drop it
      continue
    }

    const generated = pmNodeToGeneratedBlock(node)
    const idx = node.attrs?.docxIndex as number | null
    const original = idx !== null && idx !== undefined ? originalByIndex.get(idx) : undefined
    if (
      original &&
      !usedIndexes.has(idx!) &&
      signatureOfBlock(original) === signatureOfGenerated(generated)
    ) {
      usedIndexes.add(idx!)
      mapAnchor(idx!)
      pushBlock({ kind: 'original', docxIndex: idx! })
    } else {
      changedCount++
      // an in-place edit consumes its original anchor: it is replaced, not
      // deleted — and may reuse the anchor's original pPr bytes. A split twin
      // (anchor already consumed) gets no rawPPr, so revision records and
      // section props are never duplicated.
      if (original && !usedIndexes.has(idx!)) {
        usedIndexes.add(idx!)
        mapAnchor(idx!)
        applyRawPPr(generated, original)
      } else if (original) {
        // A split twin inherits the source node's attrs, but pPrChange and
        // bookmark/comment anchors belong only to the anchored original.
        delete generated.pPrChange
        delete generated.bookmarks
        delete generated.hiddenBookmarks
        delete generated.commentStarts
        delete generated.commentEnds
        // A grouped shell (partial open/close of a multi-block sdt) must be
        // emitted exactly once, by the anchor.
        if (generated.sdtShell?.group !== undefined) delete generated.sdtShell
      }
      pushBlock({ kind: 'generated', block: generated })
    }
  }

  const attachShell = (emit: { at: number; idx: number }, side: 'open' | 'close') => {
    const group = sdtGroupOf.get(emit.idx)!
    const shell = sdtGroupShells.get(group)!
    const add = side === 'open' ? shell.openXml : shell.closeXml
    const sb = saveBlocks[emit.at]
    if (sb.kind === 'original') {
      const xml = originalByIndex.get(emit.idx)?.originalXml
      if (xml === undefined) return
      saveBlocks[emit.at] = {
        kind: 'xml',
        xml: side === 'open' ? add + xml : xml + add,
        docxIndex: emit.idx,
        ...(sb.revision ? { revision: sb.revision } : {}),
      }
    } else if (sb.kind === 'generated') {
      const gShell = sb.block.sdtShell ?? { ...shell, openXml: '', closeXml: '' }
      // concatenate: a nested wrapper fragment may already sit here, and the
      // group open must precede it (the group close must follow it)
      if (side === 'open') gShell.openXml = add + (gShell.openXml ?? '')
      else gShell.closeXml = (gShell.closeXml ?? '') + add
      sb.block.sdtShell = gShell
    } else if (sb.kind === 'xml') {
      sb.xml = side === 'open' ? add + sb.xml : sb.xml + add
    }
  }
  // Nested content controls put inner wrapper fragments on MIDDLE members'
  // closeXml (between-children bytes: "</inner sdt><next inner sdt>"). A
  // deleted middle member must not take its fragment with it, or the group
  // saves unbalanced sdt XML. Reattach the fragment to the nearest surviving
  // member before it (else the first after), before the group-level open/close
  // rebalance below so the outer close still lands last.
  const appendXml = (at: number, frag: string, before: boolean, group: number) => {
    const sb = saveBlocks[at]
    if (sb.kind === 'original') {
      const xml = originalByIndex.get(sb.docxIndex)?.originalXml
      if (xml === undefined) return
      saveBlocks[at] = {
        kind: 'xml',
        xml: before ? frag + xml : xml + frag,
        docxIndex: sb.docxIndex,
        ...(sb.revision ? { revision: sb.revision } : {}),
      }
    } else if (sb.kind === 'generated') {
      const shell = sb.block.sdtShell ?? {
        ...sdtGroupShells.get(group)!,
        openXml: '',
        closeXml: '',
      }
      if (before) shell.openXml = frag + (shell.openXml ?? '')
      else shell.closeXml = (shell.closeXml ?? '') + frag
      sb.block.sdtShell = shell
    } else if (sb.kind === 'xml') {
      sb.xml = before ? frag + sb.xml : sb.xml + frag
    }
  }
  for (const [group, emits] of sdtGroupEmits) {
    const members = [...sdtGroupOf.entries()]
      .filter(([, g]) => g === group)
      .map(([idx]) => idx)
      .sort((a, b) => a - b)
    const last = members[members.length - 1]
    const sorted = [...emits].sort((a, b) => a.at - b.at)
    // deleted leading members all prepend to the first survivor: collect their
    // fragments in document order and prepend once, or they stack reversed
    const prefixFrags: string[] = []
    for (const idx of members) {
      if (idx === last || usedIndexes.has(idx)) continue
      const frag = originalByIndex.get(idx)?.sdtShell?.closeXml
      if (!frag) continue
      const prev = [...sorted].reverse().find((e) => e.idx < idx)
      if (prev) appendXml(prev.at, frag, false, group)
      else prefixFrags.push(frag)
    }
    if (prefixFrags.length > 0) appendXml(sorted[0].at, prefixFrags.join(''), true, group)
  }
  for (const [group, emits] of sdtGroupEmits) {
    const shell = sdtGroupShells.get(group)!
    if (shell.openXml && !emits.some((e) => e.open)) attachShell(emits[0], 'open')
    if (shell.closeXml && !emits.some((e) => e.close)) attachShell(emits[emits.length - 1], 'close')
  }

  const deletedCount = [...originalByIndex.keys()].filter((i) => !usedIndexes.has(i)).length
  return {
    saveBlocks,
    chartPatches,
    saveBlockIndexByDocx,
    changedCount,
    deletedCount,
    totalOriginal: originalByIndex.size,
  }
}

/** rebuild a pasted image copy from its preview bytes; null when not materializable */
function imageFromProtectedAttrs(node: PmNode): NewImage | null {
  if (node.attrs?.blockType !== 'image') return null
  const m = /^data:(image\/(?:png|jpeg|gif));base64,(.+)$/.exec(
    String(node.attrs?.imageDataUrl ?? ''),
  )
  const widthPx = Number(node.attrs?.imageWidthPx)
  const heightPx = Number(node.attrs?.imageHeightPx)
  if (!m || !widthPx || !heightPx) return null
  const image: NewImage = { base64: m[2], mime: m[1] as NewImage['mime'], widthPx, heightPx }
  const align = node.attrs?.imageAlign as NewImage['align'] | null
  if (align) image.align = align
  const wrap = node.attrs?.imageWrap as ImageWrap | null
  if (wrap) image.wrap = wrap
  if (node.attrs?.imageZOrder != null) image.zOrder = Number(node.attrs.imageZOrder)
  if (node.attrs?.imageRotDeg) image.rotDeg = Number(node.attrs.imageRotDeg)
  if (node.attrs?.imageFlipH) image.flipH = true
  if (node.attrs?.imageFlipV) image.flipV = true
  return image
}

/** cloned XML must not repeat the anchor's bookmark/comment ids */
function stripAnchorMarkers(xml: string): string {
  return xml.replace(
    /<w:(?:bookmarkStart|bookmarkEnd|commentRangeStart|commentRangeEnd|commentReference)\b[^>]*\/>/g,
    '',
  )
}

/** chart data changes vs the parsed model; null when untouched or unpatchable */
function chartPatchOf(
  node: PmNode,
  original: Block,
): { partPath: string; patch: ChartPatch } | null {
  const current = node.attrs?.chartDisplay as ChartDisplay | null
  const initial = original.chartDisplay
  if (!current || !initial || current.partPath !== initial.partPath) return null
  if (
    current.series.length !== initial.series.length ||
    current.categories.length !== initial.categories.length
  ) {
    return null
  }
  const patch: ChartPatch = {}
  if (initial.title !== undefined && (current.title ?? '') !== initial.title) {
    patch.title = current.title ?? ''
  }
  let catChanged = false
  const categories = current.categories.map((cat, i) => {
    if (cat === initial.categories[i]) return null
    catChanged = true
    return cat
  })
  if (catChanged) patch.categories = categories
  let serChanged = false
  const series = current.series.map((ser, i): ChartSeriesPatch | null => {
    const orig = initial.series[i]
    if (ser.values.length !== orig.values.length) return null
    const serPatch: ChartSeriesPatch = {}
    if (orig.name !== undefined && (ser.name ?? '') !== orig.name) serPatch.name = ser.name ?? ''
    let valChanged = false
    const values = ser.values.map((value, j) => {
      // gaps in the cache have no pt to patch; they stay read-only
      if (value === orig.values[j] || orig.values[j] === null) return null
      valChanged = true
      return value
    })
    if (valChanged) serPatch.values = values
    if (Object.keys(serPatch).length === 0) return null
    serChanged = true
    return serPatch
  })
  if (serChanged) patch.series = series
  if (Object.keys(patch).length === 0) return null
  return { partPath: initial.partPath, patch }
}

interface ImageBlockPatch {
  widthPx?: number
  heightPx?: number
  align?: 'left' | 'center' | 'right' | null
  /** null = back to inline; undefined = wrap unchanged */
  wrap?: ImageWrap | null
  /** stacking rank among overlapping anchors (bring-forward/send-back); undefined = keep */
  zOrder?: number
  /** posOffset in EMU for free-position floating images; undefined = keep */
  posOffsetX?: number
  posOffsetY?: number
  /** margin-relative align pair (Word position-gallery presets); undefined = keep */
  posH?: 'left' | 'center' | 'right'
  posV?: 'top' | 'center' | 'bottom'
  /** rotation (deg clockwise, 0 removes) / mirror flips; undefined = keep */
  rotDeg?: number
  flipH?: boolean
  flipV?: boolean
}

/** size/align/wrap changes on an original image block; null when untouched */
function imagePatchOf(node: PmNode, original: Block): ImageBlockPatch | null {
  if (original.type !== 'image' || node.attrs?.blockType !== 'image') return null
  const patch: ImageBlockPatch = {}
  const w = node.attrs?.imageWidthPx ? Number(node.attrs.imageWidthPx) : null
  const h = node.attrs?.imageHeightPx ? Number(node.attrs.imageHeightPx) : null
  if (w && h && (w !== (original.imageWidthPx ?? null) || h !== (original.imageHeightPx ?? null))) {
    patch.widthPx = w
    patch.heightPx = h
  }
  const align = (node.attrs?.imageAlign as 'left' | 'center' | 'right' | null) ?? null
  if (align !== (original.imageAlign ?? null)) {
    patch.align = align
  }
  const wrap = (node.attrs?.imageWrap as ImageWrap | null) ?? null
  if (wrap !== (original.imageWrap ?? null)) {
    patch.wrap = wrap
  }
  const zOrder = node.attrs?.imageZOrder != null ? Number(node.attrs.imageZOrder) : undefined
  if (zOrder !== undefined && zOrder !== (original.imageZOrder ?? undefined)) {
    patch.zOrder = zOrder
  }
  // posOffset for free-position floating images
  const posOffsetX =
    node.attrs?.imageOffsetXEmu != null ? Number(node.attrs.imageOffsetXEmu) : undefined
  const posOffsetY =
    node.attrs?.imageOffsetYEmu != null ? Number(node.attrs.imageOffsetYEmu) : undefined
  if (posOffsetX !== undefined && posOffsetX !== (original.imageOffsetXEmu ?? undefined)) {
    patch.posOffsetX = posOffsetX
  }
  if (posOffsetY !== undefined && posOffsetY !== (original.imageOffsetYEmu ?? undefined)) {
    patch.posOffsetY = posOffsetY
  }
  const rotDeg = node.attrs?.imageRotDeg != null ? Number(node.attrs.imageRotDeg) : 0
  if (rotDeg !== (original.imageRotDeg ?? 0)) patch.rotDeg = rotDeg
  const flipH = !!node.attrs?.imageFlipH
  const flipV = !!node.attrs?.imageFlipV
  if (flipH !== (original.imageFlipH ?? false)) patch.flipH = flipH
  if (flipV !== (original.imageFlipV ?? false)) patch.flipV = flipV
  const posH = (node.attrs?.imagePosH as ImageBlockPatch['posH'] | null) ?? null
  const posV = (node.attrs?.imagePosV as ImageBlockPatch['posV'] | null) ?? null
  if (
    posH &&
    posV &&
    (posH !== (original.imagePosH ?? null) || posV !== (original.imagePosV ?? null))
  ) {
    patch.posH = posH
    patch.posV = posV
    // the position pair is written by applyImageWrap, which only runs when wrap is in the patch
    if (patch.wrap === undefined) patch.wrap = wrap
  }
  return Object.keys(patch).length > 0 ? patch : null
}

/** gridGap placeholders have no w:tc in the original XML: drop them so the
 *  patch grid's indexes line up with document-order w:tc segments */
function patchableCells(row: TableCell[] | undefined): TableCell[] {
  return (row ?? []).filter((cell) => !cell.gridGap)
}

/** per-cell text changes on an original table block; null when untouched */
function tableTextsPatch(node: PmNode, original: Block): (string[] | null)[][] | null {
  if (original.type !== 'table' || node.attrs?.blockType !== 'table') return null
  const current = node.attrs?.table as TableModel | null
  const orig = original.table
  if (!current || !orig) return null
  let changed = false
  const texts = current.rows.map((row, r) => {
    const origRow = patchableCells(orig.rows[r])
    return patchableCells(row).map((cell, c) => {
      const originalCell = origRow[c]
      if (!originalCell) return null
      if (cell.paras.join('\n') === originalCell.paras.join('\n')) return null
      changed = true
      return cell.paras
    })
  })
  return changed ? texts : null
}

function tableTextsPatchFromModel(
  current: TableModel,
  original: Block,
): (CellTextsPatch | null)[][] | null {
  if (original.type !== 'table' || !original.table) return null
  let changed = false
  const texts = current.rows.map((row, r) => {
    const origRow = patchableCells(original.table!.rows[r])
    return patchableCells(row).map((cell, c): CellTextsPatch | null => {
      const originalCell = origRow[c]
      if (!originalCell) return null
      // nested tables: diff cell texts per table; changes go through the recursive surgical patch
      if (cell.nestedTables?.length && originalCell.nestedTables?.length) {
        const nested = cell.nestedTables.map((nt, i) => {
          const origNt = originalCell.nestedTables![i]
          if (!origNt) return null
          const grid = nestedTextsDiff(nt, origNt)
          return grid
        })
        if (nested.some((g) => g !== null)) {
          changed = true
          return { nested }
        }
        return null
      }
      if (cell.paras.join('\n') === originalCell.paras.join('\n')) return null
      changed = true
      return cell.paras
    })
  })
  return changed ? texts : null
}

/** per-cell text diff of one nested table; null = untouched */
function nestedTextsDiff(current: TableModel, original: TableModel): (string[] | null)[][] | null {
  if (current.rows.length !== original.rows.length) return null
  let changed = false
  const grid = current.rows.map((row, r) => {
    const origRow = patchableCells(original.rows[r])
    return patchableCells(row).map((cell, c) => {
      const originalCell = origRow[c]
      if (!originalCell || cell.paras.join('\n') === originalCell.paras.join('\n')) return null
      changed = true
      return cell.paras
    })
  })
  return changed ? grid : null
}

/** rich-run signature of one textbox paragraph, for per-paragraph change detection */
export function textboxParaSignature(para: TextboxDisplay['paras'][number]): string {
  return JSON.stringify([para.align ?? null, normalizedRuns(para.runs)])
}

/** all-empty sub-editor content counts as "still no text" for a paras:[] box */
function boxStillEmpty(paras: TextboxDisplay['paras']): boolean {
  return paras.every((p) => p.runs.every((r) => r.text === ''))
}

/**
 * Per-box, per-paragraph rich-run patches on an original textbox block,
 * addressed by the box's txbxIndex (or shapeId for a box gaining its first
 * text); null when untouched. Unchanged paragraphs stay null so the engine
 * keeps their original bytes.
 */
function textboxParasPatch(node: PmNode, original: Block): TextboxParasPatchSet | null {
  const current = node.attrs?.textboxes as TextboxDisplay[] | null
  const orig = original.textboxes
  if (!current || !orig || current.length !== orig.length) return null
  const byIndex: (TextboxParaPatch | null)[][] = []
  const inject: Array<{ shapeId: string; paras: TextboxParaPatch[] }> = []
  current.forEach((box, i) => {
    const origBox = orig[i]
    const origParas = origBox.paras
    const same =
      box.paras.length === origParas.length &&
      box.paras.every((p, j) => textboxParaSignature(p) === textboxParaSignature(origParas[j]))
    if (same || (origParas.length === 0 && boxStillEmpty(box.paras))) return
    if (origBox.txbxIndex !== undefined) {
      byIndex[origBox.txbxIndex] = box.paras.map((p, j) => {
        if (
          j < origParas.length &&
          textboxParaSignature(p) === textboxParaSignature(origParas[j])
        ) {
          return null
        }
        // align is always explicit so a removed alignment also clears w:jc
        return { runs: mergeRuns(p.runs), align: p.align ?? null }
      })
    } else if (origBox.shapeId) {
      inject.push({
        shapeId: origBox.shapeId,
        paras: box.paras.map((p) => ({ runs: mergeRuns(p.runs), align: p.align ?? null })),
      })
    }
  })
  if (byIndex.length === 0 && inject.length === 0) return null
  return {
    ...(byIndex.length > 0 ? { byIndex } : {}),
    ...(inject.length > 0 ? { inject } : {}),
  }
}

function textboxSizesPatch(node: PmNode, original: Block): (TextboxSizePatch | null)[] | null {
  const current = node.attrs?.textboxes as TextboxDisplay[] | null
  const initial = original.textboxes
  if (!current || !initial || current.length !== initial.length) return null
  let changed = false
  const sizes = current.map((box, index) => {
    // a resize on an autofit box (no initial heightPx) pins its height:
    // patchTextboxSizes drops spAutoFit so Word honors the fixed extent
    const wPx = box.widthPx && box.widthPx !== initial[index].widthPx ? box.widthPx : null
    const hPx = box.heightPx && box.heightPx !== initial[index].heightPx ? box.heightPx : null
    if (wPx == null && hPx == null) return null
    changed = true
    return { wPx, hPx }
  })
  return changed ? sizes : null
}

function textboxStylesPatch(node: PmNode, original: Block): (ShapeStylePatch | null)[] | null {
  const current = node.attrs?.textboxes as TextboxDisplay[] | null
  const initial = original.textboxes
  if (!current || !initial || current.length !== initial.length) return null
  let changed = false
  const styles = current.map((box, index) => {
    const fillHex =
      (box.fill ?? null) !== (initial[index].fill ?? null) ? (box.fill ?? null) : undefined
    const borderHex =
      (box.borderColor ?? null) !== (initial[index].borderColor ?? null)
        ? (box.borderColor ?? null)
        : undefined
    if (fillHex === undefined && borderHex === undefined) return null
    changed = true
    return { fillHex, borderHex }
  })
  return changed ? styles : null
}

function fieldTextPatch(node: PmNode, original: Block): FieldTextPatch | null {
  const current = node.attrs?.fieldDisplay as FieldDisplay | null
  const initial = original.fieldDisplay
  if (!current || !initial || current.kind !== initial.kind) return null
  const patch: FieldTextPatch = {}
  if ((current.left ?? '') !== (initial.left ?? '')) patch.left = current.left ?? ''
  if (current.kind === 'tocLine' && (current.right ?? '') !== (initial.right ?? '')) {
    patch.right = current.right ?? ''
  }
  return Object.keys(patch).length > 0 ? patch : null
}

function formulaTokensPatch(node: PmNode, original: Block): string[] | null {
  const current = node.attrs?.formulaDisplay as FormulaDisplay | null
  const initial = original.formulaDisplay
  if (!current || !initial || current.tokens.length !== initial.tokens.length) return null
  return current.tokens.some((token, i) => token !== initial.tokens[i]) ? current.tokens : null
}

/**
 * High-fidelity pPr passthrough for in-place paragraph edits: text-only edits
 * reuse the original <w:pPr> bytes verbatim; format edits merge the six
 * format-model children into it (everything else keeps its bytes). Structure
 * changes (type / style / list) fall back to a full rebuild.
 */
function applyRawPPr(generated: GeneratedBlock, original: Block): void {
  if (original.rawPPr === undefined) return
  const structureSame =
    original.type === generated.type &&
    (original.styleId ?? null) === (generated.styleId ?? null) &&
    JSON.stringify(original.list ?? null) === JSON.stringify(generated.list ?? null)
  if (!structureSame) return
  const formatSame =
    JSON.stringify(normalizedFormat(original.format)) ===
    JSON.stringify(normalizedFormat(generated.format))
  let rawPPr = formatSame ? original.rawPPr : mergePPrFormat(original.rawPPr, generated.format)
  // Strip pPrChange when the user accepted/rejected it (pPrChange: null in generated block)
  if (generated.pPrChange === null && original.pPrChangeInfo !== undefined) {
    rawPPr = stripPPrChange(rawPPr)
  } else if (generated.pPrChange) {
    rawPPr = setPPrChange(rawPPr, generated.pPrChange)
  }
  generated.rawPPr = rawPPr
}

function nodeFormat(node: PmNode): ParaFormat | undefined {
  const format: ParaFormat = {}
  if (node.attrs?.align) format.align = node.attrs.align as ParaFormat['align']
  if (node.attrs?.lineSpacing) format.lineSpacing = Number(node.attrs.lineSpacing)
  if (node.attrs?.lineRule) format.lineRule = node.attrs.lineRule as ParaFormat['lineRule']
  if (node.attrs?.lineRawTwips) format.lineRawTwips = Number(node.attrs.lineRawTwips)
  if (node.attrs?.indentLeft) format.indentLeft = Number(node.attrs.indentLeft)
  if (node.attrs?.indentRight) format.indentRight = Number(node.attrs.indentRight)
  if (node.attrs?.indentFirstLine) format.indentFirstLine = Number(node.attrs.indentFirstLine)
  if (node.attrs?.spaceBefore != null) format.spaceBefore = Number(node.attrs.spaceBefore)
  if (node.attrs?.spaceAfter != null) format.spaceAfter = Number(node.attrs.spaceAfter)
  if (node.attrs?.spaceBeforeAuto != null)
    format.spaceBeforeAuto = node.attrs.spaceBeforeAuto as boolean
  if (node.attrs?.spaceAfterAuto != null)
    format.spaceAfterAuto = node.attrs.spaceAfterAuto as boolean
  if (node.attrs?.contextualSpacing != null)
    format.contextualSpacing = node.attrs.contextualSpacing as boolean
  if (node.attrs?.pageBreakBefore) format.pageBreakBefore = true
  if (node.attrs?.bidi) format.bidi = true
  if (node.attrs?.autoSpace != null) format.autoSpace = node.attrs.autoSpace as boolean
  if (node.attrs?.shadingFill) format.shadingFill = String(node.attrs.shadingFill)
  if (node.attrs?.borders) format.borders = String(node.attrs.borders)
  if (node.attrs?.borderLines) {
    try {
      const parsed = JSON.parse(String(node.attrs.borderLines))
      if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
        format.borderLines = parsed
      }
    } catch {
      /* ignore malformed */
    }
  }
  if (node.attrs?.tabStops) {
    try {
      const parsed = JSON.parse(String(node.attrs.tabStops))
      if (Array.isArray(parsed) && parsed.length > 0) format.tabStops = parsed
    } catch {
      /* ignore malformed */
    }
  }
  if (node.attrs?.dropCap) {
    try {
      const parsed = JSON.parse(String(node.attrs.dropCap))
      if (parsed && typeof parsed === 'object') format.dropCap = parsed
    } catch {
      /* ignore malformed */
    }
  }
  if (node.attrs?.emptyRunSize) format.emptyRunSizeHalfPoints = Number(node.attrs.emptyRunSize)
  if (node.attrs?.emptyRunFont) format.emptyRunFontFamily = String(node.attrs.emptyRunFont)
  return Object.keys(format).length > 0 ? format : undefined
}

export function pmNodeToGeneratedBlock(node: PmNode): GeneratedBlock {
  const runs = inlineToRuns(node.content ?? [])
  const format = nodeFormat(node)
  const bookmarks = nodeBookmarks(node, 'bookmarks')
  const hiddenBookmarks = nodeBookmarks(node, 'hiddenBookmarks')
  const commentStarts = nodeBookmarks(node, 'commentStarts')
  const commentEnds = nodeBookmarks(node, 'commentEnds')
  if (node.type === 'docHeading') {
    const pPrChange = node.attrs?.pPrChange as string | null | undefined
    const blockRevision = node.attrs?.blockRevision as GeneratedBlock['blockRevision']
    return {
      type: 'heading',
      level: Number(node.attrs?.level) || 1,
      styleId: (node.attrs?.styleId as string) ?? undefined,
      format,
      bookmarks,
      hiddenBookmarks,
      commentStarts,
      commentEnds,
      runs,
      ...(pPrChange !== undefined ? { pPrChange: pPrChange ?? null } : {}),
      ...(blockRevision !== undefined ? { blockRevision: blockRevision ?? null } : {}),
    }
  }
  if (node.type === 'docListItem') {
    const numId = node.attrs?.numId as string | null
    if (numId) {
      const pPrChange = node.attrs?.pPrChange as string | null | undefined
      const blockRevision = node.attrs?.blockRevision as GeneratedBlock['blockRevision']
      return {
        type: 'listItem',
        styleId: (node.attrs?.styleId as string) ?? undefined,
        list: {
          kind: (node.attrs?.kind as 'bullet' | 'ordered') ?? 'bullet',
          numId,
          ilvl: Number(node.attrs?.ilvl) || 0,
        },
        format,
        bookmarks,
        hiddenBookmarks,
        commentStarts,
        commentEnds,
        runs,
        ...(pPrChange !== undefined ? { pPrChange: pPrChange ?? null } : {}),
        ...(blockRevision !== undefined ? { blockRevision: blockRevision ?? null } : {}),
      }
    }
    // list item without a docx numbering id degrades to a plain paragraph with marker
    return {
      type: 'paragraph',
      format,
      bookmarks,
      hiddenBookmarks,
      commentStarts,
      commentEnds,
      runs: [{ text: '• ' }, ...runs],
    }
  }
  // Extract sdtShell from node attrs (serialized as JSON)
  const sdtShell = node.attrs?.sdtShell
    ? (() => {
        try {
          const parsed = JSON.parse(String(node.attrs.sdtShell))
          return parsed && typeof parsed === 'object' ? parsed : undefined
        } catch {
          return undefined
        }
      })()
    : undefined
  // pPrChange: propagate to GeneratedBlock so applyRawPPr can strip it when accepted
  const pPrChange = node.attrs?.pPrChange as string | null | undefined
  const blockRevision = node.attrs?.blockRevision as GeneratedBlock['blockRevision']
  return {
    type: 'paragraph',
    styleId: (node.attrs?.styleId as string) ?? undefined,
    format,
    bookmarks,
    hiddenBookmarks,
    commentStarts,
    commentEnds,
    runs,
    ...(sdtShell ? { sdtShell } : {}),
    // carry pPrChange through: null means "user accepted/rejected, strip from rawPPr"
    ...(pPrChange !== undefined ? { pPrChange: pPrChange ?? null } : {}),
    ...(blockRevision !== undefined ? { blockRevision: blockRevision ?? null } : {}),
  }
}

function nodeBookmarks(
  node: PmNode,
  attr: 'bookmarks' | 'hiddenBookmarks' | 'commentStarts' | 'commentEnds',
): string[] | undefined {
  const value = node.attrs?.[attr] as string[] | null | undefined
  return Array.isArray(value) && value.length > 0 ? value : undefined
}

export function inlineToRuns(content: PmNode[]): Run[] {
  const runs: Run[] = []
  for (const node of content) {
    if (node.type === 'hardBreak') {
      const ch = node.attrs?.pageBreak ? '\f' : node.attrs?.colBreak ? '\v' : '\n'
      const prev = runs[runs.length - 1]
      const prevAtomic =
        prev && (prev.noteRef || prev.xeTerm !== undefined || prev.math || prev.ruby || prev.image)
      if (prev && !prevAtomic) prev.text += ch
      else runs.push({ text: ch })
      continue
    }
    if (node.type === 'docNoteRef') {
      runs.push({
        text: String(node.attrs?.num ?? 1),
        noteRef: {
          kind: (node.attrs?.kind as 'footnote' | 'endnote') ?? 'footnote',
          id: String(node.attrs?.id ?? ''),
        },
      })
      continue
    }
    if (node.type === 'docXeMark') {
      runs.push({ text: '', xeTerm: String(node.attrs?.term ?? '') })
      continue
    }
    if (node.type === 'docInlineMath') {
      const omml = String(node.attrs?.omml ?? '')
      if (omml) runs.push({ text: String(node.attrs?.text ?? ''), math: { omml } })
      continue
    }
    if (node.type === 'docRuby') {
      const base = String(node.attrs?.base ?? '')
      const xml = String(node.attrs?.xml ?? '')
      if (base) {
        runs.push(
          xml ? { text: base, ruby: { rt: String(node.attrs?.rt ?? ''), xml } } : { text: base },
        )
      }
      continue
    }
    if (node.type === 'docInlineImage') {
      const dataUrl = String(node.attrs?.dataUrl ?? '')
      const xml = String(node.attrs?.xml ?? '')
      if (dataUrl && xml) {
        runs.push({
          text: '',
          image: {
            dataUrl,
            xml,
            ...(node.attrs?.widthPx ? { widthPx: Number(node.attrs.widthPx) } : {}),
            ...(node.attrs?.heightPx ? { heightPx: Number(node.attrs.heightPx) } : {}),
          },
        })
      }
      continue
    }
    if (node.type !== 'text' || !node.text) continue
    const run: Run = { text: node.text }
    for (const mark of node.marks ?? []) {
      if (mark.type === 'bold') run.bold = true
      else if (mark.type === 'italic') run.italic = true
      else if (mark.type === 'underline') run.underline = true
      else if (mark.type === 'strike') run.strike = true
      else if (mark.type === 'link') {
        run.link = {
          href: String(mark.attrs?.href ?? ''),
          rId: (mark.attrs?.rId as string) ?? undefined,
          tooltip: (mark.attrs?.tooltip as string) ?? undefined,
        }
      } else if (mark.type === 'refField') {
        run.refField = String(mark.attrs?.name ?? '')
      } else if (mark.type === 'instrField') {
        run.instrField = String(mark.attrs?.instr ?? '')
        if (mark.attrs?.beginXml) run.fldBeginXml = String(mark.attrs.beginXml)
      } else if (mark.type === 'comment') {
        const ids = String(mark.attrs?.ids ?? '')
          .split(' ')
          .filter(Boolean)
        if (ids.length > 0) run.commentIds = ids
      } else if (mark.type === 'ins' || mark.type === 'del') {
        const info: NonNullable<Run['ins']> = { author: String(mark.attrs?.author ?? '') }
        if (mark.attrs?.date) info.date = String(mark.attrs.date)
        if (mark.attrs?.id) info.id = String(mark.attrs.id)
        if (mark.type === 'ins') run.ins = info
        else run.del = info
      } else if (mark.type === 'docTextStyle') {
        if (mark.attrs?.color) run.color = String(mark.attrs.color)
        if (mark.attrs?.sizeHalfPoints) run.sizeHalfPoints = Number(mark.attrs.sizeHalfPoints)
        if (mark.attrs?.font) run.font = String(mark.attrs.font)
        if (mark.attrs?.fontAscii) run.fontAscii = String(mark.attrs.fontAscii)
        if (mark.attrs?.csFont) run.csFont = String(mark.attrs.csFont)
        if (mark.attrs?.charSpacingTwips) run.charSpacingTwips = Number(mark.attrs.charSpacingTwips)
        if (mark.attrs?.highlight) run.highlight = String(mark.attrs.highlight)
        if (mark.attrs?.shading) run.shading = String(mark.attrs.shading)
        if (mark.attrs?.vertAlign === 'superscript' || mark.attrs?.vertAlign === 'subscript') {
          run.vertAlign = mark.attrs.vertAlign
        }
        if (mark.attrs?.em) run.em = mark.attrs.em as NonNullable<Run['em']>
        if (mark.attrs?.cs) run.cs = true
        if (mark.attrs?.styleId) run.styleId = String(mark.attrs.styleId)
        if (mark.attrs?.rawRPr) run.rawRPr = String(mark.attrs.rawRPr)
      } else if (mark.type === 'rprChange') {
        run.rPrChange = {
          author: String(mark.attrs?.author ?? ''),
          ...(mark.attrs?.date ? { date: String(mark.attrs.date) } : {}),
          ...(mark.attrs?.id ? { id: String(mark.attrs.id) } : {}),
          ...(mark.attrs?.old
            ? { old: mark.attrs.old as NonNullable<Run['rPrChange']>['old'] }
            : {}),
        }
      }
    }
    runs.push(run)
  }
  return mergeRuns(runs)
}

function mergeRuns(runs: Run[]): Run[] {
  const merged: Run[] = []
  for (const run of runs) {
    const prev = merged[merged.length - 1]
    // reference markers / index entries / inline math / fields are atomic and
    // never merge — two identical FORMCHECKBOX runs must stay two fields
    const atomic =
      run.noteRef ||
      run.xeTerm !== undefined ||
      run.instrField !== undefined ||
      run.math ||
      run.ruby ||
      run.image ||
      prev?.noteRef ||
      prev?.xeTerm !== undefined ||
      prev?.instrField !== undefined ||
      prev?.math ||
      prev?.ruby ||
      prev?.image
    if (prev && !atomic && runStyleKey(prev) === runStyleKey(run)) prev.text += run.text
    else merged.push({ ...run })
  }
  return merged
}

function runStyleKey(run: Run): string {
  return JSON.stringify([
    run.rawRPr ?? null,
    run.styleId ?? null,
    !!run.bold,
    !!run.italic,
    !!run.underline,
    !!run.strike,
    run.color ?? null,
    run.sizeHalfPoints ?? null,
    run.font ?? null,
    run.fontAscii ?? null,
    run.highlight ?? null,
    run.shading ?? null,
    run.vertAlign ?? null,
    run.link?.href ?? null,
    run.link?.rId ?? null,
    run.commentIds?.join(' ') ?? null,
    revisionKey(run),
    run.noteRef ? [run.noteRef.kind, run.noteRef.id] : null,
    run.xeTerm ?? null,
    run.refField ?? null,
    run.instrField ?? null,
    run.fldBeginXml ?? null,
    run.math?.omml ?? null,
    run.ruby?.xml ?? null,
  ])
}

function revisionKey(run: Run): string | null {
  if (!run.ins && !run.del) return null
  return JSON.stringify([
    run.ins?.author ?? null,
    run.ins?.date ?? null,
    run.ins?.id ?? null,
    run.del?.author ?? null,
    run.del?.date ?? null,
    run.del?.id ?? null,
  ])
}

// ---- signatures: "did the user actually change this block?" ----

function normalizedRuns(runs: Run[]): unknown[] {
  return mergeRuns(runs).map((r) => [
    r.text,
    r.rawRPr ?? null,
    r.styleId ?? null,
    !!r.bold,
    !!r.italic,
    !!r.underline,
    !!r.strike,
    r.color ?? null,
    r.sizeHalfPoints ?? null,
    r.font ?? null,
    r.fontAscii ?? null,
    r.highlight ?? null,
    r.vertAlign ?? null,
    r.link?.href ?? null,
    r.commentIds?.join(' ') ?? null,
    revisionKey(r),
    r.noteRef ? [r.noteRef.kind, r.noteRef.id] : null,
    r.xeTerm ?? null,
    r.refField ?? null,
    r.instrField ?? null,
    r.fldBeginXml ?? null,
    r.math?.omml ?? null,
    r.ruby?.xml ?? null,
  ])
}

function normalizedFormat(format: ParaFormat | undefined): unknown {
  if (!format) return null
  return [
    format.align ?? null,
    format.lineSpacing ?? null,
    format.lineRule ?? null,
    format.lineRawTwips ?? null,
    format.bidi ?? false,
    format.indentLeft ?? null,
    format.indentRight ?? null,
    format.indentFirstLine ?? null,
    format.spaceBefore ?? null,
    format.spaceAfter ?? null,
    format.pageBreakBefore ?? false,
    format.shadingFill ?? null,
    format.borders ?? null,
    format.borderLines ? JSON.stringify(format.borderLines) : null,
    format.tabStops ? JSON.stringify(format.tabStops) : null,
    format.dropCap ? JSON.stringify(format.dropCap) : null,
    format.autoSpace ?? null,
    format.emptyRunSizeHalfPoints ?? null,
  ]
}

export function signatureOfBlock(block: Block): string {
  return JSON.stringify({
    type: block.type,
    level: block.level ?? null,
    styleId: block.styleId ?? null,
    list: block.list ? [block.list.kind, block.list.numId, block.list.ilvl] : null,
    format: normalizedFormat(block.format),
    bookmarks: block.bookmarks ?? null,
    hiddenBookmarks: block.hiddenBookmarks ?? null,
    commentStarts: block.commentStarts ?? null,
    commentEnds: block.commentEnds ?? null,
    runs: normalizedRuns(block.runs ?? []),
    // include pPrChangeInfo in signature: present = has pPrChange, absent = clean
    pPrChange: block.pPrChangeInfo ? JSON.stringify(block.pPrChangeInfo) : null,
    blockRevision: block.blockRevision ?? null,
  })
}

export function signatureOfGenerated(block: GeneratedBlock): string {
  return JSON.stringify({
    type: block.type,
    level: block.level ?? null,
    styleId: block.styleId ?? null,
    list: block.list ? [block.list.kind, block.list.numId, block.list.ilvl] : null,
    format: normalizedFormat(block.format),
    bookmarks: block.bookmarks ?? null,
    hiddenBookmarks: block.hiddenBookmarks ?? null,
    commentStarts: block.commentStarts ?? null,
    commentEnds: block.commentEnds ?? null,
    runs: normalizedRuns(block.runs),
    // include pPrChange in signature: null (accepted/rejected) != non-null (has pPrChange)
    pPrChange: block.pPrChange ?? null,
    blockRevision: block.blockRevision ?? null,
  })
}

import { Editor, Extension, Node } from '@tiptap/core'
import type { ChainedCommands, RawCommands } from '@tiptap/core'
import { UndoRedo } from '@tiptap/extensions'
import { DOMSerializer } from '@tiptap/pm/model'
import type { DOMOutputSpec, Node as PmNode } from '@tiptap/pm/model'
import {
  AllSelection,
  NodeSelection,
  Plugin,
  PluginKey,
  TextSelection,
  type EditorState,
  type Transaction,
} from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'
import type { EditorView } from '@tiptap/pm/view'
import {
  CellSelection,
  addRowAfter,
  columnResizing,
  columnResizingPluginKey,
  deleteTable,
  goToNextCell,
  isInTable,
  tableEditing,
} from '@tiptap/pm/tables'
import {
  autospaceBoundaries,
  autospacePadBetween,
  cjkDeclaredLineFactor,
  cssAutoLineMult,
  cssFontFamily,
  cssRunFontFamily,
  cssGridSpacingPt,
  cssLineHeight,
  isCjkFontName,
  lineHeightFactor,
  paraLineFactorCss,
  SIMSUN_GAP_CHAR_RE,
  simsunGapLineFactor,
  textHasCjk,
  textHasHangul,
  cssSimsunGapLineExpr,
  WORD_AUTO_SPACING_PT,
} from '../line-metrics'
import { noteMarkText } from '../note-format'
import { t } from '../i18n/locale'
import {
  ommlToMathML,
  patchMathTokens,
  type ChartDisplay,
  type DiagramDisplay,
  type DocDefaults,
  type FieldDisplay,
  type FormulaDisplay,
  type NewChart,
  type NumberingDef,
  type Run,
  type StyleDisplay,
  type StyleInfo,
  type TableCell,
  type TableModel,
  type TextboxDisplay,
} from '@genoffice/docx-engine'
import {
  bulletMarkerScale,
  computeListMarkerInfos,
  markerTabAdvance,
  type ListItemRef,
} from './numbering'
import { symbolFontCovers } from '../font-check'
import { dropActiveSubEditor, notifySubEditorState, setActiveSubEditor } from './active-editor'
import { paraBorderCss } from './hf-dom'
import { PaginationGapsExtension } from './pagination-gaps'
import { CaretMarksMemory, FORMAT_MARKS, serializeMarks } from './caret-marks'
import { ColumnLayoutExtension } from './column-layout'
import { TableHandle } from './table-handle'
import { TrackChangesExtension } from './revisions'
import { inlineToRuns, runsToInline, textboxParaSignature, type PmNode as PmJson } from './convert'
import { constrainTableWidthAtCell } from './table-sizing'

/**
 * Custom schema mirroring the docx-engine Block model 1:1.
 * Every top-level node carries `docxIndex` (patch anchor, null = new) and
 * `aiChanged` (diff highlighting for AI edits).
 */

import {
  CHART_MAX_WIDTH_PX,
  CHART_TITLE_ROW_PX,
  drawChartSvg,
  renderChartSpec,
  renderFieldSpec,
  renderFormulaSpec,
  renderTableSpec,
  renderTextboxSpec,
  runSpanSpecs,
  textboxBoxStyle,
  wireChartEditing,
} from './protected-render'
import { isStraightLineKind } from './shape-svg'
import {
  BoldMark,
  CommentMark,
  DelMark,
  InsMark,
  InstrFieldMark,
  ItalicMark,
  LinkMark,
  RefFieldMark,
  RevisionOriginalExtension,
  RprChangeMark,
  StrikeMark,
  TextStyleMark,
  UnderlineMark,
} from './marks'
import {
  DropCapExtension,
  MoveRevisionExtension,
  PPrChangeExtension,
  ParaBorderMergeExtension,
  ParaMarkDelExtension,
  PendingCommentHighlightExtension,
  ResolvedCommentsExtension,
  SdtExtension,
  SearchHighlightExtension,
  TabStopExtension,
  WsRunLineHeightExtension,
} from './decoration-extensions'
import { AutoDirectionExtension } from './direction'
import { InactiveSelectionExtension } from './inactive-selection'
import { AiQueueAnchorsExtension } from './ai-queue-anchors'
import { PageGapNavExtension } from './page-gap-nav'
import { moveBlocks } from './move-block'
export * from './marks'
export * from './decoration-extensions'

const anchorAttrs = {
  docxIndex: { default: null as number | null },
  styleId: { default: null as string | null },
  aiChanged: { default: false },
  /** user bookmark names starting in this paragraph */
  bookmarks: { default: null as string[] | null },
  /** Word internal bookmarks (_Ref/_Toc…): kept out of the bookmark manager, written back verbatim on paragraph rebuild so cross-references don't break */
  hiddenBookmarks: { default: null as string[] | null },
  /** Endpoints of cross-paragraph comment ranges (only one end in this paragraph); written back on paragraph rebuild to avoid orphan marks */
  commentStarts: { default: null as string[] | null },
  commentEnds: { default: null as string[] | null },
  align: { default: null as string | null },
  lineSpacing: { default: null as number | null },
  /** Word line-spacing rule (auto/atLeast/exact); null = auto */
  lineRule: { default: null as string | null },
  /** Raw w:spacing w:line twips (used by atLeast/exact) */
  lineRawTwips: { default: null as number | null },
  /** w:snapToGrid: false only when explicitly off (opts out of docGrid snapping) */
  snapToGrid: { default: null as boolean | null },
  indentLeft: { default: null as number | null },
  indentRight: { default: null as number | null },
  indentFirstLine: { default: null as number | null },
  spaceBefore: { default: null as number | null },
  spaceAfter: { default: null as number | null },
  /** w:beforeAutospacing / w:afterAutospacing: Word's HTML auto spacing (14pt) replaces
      the literal; false = explicit "0" overriding a style-chain auto */
  spaceBeforeAuto: { default: null as boolean | null },
  spaceAfterAuto: { default: null as boolean | null },
  /** w:contextualSpacing on the pPr itself; false = explicit off overriding the style */
  contextualSpacing: { default: null as boolean | null },
  pageBreakBefore: { default: false },
  /** RTL paragraph (w:bidi); align is already the visual value */
  bidi: { default: false },
  /** render-only RTL inferred from run w:rtl / RTL script when w:bidi is absent
      (HTML-converted docs); align is the visual value as-is, never saved */
  bidiInferred: { default: false },
  /** CJK-Latin/digit auto spacing (w:autoSpaceDE/DN); null = Word default on */
  autoSpace: { default: null as boolean | null },
  shadingFill: { default: null as string | null },
  /** w:sz (half-points) of the paragraph mark / dropped empty runs; sizes the line of run-less paragraphs */
  emptyRunSize: { default: null as number | null },
  /** w:rFonts of the paragraph mark / dropped empty runs; faces the line of run-less paragraphs */
  emptyRunFont: { default: null as string | null },
  /** subset of "tblr": which sides have a single-line border */
  borders: { default: null as string | null },
  /** JSON per-side {color?,szPt?} for `borders` (w:pBdr declared look) */
  borderLines: { default: null as string | null },
  /** custom tab stops JSON: Array<{pos:number,val:string,leader?:string}> */
  tabStops: { default: null as string | null },
  /** drop cap: JSON {type:'drop'|'margin',lines:number} */
  dropCap: { default: null as string | null },
  /** SDT shell: JSON SdtShell (alias, tag, controlType, openXml, closeXml) */
  sdtShell: { default: null as string | null },
  /** move revision type: 'from' (content moved away) or 'to' (content moved here) */
  moveRevision: { default: null as string | null },
  /** JSON {author,date?,id?} when the paragraph has a pPrChange tracked format change */
  pPrChange: { default: null as string | null },
  /** JSON {author,date?,id?} when the paragraph mark is a tracked deletion (w:pPr/w:rPr/w:del) */
  paraMarkDel: { default: null as string | null },
  /** top-level insertion/deletion revision ({kind,author,date?}) */
  blockRevision: { default: null as Record<string, string> | null },
  /** JSON marks snapshot for an empty block's caret (Word's pilcrow
      formatting): stamped while the caret holds stored marks in an empty
      block, restored as storedMarks when the caret re-enters bare — arrow
      navigation must not drop the pending format (alpha ledger r114) */
  caretMarks: { default: null as string | null },
}

/** Max explicit run size (half-points) when *every* text child declares one, else null.
 *  Any run inheriting the body size keeps the inherited strut (conservative: never shrinks a line Word would keep tall). */
function explicitStrutHalfPoints(node: { descendants?: PmNode['descendants'] }): number | null {
  if (!node.descendants) return null
  let max: number | null = null
  let inherited = false
  node.descendants((child) => {
    if (inherited) return false
    if (!child.isText) return true
    const sz = child.marks.find((m) => m.type.name === 'docTextStyle')?.attrs.sizeHalfPoints as
      number | null | undefined
    if (sz == null) inherited = true
    else max = Math.max(max ?? 0, sz)
    return false
  })
  return inherited ? null : max
}

/**
 * Latin paragraphs: runs declaring a font override the doc-level factor with that
 * face's metric (Word sizes lines by run fonts, not the docDefaults face — a
 * Cambria-themed doc whose runs all say Calibri lays out at 1.22, not 1.17);
 * runs inheriting the body face keep the doc var via max().
 */
function latinParaFactor(node: { descendants?: PmNode['descendants'] }, scriptVar: string): string {
  if (!node.descendants) return scriptVar
  let declaredMax = 0
  let undeclared = false
  node.descendants((child) => {
    if (!child.isText) return true
    const attrs = child.marks.find((m) => m.type.name === 'docTextStyle')?.attrs
    // ascii/hAnsi slot only: Word lays Latin text with the (possibly inherited)
    // ascii face, so an eastAsia-only declaration (attrs.font) must not drag
    // its factor onto a Latin line (EA "Arial Unicode MS" = 1.74, sample 13)
    const family = attrs?.fontAscii as string | null | undefined
    if (family) declaredMax = Math.max(declaredMax, lineHeightFactor(family))
    else undeclared = true
    return false
  })
  if (declaredMax <= 0) return scriptVar
  return undeclared ? `max(${scriptVar}, ${declaredMax})` : String(declaredMax)
}

/** Paragraph font-family follows the runs when every text run declares one:
 *  Chromium's line box is the union of the strut (paragraph font) and run boxes,
 *  so a paragraph face with a taller ascent than the runs' inflates every line
 *  past the computed line-height. No run inherits the face, so only the strut
 *  (and list markers without their own font) changes. */
function paraDeclaredFontFamily(node: { descendants?: PmNode['descendants'] }): string | null {
  if (!node.descendants) return null
  let first: string | null = null
  let inherited = false
  node.descendants((child) => {
    if (inherited) return false
    if (!child.isText) return true
    const attrs = child.marks.find((m) => m.type.name === 'docTextStyle')?.attrs
    const ea = attrs?.font ? String(attrs.font) : null
    const ascii = attrs?.fontAscii ? String(attrs.fontAscii) : null
    if (!ea && !ascii) {
      inherited = true
      return false
    }
    // same chain the run's span renders, so the strut face equals the run face
    first ??= cssRunFontFamily(ascii, ea)
    return false
  })
  return inherited ? null : first
}

/**
 * Per-paragraph --doc-line-factor value: CJK runs with a declared font take that
 * font's LO-metric factor (max over runs); undeclared CJK runs keep the
 * document-level CJK var; non-CJK paragraphs keep the script-based guess.
 */
function paraLineFactor(node: {
  textContent?: string
  descendants?: PmNode['descendants']
}): string {
  const scriptVar = paraLineFactorCss(node.textContent ?? '')
  if (!node.descendants) return scriptVar
  if (!textHasCjk(node.textContent ?? '')) return latinParaFactor(node, scriptVar)
  let declaredMax = 0
  let undeclaredCjk = false
  node.descendants((child) => {
    if (!child.isText) return true
    if (!textHasCjk(child.text ?? '')) return false
    const mark = child.marks.find((m) => m.type.name === 'docTextStyle')
    // empty-EA-theme-slot backfills keep the Word-look face but are not a
    // document font choice: LO cascades such runs to the document's EA default,
    // so they count as undeclared here (the doc-level var carries that factor).
    // Latin-named faces likewise don't drive CJK line height — an ascii-only
    // "Times New Roman" run still renders its CJK via the inherited EA font.
    const family =
      mark?.attrs.eaSlotEmpty === true
        ? null
        : ((mark?.attrs.font ?? mark?.attrs.fontAscii) as string | null | undefined)
    if (family && isCjkFontName(family)) {
      declaredMax = Math.max(declaredMax, cjkDeclaredLineFactor(family) ?? lineHeightFactor(family))
    } else undeclaredCjk = true
    return false
  })
  if (declaredMax <= 0) return scriptVar
  return undeclaredCjk ? `max(${scriptVar}, ${declaredMax})` : String(declaredMax)
}

/**
 * Paragraph FORMATTING attrs that survive the clipboard HTML round-trip
 * (renderHTML emits them as data-para JSON; parseHTML restores them), typed so
 * a crafted/corrupt payload can't smuggle wrong-typed values into the model.
 * Identity/anchor attrs stay out on purpose: a pasted paragraph is NEW content,
 * so docxIndex (save patch anchor), bookmarks, comment endpoints, sdtShell and
 * revision metadata must not be duplicated by copy/paste (alpha ledger r117).
 */
const CLIPBOARD_PARA_ATTR_TYPES: Record<string, 'string' | 'number' | 'boolean'> = {
  styleId: 'string',
  align: 'string',
  lineSpacing: 'number',
  lineRule: 'string',
  lineRawTwips: 'number',
  snapToGrid: 'boolean',
  indentLeft: 'number',
  indentRight: 'number',
  indentFirstLine: 'number',
  spaceBefore: 'number',
  spaceAfter: 'number',
  spaceBeforeAuto: 'boolean',
  spaceAfterAuto: 'boolean',
  contextualSpacing: 'boolean',
  pageBreakBefore: 'boolean',
  bidi: 'boolean',
  bidiInferred: 'boolean',
  autoSpace: 'boolean',
  shadingFill: 'string',
  emptyRunSize: 'number',
  emptyRunFont: 'string',
  borders: 'string',
  borderLines: 'string',
  tabStops: 'string',
  dropCap: 'string',
  // docListItem identity (paragraphs never set them; ProseMirror drops attrs
  // unknown to the parsing node type). numId stays out: a pasted copy pointing
  // at another document's numbering table would dangle.
  kind: 'string',
  ilvl: 'number',
}

/** data-para payload for a block node, or null when everything is at defaults */
function clipboardParaPayload(attrs: Record<string, unknown>): string | null {
  const clip: Record<string, unknown> = {}
  for (const key of Object.keys(CLIPBOARD_PARA_ATTR_TYPES)) {
    const v = attrs[key]
    if (v == null) continue
    // false IS meaningful for snapToGrid/autoSpace (explicit opt-out); for the
    // false-by-default flags it's just the default and stays out of the payload
    if (v === false && (key === 'pageBreakBefore' || key === 'bidi' || key === 'bidiInferred')) {
      continue
    }
    clip[key] = v
  }
  return Object.keys(clip).length > 0 ? JSON.stringify(clip) : null
}

/** Inverse of clipboardParaPayload for parseHTML getAttrs: restores only
 *  whitelisted keys whose runtime type matches, null when absent/malformed. */
export function clipboardParaAttrs(el: HTMLElement): Record<string, unknown> | null {
  const raw = el.getAttribute?.('data-para')
  if (!raw) return null
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch {
    return null
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) return null
  const attrs: Record<string, unknown> = {}
  for (const [key, type] of Object.entries(CLIPBOARD_PARA_ATTR_TYPES)) {
    const v = (parsed as Record<string, unknown>)[key]
    if (typeof v !== type) continue
    if (type === 'number' && !Number.isFinite(v)) continue
    attrs[key] = v
  }
  return Object.keys(attrs).length > 0 ? attrs : null
}

function blockAttrs(
  node: {
    attrs: Record<string, unknown>
    textContent?: string
    descendants?: PmNode['descendants']
  },
  {
    includeIndent = true,
    listGeometry = false,
  }: { includeIndent?: boolean; listGeometry?: boolean } = {},
): Record<string, string> {
  const attrs: Record<string, string> = {}
  if (node.attrs.docxIndex !== null) attrs['data-idx'] = String(node.attrs.docxIndex)
  // paragraph formatting round-trips the clipboard through this attribute:
  // the CSS below renders it, but nothing parses that CSS back (r117)
  const clip = clipboardParaPayload(node.attrs)
  if (clip) attrs['data-para'] = clip
  // per-document style CSS (generated from styles.xml) targets this attribute
  if (node.attrs.styleId) attrs['data-style'] = String(node.attrs.styleId)
  // bookmark jump targets ([data-bookmarks~="name"]; names cannot contain spaces)
  if (Array.isArray(node.attrs.bookmarks) && node.attrs.bookmarks.length > 0) {
    attrs['data-bookmarks'] = (node.attrs.bookmarks as string[]).join(' ')
  }
  const classes: string[] = []
  if (node.attrs.aiChanged) classes.push('ai-changed')
  // textless paragraph: table-cell CSS shrinks these to the Latin line height
  // (an empty cell inheriting the CJK factor would out-grow the content cells)
  if (!node.textContent) classes.push('doc-p-empty')
  if (node.attrs.pageBreakBefore) {
    classes.push('page-break-before')
    attrs['data-page-break-label'] = t('editorPageBreak')
  }
  if (classes.length > 0) attrs['class'] = classes.join(' ')
  const styles: string[] = []
  if (node.attrs.bidi || node.attrs.bidiInferred) {
    styles.push('direction:rtl', 'unicode-bidi:isolate')
  } else {
    // explicit: paragraph direction is its own w:bidi only — a bidiVisual
    // table's dir="rtl" mirrors column order but must not reorder cell text
    styles.push('direction:ltr')
  }
  // explicit autoSpaceDE/DN off also disables the browser's native 1/8em gap
  if (node.attrs.autoSpace === false) styles.push('text-autospace:no-autospace')
  if (node.attrs.align) {
    styles.push(`text-align:${node.attrs.align === 'distribute' ? 'justify' : node.attrs.align}`)
  }
  // the line-height factor follows paragraph content (approximating Word's max-of-inline-fonts
  // line height): CJK paragraphs get the CJK factor, pure-Western ones the document's
  // font-aware Latin factor (doc-style-css sets --doc-line-factor-latin per body font).
  // Runs that DECLARE a font override the script guess with that font's factor
  // (LO probe: line height follows the requested face's metrics even when CJK
  // glyphs fall through to another font — EA "Times New Roman" lays at 1.15em);
  // the paragraph takes the max over its CJK runs, like Word's tallest-run rule.
  if (node.textContent) {
    // Word breaks Korean at spaces (UAX#14 default would break between syllables);
    // scoped to Hangul-bearing paragraphs so CJ text keeps per-char breaking.
    // overflow-wrap keeps the sim's overlong-word hard-break fallback.
    if (textHasHangul(node.textContent)) {
      styles.push('word-break:keep-all', 'overflow-wrap:anywhere')
    }
    styles.push(`--doc-line-factor:${paraLineFactor(node)}`)
    const fam = paraDeclaredFontFamily(node)
    if (fam) styles.push(`font-family:${fam}`)
    // Word's line strut follows run sizes; without this the paragraph inherits the
    // body size (often larger than table-cell runs) and every line box inflates.
    // Shrink-only: a large run already lifts its own line, and Word sizes each
    // line by the runs on it, so the strut must never exceed the inherited size
    const strut = explicitStrutHalfPoints(node)
    if (strut) styles.push(`--doc-strut:${strut / 2}pt`, 'font-size:min(var(--doc-strut), 1em)')
  } else if (node.attrs.emptyRunSize || node.attrs.emptyRunFont) {
    // Word sizes an empty line by the paragraph mark / empty run, both directions
    if (node.attrs.emptyRunSize) styles.push(`font-size:${Number(node.attrs.emptyRunSize) / 2}pt`)
    // the mark face sizes the empty line, CJK included (empty-line probe
    // 2026-08-25: SimSun 1.30 / DengXian 1.36 / Malgun 1.74 / Calibri 1.24 —
    // each face's own text factor; the earlier Western-only scoping starved
    // CJK marks down to the document factor and doubled their grid rows)
    const fam = node.attrs.emptyRunFont ? String(node.attrs.emptyRunFont) : null
    if (fam) {
      styles.push(`--doc-line-factor:${lineHeightFactor(fam)}`, `font-family:${cssFontFamily(fam)}`)
    }
  }
  const lineRule = (node.attrs.lineRule as 'auto' | 'atLeast' | 'exact' | null) ?? undefined
  const lineRawTwips = node.attrs.lineRawTwips != null ? Number(node.attrs.lineRawTwips) : undefined
  const lineSpacing = node.attrs.lineSpacing ? Number(node.attrs.lineSpacing) : undefined
  const lh = cssLineHeight(lineRule, lineRawTwips, lineSpacing)
  if (lh) styles.push(`line-height:${lh}`)
  // grid-doc span snapping (doc-style-css): fixed-height lines opt out (atLeast
  // never snaps, including the line="0" opt-out form), multiples scale
  if ((lineRule === 'exact' && lineRawTwips) || lineRule === 'atLeast') {
    classes.push('doc-lh-fixed')
    attrs['class'] = classes.join(' ')
  } else {
    const mult =
      lineSpacing ?? (lineRule === 'auto' && lineRawTwips ? lineRawTwips / 240 : undefined)
    // explicit single (mult 1) still overrides an inherited style/doc multiple
    if (mult) styles.push(`--doc-line-mult:${mult}`)
  }
  // w:snapToGrid=0: opt this paragraph out of docGrid line snapping (the
  // round(up) expressions read the pitch var, so a local ~0 disables them;
  // .doc-nosnap re-declares --doc-line-max as natural x mult on the paragraph
  // AND its spans — an inline var would not reach spans, which .doc-page *
  // re-declares per element)
  if (node.attrs.snapToGrid === false) {
    styles.push('--doc-grid-pitch:0.0001px')
    classes.push('doc-nosnap')
    attrs['class'] = classes.join(' ')
  }
  // list items already indent via padding; a margin would double-shift them.
  // listGeometry: drive list geometry with w:ind (--li-left text indent, --li-hang the hanging
  // area i.e. the number-marker width); negative text-indent is expressed by the marker box, no longer emitted directly
  // Logical (inline-start/end) margins: identical to left/right in LTR, and in bidi
  // paragraphs they mirror, matching Word's quirk that w:ind left/right swap sides.
  if (includeIndent && node.attrs.indentLeft) {
    styles.push(`margin-inline-start:${Number(node.attrs.indentLeft) / 20}pt`)
  } else if (listGeometry && node.attrs.indentLeft) {
    styles.push(`--li-left:${Number(node.attrs.indentLeft) / 20}pt`)
  }
  if (node.attrs.indentRight)
    styles.push(`margin-inline-end:${Number(node.attrs.indentRight) / 20}pt`)
  if (node.attrs.indentFirstLine) {
    const firstLine = Number(node.attrs.indentFirstLine)
    if (listGeometry && firstLine < 0) styles.push(`--li-hang:${-firstLine / 20}pt`)
    else styles.push(`text-indent:${firstLine / 20}pt`)
  }
  // explicit 0 must still emit (w:after="0" overrides the style/docDefaults margin)
  // autospacing replaces the literal with Word's HTML auto value (14pt, measured);
  // the sp-auto-* classes let CSS collapse it to 0 between two list items (Word)
  if (node.attrs.spaceBeforeAuto) {
    styles.push(`margin-top:${cssGridSpacingPt(WORD_AUTO_SPACING_PT)}`)
    classes.push('sp-auto-b')
  } else if (node.attrs.spaceBefore != null)
    styles.push(`margin-top:${cssGridSpacingPt(Number(node.attrs.spaceBefore) / 20)}`)
  if (node.attrs.spaceAfterAuto) {
    styles.push(`margin-bottom:${cssGridSpacingPt(WORD_AUTO_SPACING_PT)}`)
    classes.push('sp-auto-a')
  } else if (node.attrs.spaceAfter != null)
    styles.push(`margin-bottom:${cssGridSpacingPt(Number(node.attrs.spaceAfter) / 20)}`)
  // direct w:contextualSpacing: same-style adjacency suppression / explicit opt-out
  // (the style-level rules live in doc-style-css and honor these classes)
  if (node.attrs.contextualSpacing === true) classes.push('ctx-sp')
  else if (node.attrs.contextualSpacing === false) classes.push('ctx-sp-off')
  if (classes.length > 0) attrs['class'] = classes.join(' ')
  if (node.attrs.shadingFill) styles.push(`background-color:#${node.attrs.shadingFill}`)
  if (node.attrs.borders) {
    const borders = String(node.attrs.borders)
    let borderLines: Partial<Record<string, { color?: string; szPt?: number }>> = {}
    if (node.attrs.borderLines) {
      try {
        borderLines = JSON.parse(String(node.attrs.borderLines))
      } catch {
        /* malformed attr: fall back to legacy line */
      }
    }
    const line = (side: string) => paraBorderCss(borderLines[side])
    if (borders.includes('t')) styles.push(`border-top:${line('t')}`)
    if (borders.includes('b')) styles.push(`border-bottom:${line('b')}`)
    if (borders.includes('l')) styles.push(`border-left:${line('l')}`)
    if (borders.includes('r')) styles.push(`border-right:${line('r')}`)
    styles.push('padding:1px 4px')
  }
  if (node.attrs.tabStops) {
    // debugging aid only; actual tab layout is measured by TabStopExtension
    attrs['data-tab-stops'] = String(node.attrs.tabStops)
  }
  if (node.attrs.dropCap) {
    attrs['data-drop-cap'] = String(node.attrs.dropCap)
  }
  if (node.attrs.sdtShell) {
    attrs['data-sdt'] = 'true'
  }
  if (node.attrs.moveRevision) {
    attrs['data-move-revision'] = String(node.attrs.moveRevision)
  }
  if (node.attrs.pPrChange) {
    attrs['data-ppr-change'] = 'true'
  }
  if (styles.length > 0) attrs['style'] = styles.join(';')
  return attrs
}

export const DocDocument = Node.create({
  name: 'doc',
  topNode: true,
  content: 'block+',
})

export const DocText = Node.create({
  name: 'text',
  group: 'inline',
})

/** Footnote / endnote reference marker: an atomic superscript number. */
export const DocNoteRef = Node.create({
  name: 'docNoteRef',
  inline: true,
  group: 'inline',
  atom: true,
  selectable: true,
  addAttributes() {
    return {
      kind: { default: 'footnote' as 'footnote' | 'endnote' },
      id: { default: '' },
      num: { default: 1 },
    }
  },
  parseHTML() {
    return [{ tag: 'sup[data-note-ref]' }]
  },
  renderHTML({ node }) {
    return [
      'sup',
      {
        'data-note-ref': String(node.attrs.id),
        'data-note-kind': String(node.attrs.kind),
        class: 'doc-note-ref',
        title: node.attrs.kind === 'footnote' ? t('editorFootnote') : t('editorEndnote'),
      },
      // bare superscript number, matching Word; hover/selection accents live in CSS
      noteMarkText(node.attrs.kind as 'footnote' | 'endnote', Number(node.attrs.num) || 1),
    ]
  },
})

/** Index entry (XE field) marker: invisible in Word, a small chip on screen. */
export const DocXeMark = Node.create({
  name: 'docXeMark',
  inline: true,
  group: 'inline',
  atom: true,
  selectable: true,
  addAttributes() {
    return { term: { default: '' } }
  },
  parseHTML() {
    return [{ tag: 'span[data-xe-term]' }]
  },
  renderHTML({ node }) {
    return [
      'span',
      {
        'data-xe-term': String(node.attrs.term),
        class: 'doc-xe-mark',
        title: t('editorIndexEntry', { term: String(node.attrs.term) }),
      },
    ]
  },
})

/**
 * Phonetic guide (w:ruby): atomic, renders as a native <ruby> element.
 * `xml` is the exact <w:ruby> fragment that saves verbatim.
 */
export const DocRuby = Node.create({
  name: 'docRuby',
  inline: true,
  group: 'inline',
  atom: true,
  selectable: true,
  addAttributes() {
    return {
      base: { default: '' },
      rt: { default: '' },
      xml: { default: '' },
    }
  },
  parseHTML() {
    return [{ tag: 'ruby[data-doc-ruby]' }]
  },
  renderText({ node }) {
    return String(node.attrs.base ?? '')
  },
  renderHTML({ node }) {
    return [
      'ruby',
      { 'data-doc-ruby': 'true', class: 'doc-ruby' },
      String(node.attrs.base),
      ['rt', {}, String(node.attrs.rt)],
    ]
  },
})

/**
 * Inline picture in a table cell (document content: sizes stay in px, no theme
 * tokens). `xml` is the exact <w:drawing> fragment that saves verbatim.
 */
export const DocInlineImage = Node.create({
  name: 'docInlineImage',
  inline: true,
  group: 'inline',
  atom: true,
  selectable: true,
  addAttributes() {
    return {
      dataUrl: { default: '' },
      widthPx: { default: null as number | null },
      heightPx: { default: null as number | null },
      xml: { default: '' },
      /** floating (wp:anchor) picture: wrap kind + anchor offsets (display only) */
      wrap: { default: null as string | null },
      offsetXEmu: { default: null as number | null },
      offsetYEmu: { default: null as number | null },
      wrapDistTopEmu: { default: null as number | null },
      wrapDistBottomEmu: { default: null as number | null },
      wrapDistLeftEmu: { default: null as number | null },
      wrapDistRightEmu: { default: null as number | null },
      /** picture outline (pic:spPr a:ln solid fill, display-only) */
      border: { default: null as { color: string; widthPt: number } | null },
      /** positionV line/center: the picture centers on its anchor line (display only) */
      lineCenterV: { default: false },
    }
  },
  parseHTML() {
    return [{ tag: 'img[data-inline-image]' }]
  },
  renderHTML({ node }) {
    const attrs: Record<string, string> = {
      'data-inline-image': '1',
      class: 'doc-inline-img',
      src: String(node.attrs.dataUrl),
    }
    const w = Number(node.attrs.widthPx)
    const h = Number(node.attrs.heightPx)
    if (w > 0) attrs.style = `width:${w}px;${h > 0 ? `height:${h}px` : 'height:auto'}`
    const ib = node.attrs.border as { color: string; widthPt: number } | null
    if (ib) {
      // picture outline (document data, not chrome)
      attrs.style =
        `${attrs.style ? `${attrs.style};` : ''}border:${((ib.widthPt * 96) / 72).toFixed(1)}px ` +
        `solid #${String(ib.color).replace(/[^0-9A-Fa-f]/g, '')}`
    }
    const wrap = node.attrs.wrap as string | null
    if (wrap === 'front' || wrap === 'behind') {
      // no-wrap / behind-text anchor: absolute overlay at the anchor offset from
      // the run position (zero flow footprint, like Word); behind approximated
      // by reduced opacity — the flowing canvas has no z layer under the text
      const left = Number(node.attrs.offsetXEmu ?? 0) / EMU_PER_PX
      const top = Number(node.attrs.offsetYEmu ?? 0) / EMU_PER_PX
      attrs.style =
        `${attrs.style ?? ''};position:absolute;left:${left.toFixed(1)}px;` +
        `top:${top.toFixed(1)}px;max-width:none`
      if (wrap === 'behind') attrs.class += ' doc-inline-img--behind'
      return [
        'span',
        { class: 'doc-inline-img-anchor', 'data-inline-image-anchor': '1' },
        ['img', attrs],
      ]
    }
    // square/tight/through wrap → real CSS float so the surrounding text wraps;
    // topBottom → block line of its own
    if (wrap) attrs.class += ` doc-inline-img--wrap-${wrap}`
    // free-position floats honor the numeric posOffset X like the block-image
    // path: X measures from the column start; right floats convert it to a
    // right-edge inset so the picture is not stuck flush against the margin
    const tx = node.attrs.offsetXEmu != null ? Number(node.attrs.offsetXEmu) / EMU_PER_PX : null
    if (tx != null && wrap) {
      if (wrap.endsWith('-right') && w > 0) {
        attrs.style = `${attrs.style ?? ''};margin-right:calc(100% - ${(tx + w).toFixed(1)}px);max-width:none`
      } else if (wrap.endsWith('-left')) {
        attrs.style = `${attrs.style ?? ''};margin-left:${tx.toFixed(1)}px;max-width:none`
      }
    }
    if (wrap) {
      const distancePx = (attr: string): number | null =>
        node.attrs[attr] != null ? Number(node.attrs[attr]) / EMU_PER_PX : null
      const top = distancePx('wrapDistTopEmu')
      const bottom = distancePx('wrapDistBottomEmu')
      const left = distancePx('wrapDistLeftEmu')
      const right = distancePx('wrapDistRightEmu')
      const distances = [
        top != null ? `margin-top:${top.toFixed(1)}px` : '',
        bottom != null ? `margin-bottom:${bottom.toFixed(1)}px` : '',
        wrap.endsWith('-right') && left != null ? `margin-left:${left.toFixed(1)}px` : '',
        wrap.endsWith('-left') && right != null ? `margin-right:${right.toFixed(1)}px` : '',
      ].filter(Boolean)
      if (distances.length) {
        attrs.style = `${attrs.style ?? ''};${distances.join(';')}`
      }
    }
    // positionV line/center: lift so the picture centers on the anchor line
    // (0.75em ≈ half a single-spaced line) instead of hanging below it
    if (node.attrs.lineCenterV && h > 0) {
      attrs.style = `${attrs.style ?? ''};margin-top:calc(0.75em - ${(h / 2).toFixed(1)}px)`
    }
    return ['img', attrs]
  },
})

/**
 * Atomic inline formula flowing with the text. `omml` is the exact <m:oMath>
 * fragment that saves verbatim; `mathml` renders natively in Chromium;
 * `latex` is kept for editor-created formulas so double-click can re-edit.
 */
export const DocInlineMath = Node.create({
  name: 'docInlineMath',
  inline: true,
  group: 'inline',
  atom: true,
  selectable: true,
  addAttributes() {
    return {
      omml: { default: '' },
      mathml: { default: '' },
      latex: { default: null as string | null },
      /** flat token strip (word count / AI read fallback) */
      text: { default: '' },
    }
  },
  parseHTML() {
    return [{ tag: 'span[data-inline-math]' }]
  },
  renderText({ node }) {
    return String(node.attrs.text ?? '')
  },
  renderHTML({ node }) {
    return ['span', inlineMathDomAttrs(node), String(node.attrs.text ?? '')]
  },
  addNodeView() {
    return ({ node, getPos }) => {
      let currentNode = node
      const dom = document.createElement('span')
      const render = () => {
        for (const [key, value] of Object.entries(inlineMathDomAttrs(currentNode))) {
          dom.setAttribute(key, value)
        }
        const mathml = String(currentNode.attrs.mathml ?? '')
        if (mathml) dom.innerHTML = mathml
        else dom.textContent = String(currentNode.attrs.text ?? '')
      }
      render()
      dom.addEventListener('dblclick', () => {
        // only editor-created formulas carry LaTeX and can be re-edited
        const latex = currentNode.attrs.latex
        const pos = (getPos as () => number | undefined)()
        if (latex && typeof pos === 'number') {
          window.dispatchEvent(
            new CustomEvent('ai-docs-edit-inline-math', {
              detail: { pos, latex: String(latex), kind: 'inline' },
            }),
          )
        }
      })
      return {
        dom,
        update: (n: PmNode) => {
          if (n.type.name !== 'docInlineMath') return false
          currentNode = n
          render()
          return true
        },
      }
    }
  },
})

function inlineMathDomAttrs(node: { attrs: Record<string, unknown> }): Record<string, string> {
  return {
    'data-inline-math': '1',
    class: 'doc-inline-math',
    title: node.attrs.latex
      ? t('editorEquationEditHint', { latex: String(node.attrs.latex) })
      : t('editorEquation'),
  }
}

export const DocHardBreak = Node.create({
  name: 'hardBreak',
  inline: true,
  group: 'inline',
  selectable: false,
  linebreakReplacement: true,
  addAttributes() {
    return {
      // in-paragraph page break (w:br w:type="page"): the pagination engine breaks after the containing block
      pageBreak: { default: false },
      // column break (w:br w:type="column"): next column, or next page in a single-column section
      colBreak: { default: false },
    }
  },
  parseHTML() {
    return [
      { tag: 'br.doc-page-br', attrs: { pageBreak: true } },
      { tag: 'br.doc-col-br', attrs: { colBreak: true } },
      { tag: 'br' },
    ]
  },
  renderHTML({ node }) {
    return node.attrs.pageBreak
      ? ['br', { class: 'doc-page-br' }]
      : node.attrs.colBreak
        ? ['br', { class: 'doc-col-br' }]
        : ['br']
  },
  addKeyboardShortcuts() {
    return {
      'Shift-Enter': () => this.editor.commands.insertContent({ type: 'hardBreak' }),
    }
  },
})

/**
 * Enter must replace ANY non-empty selection with a paragraph break (Word).
 * Two selection shapes broke the default chain (alpha ledger r125/r129):
 * - Ctrl+A's AllSelection: every command in the split chain declines
 *   (splitBlock needs a textblock-depth selection; AllSelection's ends sit at
 *   doc depth 0) — the press was a silent no-op.
 * - A cross-block TextSelection with BOTH ends at block starts (what
 *   Shift+Right from a paragraph end followed by Shift+Down produces):
 *   TipTap's one-shot splitBlock THROWS "Inserted content deeper than
 *   insertion position" mid-dispatch, so the press did nothing while plain
 *   typing over the same selection worked.
 * Replacing the one-shot with separate delete + split dispatches sidesteps
 * both: the delete settles the document (and block merge) first, the split
 * then runs on an ordinary caret.
 */
export const EnterReplacesSelection = Extension.create({
  name: 'enterReplacesSelection',
  addKeyboardShortcuts() {
    return {
      Enter: () => {
        const sel = this.editor.state.selection
        // Word keeps the formatting of the START of the replaced selection
        // for what is typed next; the split-off caret often sits in an
        // EMPTIED paragraph with no neighbor to inherit from, so the first
        // deleted character's marks must ride along explicitly (alpha
        // ledger r133: keyboard whole-line selections type in theme font)
        const carryMarks = () => {
          // first TEXT node in the replaced range (an AllSelection's $from
          // sits at doc depth 0, where nodeAt returns the block, not a run)
          let marks: readonly import('@tiptap/pm/model').Mark[] | null = null
          sel.$from.doc.nodesBetween(sel.from, sel.to, (node) => {
            if (marks) return false
            if (node.isText) {
              marks = node.marks
              return false
            }
            return true
          })
          // formatting only: comment/link/ins/del must not reattach to new
          // typing (they are inclusive:false for the same reason — bugbot)
          const found = (marks ?? sel.$from.marks()).filter((mark) =>
            FORMAT_MARKS.has(mark.type.name),
          )
          if (found.length > 0) {
            const tr = this.editor.state.tr.setMeta('addToHistory', false)
            // Word keeps the pending format on BOTH empty paragraphs the
            // replace leaves behind. The caret-marks memory stamps only the
            // block the caret sits in (the second), so arrowing up to the
            // FIRST emptied line reverted typing to the theme font and the
            // font box to "(Body)" (alpha ledger r133 residual). The stamp
            // step must precede setStoredMarks: a doc-changing step resets
            // the transaction's stored marks.
            const $head = this.editor.state.selection.$from
            const boundary = $head.before($head.depth)
            const prev = this.editor.state.doc.resolve(boundary).nodeBefore
            if (prev && prev.isTextblock && prev.content.size === 0 && 'caretMarks' in prev.attrs) {
              tr.setNodeMarkup(boundary - prev.nodeSize, undefined, {
                ...prev.attrs,
                caretMarks: serializeMarks(found),
              })
            }
            tr.setStoredMarks([...found])
            this.editor.view.dispatch(tr)
          }
        }
        if (sel instanceof AllSelection) {
          // an AllSelection maps to itself through the delete (it always
          // spans the whole doc), so hand the split a real caret explicitly
          this.editor.commands.deleteSelection()
          this.editor.chain().setTextSelection(1).splitBlock().run()
          carryMarks()
          return true
        }
        if (sel.empty || !(sel instanceof TextSelection)) return false
        if (sel.$from.sameParent(sel.$to)) return false // default chain is fine
        this.editor.commands.deleteSelection()
        this.editor.commands.splitBlock()
        carryMarks()
        return true
      },
    }
  },
})

/**
 * Word's insert-and-move chords that must only fire with editor focus. Kept
 * out of the application menu on purpose: a menu accelerator would
 * swallow Cmd+Enter from the renderer inputs that submit with it (comments
 * panel, prompt modal).
 */
export const WordEditorShortcuts = Extension.create({
  name: 'wordEditorShortcuts',
  addKeyboardShortcuts() {
    return {
      'Mod-Enter': () =>
        this.editor.commands.insertContent({
          type: 'docParagraph',
          attrs: { pageBreakBefore: true },
        }),
      'Mod-Shift-Enter': () =>
        this.editor.commands.insertContent({ type: 'hardBreak', attrs: { colBreak: true } }),
      // U+00A0 and U+2011: the characters Word inserts for these two chords
      'Mod-Shift-Space': () => this.editor.commands.insertContent('\u00a0'),
      'Mod-Shift--': () => this.editor.commands.insertContent('\u2011'),
      'Alt-Shift-ArrowUp': () => moveBlocks(this.editor, -1),
      'Alt-Shift-ArrowDown': () => moveBlocks(this.editor, 1),
    }
  },
})

export const DocParagraph = Node.create({
  name: 'docParagraph',
  group: 'block',
  content: 'inline*',
  addAttributes() {
    return { ...anchorAttrs }
  },
  parseHTML() {
    // getAttrs null = match with defaults (foreign HTML); data-para restores formatting
    return [{ tag: 'p', getAttrs: (el) => clipboardParaAttrs(el as HTMLElement) }]
  },
  renderHTML({ node }) {
    return ['p', blockAttrs(node), 0]
  },
})

export const DocHeading = Node.create({
  name: 'docHeading',
  group: 'block',
  content: 'inline*',
  addAttributes() {
    return { ...anchorAttrs, level: { default: 1 } }
  },
  parseHTML() {
    return [1, 2, 3, 4, 5, 6].map((level) => ({
      tag: `h${level}`,
      getAttrs: (el) => ({ level, ...clipboardParaAttrs(el as HTMLElement) }),
    }))
  },
  renderHTML({ node }) {
    const level = Math.min(Math.max(Number(node.attrs.level) || 1, 1), 6)
    return [`h${level}`, blockAttrs(node), 0]
  },
})

export const DocListItem = Node.create({
  name: 'docListItem',
  group: 'block',
  content: 'inline*',
  addAttributes() {
    return {
      ...anchorAttrs,
      kind: { default: 'bullet' as 'bullet' | 'ordered' },
      numId: { default: null as string | null },
      ilvl: { default: 0 },
    }
  },
  parseHTML() {
    const ilvlOf = (el: HTMLElement): number => {
      let depth = -1
      for (let node = el.parentElement; node; node = node.parentElement) {
        if (node.tagName === 'UL' || node.tagName === 'OL') depth++
      }
      return Math.max(0, Math.min(depth, 8))
    }
    return [
      {
        tag: 'li',
        getAttrs: (el) => ({
          kind: (el as HTMLElement).closest('ol') ? 'ordered' : 'bullet',
          ilvl: ilvlOf(el as HTMLElement),
          ...clipboardParaAttrs(el as HTMLElement),
        }),
      },
      // our own clipboard HTML: renderHTML emits <div class="doc-li …">, which
      // no rule matched before r117 — pasting a GenOffice list item degraded it
      // to plain text. kind/ilvl ride in data-para; classes are the fallback.
      {
        tag: 'div.doc-li',
        getAttrs: (el) => {
          const div = el as HTMLElement
          const attrs = clipboardParaAttrs(div) ?? {}
          if (attrs.kind === undefined) {
            attrs.kind = div.classList.contains('doc-li-ordered') ? 'ordered' : 'bullet'
          }
          if (attrs.ilvl === undefined) {
            const m = /(?:^|\s)ilvl-(\d)(?:\s|$)/.exec(div.className)
            attrs.ilvl = m ? Number(m[1]) : 0
          }
          return attrs
        },
      },
    ]
  },
  renderHTML({ node }) {
    const base = blockAttrs(node, { includeIndent: false, listGeometry: true })
    const cls = [
      'doc-li',
      `doc-li-${node.attrs.kind}`,
      `ilvl-${Math.min(Number(node.attrs.ilvl) || 0, 4)}`,
      base['class'] ?? '',
    ]
      .filter(Boolean)
      .join(' ')
    return ['div', { ...base, class: cls }, 0]
  },
  addCommands() {
    return {
      /**
       * Word's Enter behavior inside a list: a non-empty item splits
       * into a sibling item (same kind/numId/level, numbering follows), an empty
       * one leaves the list. ProseMirror's default splitBlock produces the
       * schema's default block — a paragraph — which broke continuous entry.
       */
      continueDocList:
        () =>
        ({ state, chain }: { state: EditorState; chain: () => ChainedCommands }) => {
          const { $from, empty } = state.selection
          if (!empty) return false
          const node = $from.parent
          if (node.type.name !== 'docListItem') return false
          if (node.content.size === 0) {
            return chain()
              .setNode('docParagraph', { ...node.attrs, docxIndex: null })
              .run()
          }
          return chain()
            .splitBlock()
            .command(({ tr, dispatch }) => {
              const pos = tr.selection.$from.before(tr.selection.$from.depth)
              const created = tr.doc.nodeAt(pos)
              if (!created) return false
              // The split half is a fresh paragraph: turn it back into a sibling
              // list item, without inheriting the original's docx anchor
              if (dispatch) {
                tr.setNodeMarkup(pos, state.schema.nodes.docListItem, {
                  ...created.attrs,
                  docxIndex: null,
                  kind: node.attrs.kind,
                  numId: node.attrs.numId,
                  ilvl: node.attrs.ilvl,
                })
              }
              return true
            })
            .run()
        },
    } as Partial<RawCommands>
  },
  addKeyboardShortcuts() {
    const changeLevel = (delta: number) => () => {
      if (!this.editor.isActive('docListItem')) return false
      const ilvl = Number(this.editor.getAttributes('docListItem').ilvl) || 0
      const next = Math.min(Math.max(ilvl + delta, 0), 8)
      if (next === ilvl) return true
      return this.editor.commands.updateAttributes('docListItem', { ilvl: next })
    }
    return {
      Tab: changeLevel(1),
      'Shift-Tab': changeLevel(-1),
      Enter: () => (this.editor.commands as unknown as DocListCommands).continueDocList(),
    }
  },
})

interface DocListCommands {
  continueDocList: () => boolean
}

export interface ListNumberingStorage {
  /** numId -> definition, from the open document's numbering.xml */
  defs: Map<string, NumberingDef>
  /** style/docDefaults display info: marker measurement reads the same font
   *  chain the ::before inherits (data-style rule -> .doc-page baseline) */
  styles?: Map<string, StyleInfo>
  docDefaults?: DocDefaults
}

declare module '@tiptap/core' {
  interface Storage {
    listNumbering: ListNumberingStorage
  }
}

/**
 * Real multilevel numbering: compute each list item's marker in document order per the
 * numbering.xml definitions (1. / a. / 1.1 / Chinese numerals, …), attach a data-marker
 * attribute via node decoration, and display with CSS.
 * defs are written into storage by App when a document is opened/re-parsed; items without a definition fall back to CSS counters.
 */
// ── Live line-height factor + strut font-size ────────────────────────────────
// blockAttrs bakes --doc-line-factor and the strut font-size into toDOM output,
// but ProseMirror reuses a block's DOM while typing (sameMarkup ignores content),
// so a block edited after creation keeps its creation-time values until
// save/reopen. These node decorations recompute both from the live content on
// every doc change; unchanged nodes are structurally shared, so the WeakMap
// makes a pass cheap. Dropping font-size from a decoration removes the baked
// value too (ProseMirror's patchAttributes calls style.removeProperty for every
// property named in the previous decoration style).

const LINE_FACTOR_BLOCKS = new Set(['docParagraph', 'docHeading', 'docListItem'])
const lineFactorCache = new WeakMap<PmNode, string>()

// zero-width span whose CSS margin adds the half of Word's autoSpaceDE/DN gap
// that Chromium's text-autospace does not supply (see .doc-autospace-pad)
const autospacePadDom = () => {
  const span = document.createElement('span')
  span.className = 'doc-autospace-pad'
  return span
}

const autospaceOffsetsCache = new WeakMap<PmNode, number[]>()

const simsunGapCache = new WeakMap<PmNode, Array<{ from: number; to: number }>>()

/** ranges (relative to the block's content start) of ・/〜 in SimSun-substituted runs */
function simsunGapRanges(node: PmNode): Array<{ from: number; to: number }> {
  let ranges = simsunGapCache.get(node)
  if (ranges === undefined) {
    const found: Array<{ from: number; to: number }> = []
    let offset = 0
    node.forEach((child) => {
      if (child.isText && child.text && SIMSUN_GAP_CHAR_RE.test(child.text)) {
        const mark = child.marks.find((m) => m.type.name === 'docTextStyle')
        const family =
          mark?.attrs.eaSlotEmpty === true
            ? null
            : ((mark?.attrs.font ?? mark?.attrs.fontAscii) as string | null | undefined)
        if (family && simsunGapLineFactor(family) !== null) {
          for (let i = 0; i < child.text.length; i++) {
            if (SIMSUN_GAP_CHAR_RE.test(child.text[i])) {
              found.push({ from: offset + i, to: offset + i + 1 })
            }
          }
        }
      }
      offset += child.nodeSize
    })
    ranges = found
    simsunGapCache.set(node, ranges)
  }
  return ranges
}

/** offsets (relative to the block's content start) of CJK-Latin pad boundaries */
function autospaceOffsets(node: PmNode): number[] {
  let offsets = autospaceOffsetsCache.get(node)
  if (offsets === undefined) {
    const found: number[] = []
    let offset = 0
    let prevText = '' // reset by non-text inlines: pads need direct adjacency
    node.forEach((child) => {
      if (child.isText && child.text) {
        if (autospacePadBetween(prevText, child.text)) found.push(offset)
        for (const i of autospaceBoundaries(child.text)) found.push(offset + i)
        prevText = child.text
      } else {
        prevText = ''
      }
      offset += child.nodeSize
    })
    offsets = found
    autospaceOffsetsCache.set(node, offsets)
  }
  return offsets
}

function lineFactorDecos(doc: PmNode): DecorationSet {
  const decos: Decoration[] = []
  doc.descendants((node, pos) => {
    if (!LINE_FACTOR_BLOCKS.has(node.type.name)) return true
    if (node.textContent) {
      let style = lineFactorCache.get(node)
      if (style === undefined) {
        style = `--doc-line-factor:${paraLineFactor(node)}`
        const fam = paraDeclaredFontFamily(node)
        if (fam) style += `;font-family:${fam}`
        const strut = explicitStrutHalfPoints(node)
        if (strut) style += `;--doc-strut:${strut / 2}pt;font-size:min(var(--doc-strut), 1em)`
        lineFactorCache.set(node, style)
      }
      decos.push(Decoration.node(pos, pos + node.nodeSize, { style }))
      if (node.attrs.autoSpace !== false) {
        for (const off of autospaceOffsets(node)) {
          decos.push(Decoration.widget(pos + 1 + off, autospacePadDom, { key: 'doc-autospace' }))
        }
      }
      // ・/〜 in SimSun-substituted runs: Word lifts the whole line to 1.7143 ×
      // size (probe 2026-08-13); a taller inline strut reproduces the row lift.
      // exact lineRule pins the line, so no lift there.
      if (node.attrs.lineRule !== 'exact') {
        const ranges = simsunGapRanges(node)
        if (ranges.length > 0) {
          const m =
            Number(node.attrs.lineSpacing) ||
            (node.attrs.lineRule === 'auto' && node.attrs.lineRawTwips
              ? Number(node.attrs.lineRawTwips) / 240
              : 1)
          const gapStyle = `line-height:${cssSimsunGapLineExpr(m)}`
          for (const r of ranges) {
            decos.push(Decoration.inline(pos + 1 + r.from, pos + 1 + r.to, { style: gapStyle }))
          }
        }
      }
    }
    return false
  })
  return DecorationSet.create(doc, decos)
}

export const LineFactorExtension = Extension.create({
  name: 'lineFactorLive',
  addProseMirrorPlugins() {
    const key = new PluginKey<DecorationSet>('lineFactorLive')
    const editor = this.editor
    return [
      new Plugin<DecorationSet>({
        key,
        state: {
          init: (_config, state) => lineFactorDecos(state.doc),
          apply: (tr, old) => {
            if (tr.getMeta(key)) return lineFactorDecos(tr.doc)
            if (!tr.docChanged) return old
            // inserting pad widgets next to an active IME composition aborts it;
            // keep the old set mapped and refresh on compositionend
            if (editor?.view?.composing) return old.map(tr.mapping, tr.doc)
            return lineFactorDecos(tr.doc)
          },
        },
        props: {
          decorations(state) {
            return key.getState(state)
          },
          handleDOMEvents: {
            compositionend: (view) => {
              window.setTimeout(() => {
                if (!view.isDestroyed) view.dispatch(view.state.tr.setMeta(key, true))
              })
              return false
            },
          },
        },
      }),
    ]
  },
})

function firstRunSizeHalfPoints(node: PmNode): number | null {
  let sz: number | null = null
  node.descendants((child) => {
    if (sz !== null) return false
    if (child.isText) {
      const mark = child.marks.find((m) => m.type.name === 'docTextStyle')
      sz = (mark?.attrs.sizeHalfPoints as number | null) ?? null
      return false
    }
    return true
  })
  return sz
}

/** the font the ::before marker actually inherits: the item's [data-style] rule,
 *  else the .doc-page baseline (Normal / docDefaults) — same chain as doc-style-css */
function markerParagraphFont(
  styleId: unknown,
  storage: ListNumberingStorage,
): { family: string; sizeHalf: number; bold: boolean } {
  const style = typeof styleId === 'string' ? storage.styles?.get(styleId)?.display : undefined
  let normal: StyleDisplay | undefined
  for (const info of storage.styles?.values() ?? []) {
    if (info.isDefault && info.type === 'paragraph' && info.display) {
      normal = info.display
      break
    }
  }
  const dd = storage.docDefaults
  return {
    // ascii slot first: dual-slot font-family rules put the Latin face first,
    // and markers are Latin/digit text
    family:
      style?.fontAscii ??
      style?.font ??
      normal?.fontAscii ??
      dd?.asciiFont ??
      normal?.font ??
      dd?.eastAsiaFont ??
      'Calibri',
    sizeHalf: style?.sizeHalfPoints ?? normal?.sizeHalfPoints ?? dd?.sizeHalfPoints ?? 22,
    bold: style?.bold ?? normal?.bold ?? dd?.bold ?? false,
  }
}

let markerMeasureCtx: CanvasRenderingContext2D | null | undefined
/** marker advance in twips via canvas metrics; null in DOM-less test envs */
function measureMarkerTwips(
  text: string,
  family: string,
  sizePt: number,
  bold: boolean,
): number | null {
  if (markerMeasureCtx === undefined) {
    try {
      markerMeasureCtx = document.createElement('canvas').getContext('2d')
    } catch {
      markerMeasureCtx = null
    }
  }
  if (!markerMeasureCtx) return null
  const weight = bold ? '600 ' : ''
  markerMeasureCtx.font = `${weight}${(sizePt * 4) / 3}px "${family.replaceAll('"', '')}", Calibri, sans-serif`
  const w = markerMeasureCtx.measureText(text).width
  return Number.isFinite(w) && w > 0 ? Math.round(w * 15) : null
}

export const ListNumberingExtension = Extension.create<object, ListNumberingStorage>({
  name: 'listNumbering',
  addStorage() {
    return { defs: new Map<string, NumberingDef>() }
  },
  addProseMirrorPlugins() {
    const storage = this.storage
    const compute = (doc: PmNode): DecorationSet | null => {
      if (storage.defs.size === 0) return null
      const refs: ListItemRef[] = []
      const nodes: Array<{ pos: number; node: PmNode }> = []
      doc.descendants((node, pos) => {
        if (node.type.name === 'docListItem') {
          refs.push({
            numId: (node.attrs.numId as string | null) ?? null,
            ilvl: Number(node.attrs.ilvl) || 0,
          })
          nodes.push({ pos, node })
          return false
        }
        return true
      })
      if (refs.length === 0) return null
      const markers = computeListMarkerInfos(refs, storage.defs)
      const decos: Decoration[] = []
      markers.forEach((marker, i) => {
        if (marker === null) return
        const styles: string[] = []
        let text = marker.text
        if (marker.symbolFont && marker.symbolChar) {
          if (symbolFontCovers(marker.symbolFont, marker.symbolChar)) {
            text = marker.symbolChar
            styles.push(`--li-marker-font:"${marker.symbolFont}"`)
          } else {
            // substitute glyph: pin a Latin font (CJK fallback draws ・) and compensate its smaller bullet;
            // --li-marker-lh:0 keeps the scaled em box from stretching the line
            styles.push(`--li-marker-font:Arial,'Helvetica Neue',sans-serif`)
            const scale = bulletMarkerScale(text)
            if (scale !== 1) styles.push(`--li-marker-scale:${scale}`, '--li-marker-lh:0')
          }
        }
        const attrs: Record<string, string> = { 'data-marker': text }
        // geometry fallback: when the paragraph has no w:ind of its own, use the numbering.xml level's indent;
        // marker font size comes from the level's rPr, else follows the item's first text run (Word rule)
        const def = refs[i].numId !== null ? storage.defs.get(refs[i].numId as string) : undefined
        const level = def?.levels[Math.max(0, refs[i].ilvl)]
        if (level) {
          const nodeAttrs = nodes[i].node.attrs
          if (!nodeAttrs.indentLeft && level.indentLeft) {
            styles.push(`--li-left:${level.indentLeft / 20}pt`)
          }
          if (!nodeAttrs.indentFirstLine && level.hanging) {
            styles.push(`--li-hang:${level.hanging / 20}pt`)
          }
          const szHalf = level.szHalfPoints ?? firstRunSizeHalfPoints(nodes[i].node) ?? undefined
          if (szHalf) styles.push(`--li-marker-size:${szHalf / 2}pt`)
          if (level.suff === 'space' || level.suff === 'nothing') attrs['data-suff'] = level.suff

          // Word's default tab after the marker: a marker that escapes the hanging
          // area (or a level with positive w:firstLine) pushes first-line text to
          // the next default tab stop, not right up against the marker
          if (level.suff === undefined || level.suff === 'tab') {
            const leftTw = Number(nodeAttrs.indentLeft) || level.indentLeft || 0
            const nodeFirst = Number(nodeAttrs.indentFirstLine) || 0
            if (leftTw > 0 && nodeFirst <= 0 && text) {
              const hangTw =
                nodeFirst < 0
                  ? -nodeFirst
                  : level.firstLine
                    ? -level.firstLine
                    : (level.hanging ?? 360)
              // no level/run size -> the marker renders at the li's 1em; family always
              // inherits from the li (level.font only applies to symbol bullets)
              const para = markerParagraphFont(nodeAttrs.styleId, storage)
              const widthTw = measureMarkerTwips(
                text,
                para.family,
                (szHalf ?? para.sizeHalf) / 2,
                para.bold,
              )
              const adv =
                widthTw !== null ? markerTabAdvance(leftTw - hangTw, widthTw, leftTw) : null
              if (adv !== null) {
                if (hangTw < 0) styles.push(`--li-hang:${hangTw / 20}pt`)
                styles.push(`--li-tab:${adv / 20}pt`)
              }
            }
          }
        }
        if (styles.length > 0) attrs.style = styles.join(';')
        decos.push(Decoration.node(nodes[i].pos, nodes[i].pos + nodes[i].node.nodeSize, attrs))
      })
      return DecorationSet.create(doc, decos)
    }

    interface CachedMarkers {
      defs: Map<string, NumberingDef>
      decos: DecorationSet | null
    }
    const key = new PluginKey<CachedMarkers>('listNumbering')
    return [
      new Plugin<CachedMarkers>({
        key,
        state: {
          init: (_config, state) => ({ defs: storage.defs, decos: compute(state.doc) }),
          apply(tr, old) {
            // defs is replaced (never mutated) on open/reparse and marker overlay
            if (tr.docChanged || old.defs !== storage.defs)
              return { defs: storage.defs, decos: compute(tr.doc) }
            return old.decos ? { defs: old.defs, decos: old.decos.map(tr.mapping, tr.doc) } : old
          },
        },
        props: {
          decorations(state) {
            return key.getState(state)?.decos ?? null
          },
        },
      }),
    ]
  },
})

const tableCellAttrs = {
  vAlign: { default: null as string | null },
  borders: { default: null as Record<string, unknown> | null },
  rawTcPr: { default: null as string | null },
  /** tcPr w:cellIns/w:cellDel cell revision ({kind, author, ...} | null) */
  cellRevision: { default: null as Record<string, string> | null },
  cellMar: { default: null as Record<string, number> | null },
  textDirection: { default: null as string | null },
  /** inner clip-box height (twips) when the row is hRule="exact" (computed in convert.ts) */
  clipHeightTwips: { default: null as number | null },
  /** display placeholder for the row's w:gridBefore/w:gridAfter columns (borderless, not saved as w:tc) */
  gridGap: { default: false },
  colspan: { default: 1 },
  rowspan: { default: 1 },
  colwidth: { default: null as number[] | null },
  fill: { default: null as string | null },
  color: { default: null as string | null },
  bold: { default: false },
  align: { default: null as string | null },
}

/** One OOXML border → CSS border value; 'none' means explicitly borderless */
export function borderLineCss(
  b: { style: string; szEighths?: number; color?: string } | undefined | null,
): string | null {
  if (!b) return null
  if (b.style === 'none' || b.style === 'nil') return 'none'
  const px = Math.max(1, Math.round(((b.szEighths ?? 4) / 8 / 72) * 96))
  const dash =
    b.style === 'dashed'
      ? 'dashed'
      : b.style === 'dotted'
        ? 'dotted'
        : b.style === 'double'
          ? 'double'
          : 'solid'
  const color = b.color && b.color !== 'auto' ? `#${b.color}` : '#000'
  return `${px}px ${dash} ${color}`
}

function tableCellHtml(node: PmNode): Record<string, string> {
  const attrs: Record<string, string> = {}
  // gap placeholders never save back as w:tc, so typed text would vanish — keep them inert
  if (node.attrs.gridGap) attrs.contenteditable = 'false'
  if (node.attrs.colspan > 1) attrs.colspan = String(node.attrs.colspan)
  if (node.attrs.rowspan > 1) attrs.rowspan = String(node.attrs.rowspan)
  if (node.attrs.colwidth) attrs['data-colwidth'] = (node.attrs.colwidth as number[]).join(',')
  const borderCss = (side: string): string => {
    const v = borderLineCss(
      (
        node.attrs.borders as Record<
          string,
          { style: string; szEighths?: number; color?: string }
        > | null
      )?.[side],
    )
    return v ? `border-${side}:${v}` : ''
  }
  const mar = node.attrs.cellMar as Record<string, number> | null
  const styles = [
    // gridBefore/gridAfter placeholder: bare grid space (inline border beats the --doc-b-* cell rules)
    node.attrs.gridGap ? 'border:none;background:none' : '',
    // vertical-text cells: tbRl = vertical right-to-left (vertical-rl), btLr = rotated 90° counterclockwise (sideways-lr)
    node.attrs.textDirection === 'tbRl'
      ? 'writing-mode:vertical-rl'
      : node.attrs.textDirection === 'btLr'
        ? 'writing-mode:sideways-lr'
        : '',
    // font-weight before background: jsdom's CSSOM drops the background getter
    // when font-weight follows it (order is irrelevant to real browsers)
    node.attrs.bold ? 'font-weight:600' : '',
    node.attrs.color ? `color:#${node.attrs.color}` : '',
    node.attrs.fill ? `background:#${node.attrs.fill}` : '',
    node.attrs.align ? `text-align:${node.attrs.align}` : '',
    node.attrs.vAlign && node.attrs.vAlign !== 'top'
      ? `vertical-align:${node.attrs.vAlign === 'center' ? 'middle' : 'bottom'}`
      : '',
    borderCss('top'),
    borderCss('left'),
    borderCss('bottom'),
    borderCss('right'),
    // tcMar only overrides declared sides; the rest inherit the table-level --doc-cell-pad
    ...['top', 'left', 'bottom', 'right'].map((side) =>
      mar?.[side] !== undefined ? `padding-${side}:${(mar[side] / 15).toFixed(1)}px` : '',
    ),
    Array.isArray(node.attrs.colwidth)
      ? `width:${(node.attrs.colwidth as number[]).reduce((sum, width) => sum + width, 0)}px`
      : '',
  ].filter(Boolean)
  if (styles.length > 0) attrs.style = styles.join(';')
  const cellRev = node.attrs.cellRevision as { kind?: string; author?: string } | null
  if (cellRev?.kind) {
    attrs.class = `cell-rev-${cellRev.kind}`
    if (cellRev.author) attrs.title = cellRev.author
  }
  return attrs
}

/** exact-height rows clip via a fixed-height inner box: td height is min-height
 *  semantics in CSS table layout, so the td itself can never produce overflow */
export function cellClipStyle(vAlign: string | null, clipTwips: number): string {
  return [
    `height:${(clipTwips / 15).toFixed(1)}px`,
    // replicate the td's vertical-align inside the fixed box (the box fills the cell);
    // 'safe' falls back to start when content overflows — Word keeps the top and clips
    // the bottom edge regardless of vAlign
    ...(vAlign === 'center'
      ? ['display:grid', 'align-content:safe center']
      : vAlign === 'bottom'
        ? ['display:grid', 'align-content:safe end']
        : []),
  ].join(';')
}

function tableCellSpec(tag: 'td' | 'th', node: PmNode): DOMOutputSpec {
  const attrs = tableCellHtml(node)
  const clip = node.attrs.clipHeightTwips as number | null
  // 0 is a real clip height (padding/borders consume the whole exact row)
  if (clip == null) return [tag, attrs, 0]
  return [
    tag,
    attrs,
    ['div', { class: 'cell-clip', style: cellClipStyle(node.attrs.vAlign, clip) }, 0],
  ]
}

export type TableBordersAttr = Partial<
  Record<
    'top' | 'left' | 'bottom' | 'right' | 'insideH' | 'insideV',
    { style: string; szEighths?: number; color?: string }
  >
>

/**
 * Table-level w:tblBorders → CSS variables consumed by edge/inside cell rules
 * (--doc-b-t/r/b/l on edge cells beat the inside lines even when the frame is
 * explicitly none). Undeclared = no borders, matching Word's printed output.
 */
export function tableBordersCss(b: TableBordersAttr | null): string[] {
  if (!b) return []
  const styles: string[] = []
  const edge = { top: 't', right: 'r', bottom: 'b', left: 'l' } as const
  for (const side of ['top', 'right', 'bottom', 'left'] as const) {
    styles.push(`--doc-b-${edge[side]}:${borderLineCss(b[side]) ?? 'none'}`)
  }
  styles.push(`--doc-b-h:${borderLineCss(b.insideH) ?? 'none'}`)
  styles.push(`--doc-b-v:${borderLineCss(b.insideV) ?? 'none'}`)
  return styles
}

/** Table-level w:tblCellMar → padding shorthand; undeclared sides use Word defaults (0 top/bottom, 108 twips left/right) */
export function cellPadCss(
  mar: { top?: number; right?: number; bottom?: number; left?: number } | null,
): string | null {
  if (!mar) return null
  const px = (v: number | undefined, dflt: number) => ((v ?? dflt) / 15).toFixed(1)
  return `${px(mar.top, 0)}px ${px(mar.right, 108)}px ${px(mar.bottom, 0)}px ${px(mar.left, 108)}px`
}

export const DocTable = Node.create({
  name: 'docTable',
  group: 'block',
  content: 'docTableRow+',
  isolating: true,
  selectable: true,
  draggable: true,
  addAttributes() {
    return {
      docxIndex: { default: null as number | null },
      colWidthsPct: { default: null as number[] | null },
      widthPx: { default: null as number | null },
      widthPct: { default: null as number | null },
      cellMar: { default: null as Record<string, number> | null },
      /** w:tblCellSpacing (twips, half the inter-cell gap) → CSS border-spacing */
      cellSpacingTwips: { default: null as number | null },
      /** table shading (tblPr w:shd), hex without '#' */
      tblFill: { default: null as string | null },
      cellMarEdited: { default: false },
      borders: { default: null as Record<string, unknown> | null },
      tblAlign: { default: null as string | null },
      tblFloat: { default: null as string | null },
      tblFloatSource: { default: null as string | null },
      tblFloatSuppressed: { default: false },
      tblFloatXTwips: { default: null as number | null },
      tblFloatYTwips: { default: null as number | null },
      tblFloatHorzAnchor: { default: null as string | null },
      tblFloatVertAnchor: { default: null as string | null },
      tblFloatDistance: { default: null as Record<string, number> | null },
      /** display-only measured width used to place right AutoFit floats */
      tblFloatWidthPx: { default: null as number | null },
      tblFloatEdited: { default: false },
      tblAutoFit: { default: 'fixed' as 'contents' | 'window' | 'fixed' },
      tblAutoFitEdited: { default: false },
      indentTwips: { default: null as number | null },
      tblStyleId: { default: null as string | null },
      tblLook: { default: null as Record<string, boolean> | null },
      tblLookEdited: { default: false },
      /** SDT shell JSON when the table is a content-control member (chrome hit-testing) */
      sdtShell: { default: null as string | null },
      /** RTL table (tblPr w:bidiVisual): columns right to left */
      bidiVisual: { default: false },
      originalStructure: { default: null as string | null },
      originalFormatting: { default: null as string | null },
      blockRevision: { default: null as Record<string, string> | null },
    }
  },
  parseHTML() {
    return [{ tag: 'table.doc-table' }, { tag: 'table' }]
  },
  renderHTML({ node }) {
    const attrs: Record<string, string> = { class: 'doc-table' }
    if (node.attrs.docxIndex !== null) attrs['data-idx'] = String(node.attrs.docxIndex)
    if (node.attrs.tblStyleId) attrs['data-tbl-style'] = String(node.attrs.tblStyleId)
    const autoFit = node.attrs.tblAutoFit as 'contents' | 'window' | 'fixed'
    // Imported auto-layout tables may carry a display-only expanded width from
    // the fidelity pass. Keep that measured grid until the user explicitly
    // chooses AutoFit Contents (the command clears widthPx).
    const displayAutoFit = autoFit === 'contents' && node.attrs.widthPx ? 'fixed' : autoFit
    attrs.class += ` doc-table-autofit-${displayAutoFit}`
    const tblFloated =
      !node.attrs.tblFloatSuppressed &&
      (node.attrs.tblFloat === 'left' || node.attrs.tblFloat === 'right')
    if (tblFloated) attrs.class += ` doc-table-float-${node.attrs.tblFloat}`
    if (node.attrs.bidiVisual) attrs.dir = 'rtl'
    const styles: string[] = []
    let centerMargin: string | null = null
    if (displayAutoFit === 'contents') styles.push('width:auto')
    else if (displayAutoFit === 'window') styles.push('width:100%')
    else if (node.attrs.widthPct) styles.push(`width:${Number(node.attrs.widthPct)}%`)
    // Over-wide grids may spill into the page margins like Word/LO (clamping
    // them to the content box narrowed every column, wrapped cell text onto extra
    // lines and inflated PDF-converted documents by pages), but never past the paper:
    // centered tables spill both margins symmetrically (negative-margin centering —
    // auto margins resolve to 0 on overflow and would push the spill right only),
    // left-aligned ones spill right; indent comes out of the spill allowance
    else if (node.attrs.widthPx) {
      const widthPx = Number(node.attrs.widthPx)
      // --doc-content-w: per-block section content width (differing-width sections); defaults to the page content box
      const contentW = 'var(--doc-content-w,100%)'
      if (node.attrs.tblAlign === 'center' && !tblFloated) {
        const paper = `calc(${contentW} + var(--doc-margin-left,var(--doc-margin-right,0px)) + var(--doc-margin-right,0px))`
        styles.push(`width:min(${widthPx}px,${paper})`)
        centerMargin = `margin-left:calc((${contentW} - min(${widthPx}px,${paper}))/2)`
      } else {
        const indented =
          !tblFloated && node.attrs.tblAlign !== 'right' && Number(node.attrs.indentTwips) > 0
        const indentPx = indented ? Number(node.attrs.indentTwips) / 15 : 0
        const spill = indentPx
          ? `calc(${contentW} + var(--doc-margin-right,0px) - ${indentPx.toFixed(1)}px)`
          : `calc(${contentW} + var(--doc-margin-right,0px))`
        styles.push(`width:min(${widthPx}px,${spill})`)
      }
    }
    const pad = cellPadCss(node.attrs.cellMar as Record<string, number> | null)
    if (pad) styles.push(`--doc-cell-pad:${pad}`)
    // w:tblCellSpacing: each cell contributes the value on its side, so the CSS
    // gap between cells is twice it; cells render individually boxed like Word
    if (node.attrs.cellSpacingTwips) {
      const gapPx = ((Number(node.attrs.cellSpacingTwips) * 2) / 15).toFixed(1)
      styles.push('border-collapse:separate', `border-spacing:${gapPx}px`)
    }
    if (node.attrs.tblFill) styles.push(`background-color:#${node.attrs.tblFill}`)
    styles.push(...tableBordersCss(node.attrs.borders as TableBordersAttr | null))
    // w:tblpPr positioning supersedes w:jc / w:tblInd: alignment or indent
    // margins would override the float stylesheet's wrap gaps
    if (tblFloated) {
      const distance = (node.attrs.tblFloatDistance as Record<string, number> | null) ?? {}
      const px = (twips: unknown): number => (Number(twips) || 0) / 15
      const x = px(node.attrs.tblFloatXTwips)
      const y = px(node.attrs.tblFloatYTwips)
      const top = y + Math.max(0, px(distance.top))
      const bottom = Math.max(0, px(distance.bottom))
      const left = Math.max(0, px(distance.left))
      const right = Math.max(0, px(distance.right))
      if (top) styles.push(`margin-top:${top.toFixed(1)}px`)
      if (bottom) styles.push(`margin-bottom:${bottom.toFixed(1)}px`)
      if (node.attrs.tblFloat === 'left') {
        if (x) styles.push(`margin-left:${x.toFixed(1)}px`)
        if (right) styles.push(`margin-right:${right.toFixed(1)}px`)
      } else {
        if (left) styles.push(`margin-left:${left.toFixed(1)}px`)
        const width = Number(node.attrs.widthPx) || Number(node.attrs.tblFloatWidthPx)
        if (node.attrs.tblFloatXTwips != null && width > 0) {
          styles.push(
            `margin-right:max(0px,calc(var(--doc-content-w,100%) - ${x.toFixed(1)}px - ${width.toFixed(1)}px))`,
          )
        }
      }
    } else if (node.attrs.tblAlign === 'center') {
      if (centerMargin) styles.push(centerMargin)
      else styles.push('margin-left:auto', 'margin-right:auto')
    } else if (node.attrs.tblAlign === 'right') styles.push('margin-left:auto')
    else if (node.attrs.indentTwips) {
      styles.push(`margin-left:${(Number(node.attrs.indentTwips) / 15).toFixed(1)}px`)
    }
    if (styles.length > 0) attrs.style = styles.join(';')
    // A colgroup with normalized percentages defines the column grid whenever the
    // pct list matches the grid, so a table clamped to the content box compresses
    // its columns proportionally instead of overflowing via fixed td px widths.
    let firstRowCols = 0
    node.firstChild?.forEach((cell) => {
      firstRowCols += Number(cell.attrs.colspan) || 1
    })
    const rawPct = node.attrs.colWidthsPct as number[] | null
    if (displayAutoFit !== 'contents' && rawPct?.length) {
      // zero-width grid slots get a small floor, short grids pad with the average —
      // dropping the whole colgroup falls back to fixed-layout even splitting, which
      // is always worse than an approximate grid
      const pct = rawPct.map((w) => (w > 0 ? w : 0.5))
      const avg = pct.reduce((sum, w) => sum + w, 0) / pct.length
      while (pct.length < firstRowCols) pct.push(avg)
      const total = pct.reduce((sum, w) => sum + w, 0) || 100
      return [
        'table',
        attrs,
        [
          'colgroup',
          {},
          ...pct.map(
            (w) => ['col', { style: `width:${((w / total) * 100).toFixed(2)}%` }] as const,
          ),
        ],
        ['tbody', 0],
      ]
    }
    return ['table', attrs, ['tbody', 0]]
  },
})

export const DocTableRow = Node.create({
  name: 'docTableRow',
  content: '(docTableCell | docTableHeader)+',
  addAttributes() {
    return {
      heightTwips: { default: null as number | null },
      heightRule: { default: null as 'atLeast' | 'exact' | null },
      repeatHeader: { default: false },
      repeatHeaderEdited: { default: false },
      rawTrPr: { default: null as string | null },
      /** trPr w:ins/w:del row-level revision ({kind, author, ...} | null) */
      rowRevision: { default: null as Record<string, string> | null },
    }
  },
  parseHTML() {
    return [{ tag: 'tr' }]
  },
  renderHTML({ node }) {
    const h = node.attrs.heightTwips as number | null
    const rev = node.attrs.rowRevision as { kind?: string; author?: string } | null
    const attrs: Record<string, string> = {}
    const classes: string[] = []
    if (h) {
      attrs.style = `height:${((h / 1440) * 96).toFixed(1)}px`
      if (node.attrs.heightRule === 'exact') classes.push('row-h-exact')
    }
    attrs['data-repeat-header'] = node.attrs.repeatHeader ? '1' : '0'
    if (rev?.kind) {
      classes.push(`row-rev-${rev.kind}`)
      if (rev.author) attrs.title = rev.author
    }
    if (classes.length > 0) attrs.class = classes.join(' ')
    return ['tr', attrs, 0]
  },
})

export const DocTableCell = Node.create({
  name: 'docTableCell',
  content: '(docParagraph | docListItem | docNestedTable | docCellBoxes)+',
  isolating: true,
  addAttributes() {
    return tableCellAttrs
  },
  parseHTML() {
    return [{ tag: 'td' }]
  },
  renderHTML({ node }) {
    return tableCellSpec('td', node)
  },
})

export const DocTableHeader = Node.create({
  name: 'docTableHeader',
  content: '(docParagraph | docListItem | docNestedTable | docCellBoxes)+',
  isolating: true,
  addAttributes() {
    return tableCellAttrs
  },
  parseHTML() {
    return [{ tag: 'th' }]
  },
  renderHTML({ node }) {
    return tableCellSpec('th', node)
  },
})

/** Anchored shapes/textboxes inside a table cell (display-only): Word renders them
 *  in the cell and grows the row to hold them, so the wrapper takes the boxes'
 *  bottom extent as in-flow height (pagination then pushes the row like Word) */
export const DocCellBoxes = Node.create({
  name: 'docCellBoxes',
  atom: true,
  selectable: false,
  addAttributes() {
    return { boxes: { default: null as TextboxDisplay[] | null } }
  },
  parseHTML() {
    return []
  },
  renderHTML({ node }) {
    const boxes = (node.attrs.boxes as TextboxDisplay[] | null) ?? []
    if (boxes.length === 0) return ['div', { class: 'doc-cell-boxes' }]
    let bottom = 0
    for (const b of boxes) {
      bottom = Math.max(
        bottom,
        (b.offsetYEmu ?? 0) / EMU_PER_PX + (b.heightPx ?? b.minHeightPx ?? 0),
      )
    }
    return [
      'div',
      {
        class: 'doc-cell-boxes',
        contenteditable: 'false',
        // zero-width leading float: the cell (a BFC) grows to max(text, boxes)
        // like Word, without displacing the cell's own text
        style: bottom > 0 ? `height:${bottom.toFixed(1)}px` : '',
      },
      // floating boxes self-position from their anchor offsets; in-flow boxes get
      // the same offsets via a positioned wrapper (Word places both in the cell)
      ...boxes.map((b): DomSpec => {
        const spec = renderTextboxSpec(b)
        if (b.floating) return spec
        const left = (b.offsetXEmu ?? 0) / EMU_PER_PX
        const top = (b.offsetYEmu ?? 0) / EMU_PER_PX
        return [
          'div',
          { style: `position:absolute;left:${left.toFixed(1)}px;top:${top.toFixed(1)}px` },
          spec,
        ]
      }),
    ]
  },
})

/** Nested table inside a cell: read-only atomic child table (editing the outer cell's text
 *  doesn't affect it; saving is byte-faithful via the outer table's originalXml, dropped on structural rebuild — matching old behavior) */
export const DocNestedTable = Node.create({
  name: 'docNestedTable',
  atom: true,
  selectable: false,
  addAttributes() {
    return { model: { default: null as TableModel | null } }
  },
  parseHTML() {
    return []
  },
  renderHTML({ node }) {
    const model = node.attrs.model as TableModel | null
    if (!model?.rows?.length) return ['div', { class: 'doc-nested-table' }]
    return [
      'div',
      { class: 'doc-nested-table', contenteditable: 'false' },
      renderTableSpec(model, true),
    ]
  },
  // in-place cell editing: contenteditable island; on blur the text is committed back to the model attribute
  // (saving goes through the outer table's nested-text surgical patch; cells that themselves contain nested tables stay non-editable)
  addNodeView() {
    return ({ node, editor, getPos }) => {
      let currentNode = node
      const dom = document.createElement('div')
      dom.className = 'doc-nested-table'
      dom.setAttribute('contenteditable', 'false')

      /** this table's own td elements (excluding deeper nested-table td), ordered like the model's non-vMerge-continue cells */
      const ownTds = (): HTMLElement[] => {
        const root = dom.querySelector('table')
        if (!root) return []
        return Array.from(dom.querySelectorAll('td')).filter((td) => td.closest('table') === root)
      }

      const flatCells = (): TableCell[] => {
        const model = currentNode.attrs.model as TableModel | null
        const flat: TableCell[] = []
        model?.rows.forEach((row) =>
          row.forEach((cell) => {
            if (cell.vMerge !== 'continue') flat.push(cell)
          }),
        )
        return flat
      }

      const applyEditable = () => {
        const cells = flatCells()
        ownTds().forEach((td, i) => {
          const editable = editor.isEditable && cells[i] && !cells[i].nestedTables?.length
          td.setAttribute('contenteditable', editable ? 'true' : 'false')
        })
      }

      const render = () => {
        dom.innerHTML = ''
        const model = currentNode.attrs.model as TableModel | null
        if (model?.rows?.length) {
          const rendered = DOMSerializer.renderSpec(document, renderTableSpec(model, true) as never)
          dom.appendChild(rendered.dom)
        }
        applyEditable()
      }
      render()

      const commit = () => {
        const model = currentNode.attrs.model as TableModel | null
        if (!model) return
        const tds = ownTds()
        let k = 0
        let changed = false
        const rows = model.rows.map((row) =>
          row.map((cell) => {
            if (cell.vMerge === 'continue') return cell
            const td = tds[k++]
            if (!td || cell.nestedTables?.length) return cell
            const paras = tdParas(td)
            if (paras.join('\n') === cell.paras.join('\n')) return cell
            changed = true
            const next = { ...cell, paras }
            delete next.richParas
            return next
          }),
        )
        if (!changed) return
        const pos = getPos()
        if (typeof pos !== 'number') return
        editor.view.dispatch(
          editor.view.state.tr.setNodeMarkup(pos, undefined, { model: { ...model, rows } }),
        )
      }

      const onFocusOut = (e: Event) => {
        const next = (e as FocusEvent).relatedTarget as HTMLElement | null
        if (next && dom.contains(next)) return
        commit()
      }
      dom.addEventListener('focusout', onFocusOut)
      window.addEventListener('ai-docs-commit-tables', commit)
      editor.on('update', applyEditable)

      return {
        dom,
        update: (n: PmNode) => {
          if (n.type.name !== 'docNestedTable') return false
          if (!n.eq(currentNode)) {
            currentNode = n
            render()
          } else {
            currentNode = n
          }
          return true
        },
        // edits stay in the DOM until the focusout commit; don't let ProseMirror re-parse them
        ignoreMutation: () => true,
        stopEvent: (event: Event) => {
          const target = event.target as HTMLElement | null
          return !!target?.closest?.('td[contenteditable="true"]')
        },
        destroy: () => {
          window.removeEventListener('ai-docs-commit-tables', commit)
          editor.off('update', applyEditable)
        },
      }
    }
  },
})

/** Delete only an explicitly selected whole table; leave cursors and partial cell selections alone. */
export function deleteSelectedWholeTable(
  state: EditorState,
  dispatch?: (transaction: Transaction) => void,
): boolean {
  const { selection } = state
  if (selection instanceof NodeSelection) {
    if (selection.node.type.spec.tableRole !== 'table') return false
    dispatch?.(state.tr.delete(selection.from, selection.to).scrollIntoView())
    return true
  }
  if (
    selection instanceof CellSelection &&
    selection.isRowSelection() &&
    selection.isColSelection()
  ) {
    return deleteTable(state, dispatch)
  }
  return false
}

export const NativeTableSupport = Extension.create({
  name: 'nativeTableSupport',
  extendNodeSchema(extension) {
    if (extension.name === 'docTable') return { tableRole: 'table' }
    if (extension.name === 'docTableRow') return { tableRole: 'row' }
    if (extension.name === 'docTableCell') return { tableRole: 'cell' }
    if (extension.name === 'docTableHeader') return { tableRole: 'header_cell' }
    return {}
  },
  addKeyboardShortcuts() {
    const deleteWholeTable = () =>
      deleteSelectedWholeTable(this.editor.state, this.editor.view.dispatch)
    return {
      Tab: () => {
        const { view } = this.editor
        if (goToNextCell(1)(this.editor.state, view.dispatch)) return true
        // last cell: Word appends a row and moves into its first cell
        if (!isInTable(this.editor.state)) return false
        if (!addRowAfter(this.editor.state, view.dispatch)) return false
        return goToNextCell(1)(this.editor.state, view.dispatch)
      },
      'Shift-Tab': () => goToNextCell(-1)(this.editor.state, this.editor.view.dispatch),
      Backspace: deleteWholeTable,
      Delete: deleteWholeTable,
    }
  },
  addProseMirrorPlugins() {
    return [
      new Plugin({
        props: {
          handleDOMEvents: {
            mouseup: (view) => {
              const resizeState = columnResizingPluginKey.getState(view.state) as
                { dragging?: unknown; activeHandle?: number } | undefined
              if (resizeState?.dragging == null) return false
              const handle = resizeState.activeHandle ?? -1
              if (handle < 0) return false
              // The resize plugin commits its final width in its window-level mouseup,
              // which runs after this handler and its microtasks; wait a macrotask so
              // the committed grid, not the previous drag frame, is constrained.
              window.setTimeout(() => {
                const raw = getComputedStyle(view.dom).getPropertyValue('--section-content-w')
                const maxWidth = Number.parseFloat(raw)
                if (Number.isFinite(maxWidth) && maxWidth > 0) {
                  constrainTableWidthAtCell(handle, maxWidth)(view.state, view.dispatch)
                }
              }, 0)
              return false
            },
          },
        },
      }),
      columnResizing({ View: null, cellMinWidth: 40, lastColumnResizable: true }),
      tableEditing({ allowTableNodeSelection: true }),
    ]
  },
})

/** Protected whole-unit blocks: images, passthrough (charts, math, ...). */
/**
 * Copying an embedded picture must put a REAL bitmap on the OS clipboard:
 * ProseMirror's HTML-only write left external apps with nothing to paste
 * (Gmail: blank) and other documents with a placeholder shell (r136). The
 * main process writes image + <img> html; in-document paste rebuilds the
 * picture through DocProtected's img parse rule.
 */
/** formats pmDocToSavePlan can rebuild into the docx (see imageFromProtectedAttrs) */
const PERSISTABLE_IMAGE_URL = /^data:image\/(?:png|jpeg|gif);base64,/

/** display attrs a copied picture needs to round-trip through clipboard HTML */
const imageMetaJson = (attrs: Record<string, unknown>): string =>
  JSON.stringify({
    imageWidthPx: attrs.imageWidthPx ?? null,
    imageHeightPx: attrs.imageHeightPx ?? null,
    imageAlign: attrs.imageAlign ?? null,
    imageWrap: attrs.imageWrap ?? null,
  })

export const ImageCopyExtension = Extension.create({
  name: 'imageClipboardCopy',
  addProseMirrorPlugins() {
    const copyImage = (view: EditorView, event: ClipboardEvent, cut: boolean): boolean => {
      const sel = view.state.selection
      if (!(sel instanceof NodeSelection)) return false
      const node = sel.node
      if (node.type.name !== 'docProtected' || node.attrs.blockType !== 'image') return false
      let dataUrl = node.attrs.imageDataUrl
      if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) return false
      // the save pipeline persists only png/jpeg/gif; display-only formats
      // (bmp/webp/svg/tiff...) are transcoded to PNG from the already-decoded
      // DOM img so the copy stays saveable — undecodable ones keep the
      // default HTML copy
      if (!PERSISTABLE_IMAGE_URL.test(dataUrl)) {
        const dom = view.nodeDOM(sel.from) as HTMLElement | null
        const img = dom?.querySelector?.('img.doc-protected-img') as HTMLImageElement | null
        if (!img || !img.naturalWidth || !img.naturalHeight) return false
        const canvas = document.createElement('canvas')
        canvas.width = img.naturalWidth
        canvas.height = img.naturalHeight
        const ctx = canvas.getContext('2d')
        if (!ctx) return false
        ctx.drawImage(img, 0, 0)
        try {
          dataUrl = canvas.toDataURL('image/png')
        } catch {
          return false
        }
      }
      const write = window.desktop?.copyImageToClipboard?.(dataUrl, imageMetaJson(node.attrs))
      // no bridge: keep the default HTML-only copy instead of an empty clipboard
      if (!write) return false
      event.preventDefault()
      // cut deletes only AFTER the clipboard write is confirmed, and only if
      // the same picture is still selected — a failed write must not lose data
      void write.then((ok) => {
        if (!ok || !cut || !view.editable) return
        const cur = view.state.selection
        if (cur instanceof NodeSelection && cur.from === sel.from && cur.node === node) {
          view.dispatch(view.state.tr.deleteSelection().scrollIntoView())
        }
      })
      return true
    }
    return [
      new Plugin({
        key: new PluginKey('imageClipboardCopy'),
        props: {
          handleDOMEvents: {
            copy: (view, event) => copyImage(view, event as ClipboardEvent, false),
            cut: (view, event) => copyImage(view, event as ClipboardEvent, true),
          },
        },
      }),
    ]
  },
})

export const DocProtected = Node.create({
  name: 'docProtected',
  group: 'block',
  atom: true,
  // Editable descendants switch this off on pointer-down; the explicit handle
  // switches it back on for whole-object movement.
  draggable: true,
  selectable: true,
  addAttributes() {
    return {
      docxIndex: { default: null as number | null },
      blockRevision: { default: null as Record<string, string> | null },
      blockType: { default: 'passthrough' },
      /** w:pStyle of field/TOC paragraphs: doc style CSS (spacing/line-height) targets data-style */
      styleId: { default: null as string | null },
      label: { default: '' },
      previewText: { default: '' },
      imageDataUrl: { default: null as string | null },
      oleProgId: { default: null as string | null },
      /** display size in CSS px (blockType === 'image'), editable via drag handles */
      imageWidthPx: { default: null as number | null },
      imageHeightPx: { default: null as number | null },
      /** source crop (a:srcRect) fractions, display-only */
      imageCrop: { default: null as { l: number; t: number; r: number; b: number } | null },
      /** fill placement (a:fillRect) fractions (negative = bleed), display-only */
      imageFillRect: { default: null as { l: number; t: number; r: number; b: number } | null },
      imageLeadingText: { default: null as string | null },
      imageLeadingFont: { default: null as string | null },
      imageLeadingExplicitSpaceWidthPx: { default: null as number | null },
      imageLeadingImplicitSpaceCount: { default: null as number | null },
      imageParagraphIndentLeft: { default: null as number | null },
      imageParagraphIndentRight: { default: null as number | null },
      imageParagraphIndentFirstLine: { default: null as number | null },
      /** paragraph alignment of the image (w:jc) */
      imageAlign: { default: null as string | null },
      imageWrap: { default: null as string | null },
      imageWrapDistTopEmu: { default: null as number | null },
      imageWrapDistBottomEmu: { default: null as number | null },
      imageWrapDistLeftEmu: { default: null as number | null },
      imageWrapDistRightEmu: { default: null as number | null },
      /**
       * Stacking rank of a floating image among overlapping anchors
       * (bring-to-front / send-to-back). Written to the anchor's
       * relativeHeight; higher paints in front. Null = base level.
       */
      imageZOrder: { default: null as number | null },
      /**
       * Free-position offset (EMU) of a floating image with wp:posOffset.
       * Used for drag-to-reposition. Null when the image uses named alignment
       * or is inline.
       */
      imageOffsetXEmu: { default: null as number | null },
      /** wp:anchor locked="1": keep the anchor paragraph fixed while dragging */
      imageAnchorLocked: { default: false },
      /** margin-relative wp:align preset (Word position gallery) */
      imagePosH: { default: null as string | null },
      imagePosV: { default: null as string | null },
      imageOffsetYEmu: { default: null as number | null },
      /** display-only table structure (blockType === 'table') */
      table: { default: null as TableModel | null },
      /** display-only rendering for field passthrough paragraphs */
      fieldDisplay: { default: null as FieldDisplay | null },
      /** decorative rule drawing: render as a horizontal line, not a chip */
      decorative: { default: false },
      /** stroke display of a decorative rule; null = default 1px full-width line */
      ruleColorHex: { default: null as string | null },
      ruleThicknessPx: { default: null as number | null },
      ruleWidthPx: { default: null as number | null },
      /** broken picture (missing rel/media): empty frame + alt text at the declared extent */
      brokenImage: { default: false },
      /** invisible body-level marker (stray bookmarkEnd…): render nothing, keep position */
      invisibleMarker: { default: false },
      /** display-only anchored textboxes (code boxes, callout cards) */
      textboxes: { default: null as TextboxDisplay[] | null },
      /** the anchor paragraph's own runs next to content textboxes (display-only) */
      strayRuns: { default: null as Run[] | null },
      strayStyleId: { default: null as string | null },
      /** editable OMML leaf tokens; formula structure remains protected */
      formulaDisplay: { default: null as FormulaDisplay | null },
      /** embedded chart data model; cached texts/numbers editable, structure protected */
      chartDisplay: { default: null as ChartDisplay | null },
      /** display-only SmartArt degrade (precomputed diagram drawing shapes) */
      diagramDisplay: { default: null as DiagramDisplay | null },
      /** self-contained OOXML fragment for editor-created content (new tables) */
      genXml: { default: null as string | null },
      /** new image awaiting embedding at save time */
      genImage: {
        default: null as { base64: string; mime: string; widthPx: number; heightPx: number } | null,
      },
      /** picture rotation (deg clockwise, 0-359) and mirror flips (a:xfrm rot/flipH/flipV) */
      imageRotDeg: { default: null as number | null },
      imageFlipH: { default: false },
      imageFlipV: { default: false },
      /** picture outline (pic:spPr a:ln solid fill, display-only) */
      imageBorder: { default: null as { color: string; widthPt: number } | null },
      /** replacement bytes for an original image (crop/background removal/replace):
       *  the drawing XML — and with it docxIndex, wrap and position — survives */
      imageReplace: { default: null as { base64: string; mime: string } | null },
      /** new chart awaiting embedding at save time (data snapshot; edits live in chartDisplay) */
      genChart: { default: null as NewChart | null },
    }
  },
  parseHTML() {
    /** a copied picture rebuilds from its inner img + meta payload; other
     *  protected kinds keep the default attrs (their payloads cannot travel
     *  through HTML) — r136 */
    const imageAttrsFrom = (el: HTMLElement): Record<string, unknown> | null => {
      const img = el.querySelector?.('img.doc-protected-img') as HTMLImageElement | null
      const src = img?.getAttribute('src') ?? ''
      // persistable formats only: a bmp/webp/svg picture would display and
      // then silently vanish on save — the placeholder shell is honest
      if (!PERSISTABLE_IMAGE_URL.test(src)) return null
      let meta: Record<string, unknown> = {}
      try {
        meta = JSON.parse(el.getAttribute('data-image-meta') ?? '{}') as Record<string, unknown>
      } catch {
        /* stripped payload: size falls back below */
      }
      const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : null)
      const str = (v: unknown) => (typeof v === 'string' && v ? v : null)
      return {
        blockType: 'image',
        label: 'Image',
        imageDataUrl: src,
        imageWidthPx: num(meta.imageWidthPx) ?? num(img?.width) ?? null,
        imageHeightPx: num(meta.imageHeightPx) ?? num(img?.height) ?? null,
        imageAlign: str(meta.imageAlign),
        imageWrap: str(meta.imageWrap),
      }
    }
    return [
      {
        tag: 'div[data-doc-protected]',
        getAttrs: (el) => imageAttrsFrom(el as HTMLElement),
      },
      // bare data-URL <img> (our own image-copy clipboard html, or rich
      // sources that inline the bitmap); http images keep going through the
      // dedicated insert paths, so this rule stays data:-only
      {
        tag: 'img[src]',
        getAttrs: (el) => {
          const img = el as HTMLImageElement
          const src = img.getAttribute('src') ?? ''
          if (!PERSISTABLE_IMAGE_URL.test(src)) return false
          let meta: Record<string, unknown> = {}
          try {
            meta = JSON.parse(img.getAttribute('data-image-meta') ?? '{}') as Record<
              string,
              unknown
            >
          } catch {
            /* foreign img without our payload: presentation size below */
          }
          const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : null)
          const str = (v: unknown) => (typeof v === 'string' && v ? v : null)
          return {
            blockType: 'image',
            label: 'Image',
            imageDataUrl: src,
            imageWidthPx: num(meta.imageWidthPx) ?? (img.width || null),
            imageHeightPx: num(meta.imageHeightPx) ?? (img.height || null),
            imageAlign: str(meta.imageAlign),
            imageWrap: str(meta.imageWrap),
          }
        },
      },
    ]
  },
  renderHTML({ node }) {
    return protectedDomSpec(node) as never
  },
  addNodeView() {
    return ({ node, editor, getPos }) => {
      let currentNode = node
      const dom = buildProtectedDom(currentNode)
      const getNode = () => currentNode
      const pos = getPos as () => number | undefined
      const textboxes = mountTextboxEditors(dom, getNode, pos, editor.view)
      const table = wireTableEditing(dom, getNode, pos, editor.view)
      const field = wireFieldEditing(dom, getNode, pos, editor.view)
      const formula = wireFormulaEditing(dom, getNode, pos, editor.view)
      const chart = wireChartEditing(dom, getNode, pos, editor.view)
      drawChartSvg(dom, currentNode.attrs.chartDisplay as ChartDisplay | null)
      const cleanups = [
        wireProtectedInteractionMode(
          dom,
          pos,
          editor.view,
          textboxes ?? table ?? field ?? formula ?? chart,
        ),
        wireFormulaLatexEdit(dom, getNode, pos),
        table?.cleanup,
        field?.cleanup,
        formula?.cleanup,
        chart?.cleanup,
        textboxes?.cleanup,
      ]
      return {
        dom,
        update: (n: PmNode) => {
          if (n.type.name !== 'docProtected') return false
          if (n.eq(currentNode)) {
            currentNode = n
            return true
          }
          // textbox commits only swap the textboxes attr; the sub-editors are
          // the source of truth, so keep the DOM (and editing session) alive
          if (textboxes && attrsEqualExcept(n.attrs, currentNode.attrs, 'textboxes')) {
            currentNode = n
            textboxes.sync(n.attrs.textboxes as TextboxDisplay[] | null)
            return true
          }
          // other attribute change (resize, table commit, ...): recreate DOM
          return false
        },
        // cell edits live in the DOM until committed on focusout; never re-parse
        ignoreMutation: () => true,
        stopEvent: (event: Event) => {
          const target = event.target as HTMLElement | null
          if (target?.closest?.('.doc-formula-edit')) return true
          // Let ProseMirror plugins receive handle presses; floating-object
          // dragging is implemented at the editor-view level.
          if (target?.closest?.('.doc-move-handle')) return false
          // Shape bodies (prst textboxes) drag-to-move on a plain press (Word
          // parity); a double-click still reaches the inner editor for the caret
          if (
            event.type === 'mousedown' &&
            (event as MouseEvent).detail < 2 &&
            target?.closest?.('.doc-textbox') &&
            !dom.classList.contains('doc-content-editing') &&
            (currentNode.attrs.textboxes as TextboxDisplay[] | null)?.[0]?.prst
          ) {
            return false
          }
          const contentTarget = target?.closest?.(EDITABLE_PROTECTED_SELECTOR)
          return (
            !!contentTarget &&
            (event.type === 'mousedown' || dom.classList.contains('doc-content-editing'))
          )
        },
        destroy: () => cleanups.forEach((c) => c?.()),
      }
    }
  },
  addProseMirrorPlugins() {
    return [imageResizePlugin(), floatingObjectDragPlugin()]
  },
})

/**
 * SmartArt / drawing-canvas display: absolutely positioned shapes (picture
 * fills, solid fills, centered texts) at the parse-resolved geometry. All
 * colors are document data (theme-resolved at parse), hence inline. Canvas
 * displays (lockedCanvas) keep raw-size text overflowing the scaled child
 * boxes instead of clipping, like LO renders them.
 */
function diagramSpecOf(diagram: DiagramDisplay): DomSpec {
  const shapeSpecs: DomSpec[] = diagram.shapes.map((s) => {
    // connectors (prst=line, zero cx or cy) render as solid rules along the axis
    if (s.lnHex && (s.wPx <= 0 || s.hPx <= 0)) {
      const w = Math.max(1, s.lnWPx ?? 1)
      const style = (
        s.hPx <= 0
          ? [
              `left:${s.xPx}px`,
              `top:${(s.yPx - w / 2).toFixed(1)}px`,
              `width:${s.wPx}px`,
              `height:${w}px`,
            ]
          : [
              `left:${(s.xPx - w / 2).toFixed(1)}px`,
              `top:${s.yPx}px`,
              `width:${w}px`,
              `height:${s.hPx}px`,
            ]
      )
        .concat(`background:#${s.lnHex}`)
        .join(';')
      return ['span', { class: 'doc-diagram-shape', style }] as DomSpec
    }
    const radius =
      s.prst === 'ellipse' || s.prst === 'circle'
        ? '50%'
        : s.prst === 'roundRect'
          ? `${Math.round(Math.min(s.wPx, s.hPx) * 0.12)}px`
          : '0'
    const style = [
      `left:${s.xPx}px`,
      `top:${s.yPx}px`,
      `width:${s.wPx}px`,
      `height:${s.hPx}px`,
      `border-radius:${radius}`,
      s.fillHex ? `background:#${s.fillHex}` : '',
      s.lnHex
        ? `border:${Math.max(1, s.lnWPx ?? 1)}px solid #${s.lnHex};box-sizing:border-box`
        : '',
      s.rotDeg ? `transform:rotate(${s.rotDeg}deg)` : '',
      s.fontSizePt ? `font-size:${s.fontSizePt}pt` : '',
      s.textColorHex ? `color:#${s.textColorHex}` : '',
    ]
      .filter(Boolean)
      .join(';')
    const kids: DomSpec[] = []
    if (s.imageDataUrl) {
      let imgStyle = 'position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover'
      if (s.fillRect) {
        const sw = s.wPx * (1 - s.fillRect.l - s.fillRect.r)
        const sh = s.hPx * (1 - s.fillRect.t - s.fillRect.b)
        imgStyle =
          `position:absolute;left:${(s.fillRect.l * s.wPx).toFixed(1)}px;` +
          `top:${(s.fillRect.t * s.hPx).toFixed(1)}px;` +
          `width:${sw.toFixed(1)}px;height:${sh.toFixed(1)}px;max-width:none`
      }
      kids.push(['img', { src: s.imageDataUrl, class: 'doc-diagram-img', style: imgStyle }])
    }
    if (s.texts?.length) {
      kids.push(['span', { class: 'doc-diagram-text' }, s.texts.join('\n')])
    }
    return ['span', { class: 'doc-diagram-shape', style }, ...kids]
  })
  const spanStyle = [
    `width:${diagram.widthPx}px`,
    `height:${diagram.heightPx}px`,
    diagram.floating
      ? `position:absolute;left:${((diagram.offsetXEmu ?? 0) / EMU_PER_PX).toFixed(1)}px;` +
        `top:${((diagram.offsetYEmu ?? 0) / EMU_PER_PX).toFixed(1)}px`
      : '',
  ]
    .filter(Boolean)
    .join(';')
  return [
    'span',
    {
      class: `doc-diagram${diagram.canvas ? ' doc-diagram-canvas' : ''}`,
      style: spanStyle,
    },
    ...shapeSpecs,
  ]
}

/** wrapTopAndBottom band bottom (px) for a box at the given (live) height */
export function textboxBandBottom(box: TextboxDisplay, height = box.heightPx): number {
  if (box.bandTopPx !== undefined && height !== undefined) return box.bandTopPx + height
  return box.bandBottomPx ?? 0
}

/** shared DOM spec for protected blocks (renderHTML + node view) */
function protectedDomSpec(node: PmNode): DomSpec {
  const {
    blockType,
    label,
    previewText,
    imageDataUrl,
    docxIndex,
    table,
    fieldDisplay,
    decorative,
    textboxes,
    formulaDisplay,
    chartDisplay,
  } = node.attrs
  const attrs: Record<string, string> = {
    'data-doc-protected': String(blockType),
    'data-idx': docxIndex === null ? '' : String(docxIndex),
    class: `doc-protected doc-protected-${blockType}`,
  }
  // field/TOC paragraphs keep their paragraph style so document CSS
  // (TOC1 spacing etc.) reaches the wrapper like any styled paragraph
  if (node.attrs.styleId) attrs['data-style'] = String(node.attrs.styleId)
  if (node.attrs.invisibleMarker) {
    attrs.class += ' doc-protected-invisible'
    return ['div', attrs]
  }
  if (decorative) {
    attrs.class += ' doc-protected-rule'
    const { ruleColorHex, ruleThicknessPx, ruleWidthPx } = node.attrs
    // document stroke color/size, not chrome: inline hardcoded values
    let style = ''
    if (ruleColorHex) style += `background:#${String(ruleColorHex)};`
    if (ruleThicknessPx) style += `height:${Number(ruleThicknessPx)}px;`
    if (ruleWidthPx) style += `width:${Number(ruleWidthPx)}px;max-width:100%;`
    const lineAttrs: Record<string, string> = { class: 'doc-rule-line' }
    if (style) lineAttrs.style = style
    return ['div', attrs, ['span', lineAttrs]]
  }
  if (Array.isArray(textboxes) && textboxes.length > 0) {
    attrs.class += ' doc-protected-textboxes'
    // paragraph justification centers inline shapes (WordArt) like Word
    const boxAlign = node.attrs.imageAlign
    if (boxAlign === 'center' || boxAlign === 'right') {
      attrs.class += ` doc-protected-boxes-${boxAlign}`
    }
    const boxes = textboxes as TextboxDisplay[]
    const diagram = node.attrs.diagramDisplay as DiagramDisplay | null
    // every box floats at its own anchor offset (wrapNone / multi-drawing
    // paragraphs): the wrapper leaves the flow like Word instead of stacking
    const allFloating = boxes.every((b) => b.floating) && (!diagram || diagram.floating)
    const strayRuns = node.attrs.strayRuns as Run[] | null
    let strayStyle = ''
    if (allFloating) {
      attrs.class += ' doc-protected-floating'
      // behindDoc anchors paint under the body text (Word z-order); mirrors
      // the behind-image z band
      if (boxes.every((b) => b.behind)) attrs.class += ' doc-protected-behind'
      // page-pinned cover art: the wrapper stays un-positioned so the boxes'
      // absolute page coordinates resolve against the page box
      if (boxes.every((b) => b.pagePinned)) attrs.class += ' doc-protected-pagepinned'
      // wrapTopAndBottom band: the wrapper reserves flow height down to the
      // lowest such box bottom so following text resumes below (min-height,
      // not a sum — stray flow content on the same paragraph must not add)
      const band = Math.max(0, ...boxes.map((b) => textboxBandBottom(b)))
      if (band > 0) {
        attrs.style = `min-height:${band}px`
        // consecutive anchor paragraphs share the page in Word: expose the raw
        // band geometry so syncAnchorBands can lay a run out band-exclusively
        attrs['data-band'] = String(Math.round(band))
        attrs['data-bands'] = boxes
          .filter((b) => textboxBandBottom(b) > 0)
          .map(
            (b) =>
              `${Math.max(0, Math.round(b.bandTopPx ?? 0))}:${Math.round(textboxBandBottom(b))}`,
          )
          .join(' ')
      }
      // stray text keeps the anchor paragraph's flow line in Word, so the
      // wrapper must not collapse to height 0 (next block would overlap it)
      if (strayRuns?.length) attrs.class += ' doc-protected-floating-stray'
      // Word reserves the anchor paragraph's own (empty) line even when its
      // runs carry only anchored drawings — page-pinned ones too (JP flowchart
      // docs anchor paragraph-relative labels below runs of pinned shapes;
      // collapsed pinned lines pulled every later anchor up)
      else attrs.class += ' doc-protected-floating-stray'
    } else {
      const offsetX = node.attrs.imageOffsetXEmu
      const offsetY = node.attrs.imageOffsetYEmu
      if (offsetX != null || offsetY != null) {
        const dx = Number(offsetX ?? 0) / EMU_PER_PX
        const dy = Number(offsetY ?? 0) / EMU_PER_PX
        attrs.style = `transform:translate(${dx}px,${dy}px)`
        // the drawing offset moves the boxes only; stray text stays put
        strayStyle = `transform:translate(${-dx}px,${-dy}px)`
      }
    }
    const children: DomSpec[] = boxes.map(renderTextboxSpec)
    // the anchor paragraph's own text (e.g. a heading sharing its paragraph
    // with a sidebar box) renders as a display-only line before the boxes
    if (strayRuns?.length) {
      const strayAttrs: Record<string, string> = { class: 'doc-textbox-stray' }
      if (strayStyle) strayAttrs.style = strayStyle
      if (node.attrs.strayStyleId) strayAttrs['data-style'] = String(node.attrs.strayStyleId)
      children.unshift(['div', strayAttrs, ...strayRuns.flatMap((run) => runSpanSpecs(run))])
    } else if (
      attrs.class.includes('doc-protected-floating-stray') &&
      (fieldDisplay as FieldDisplay | null)?.kind !== 'pageBreak'
    ) {
      // the anchor paragraph's empty line (the break-chip branch below renders
      // its own stray line instead)
      children.unshift(['div', { class: 'doc-anchor-strut' }, ['br']])
    }
    if (diagram?.shapes?.length) children.push(diagramSpecOf(diagram))
    // corner resize handle; multi-box nodes keep per-box autogrow semantics only
    if (boxes.length === 1 && !diagram) {
      children.push(['span', { class: 'box-resize-handle', contenteditable: 'false' }])
    }
    // page-type w:br the anchor paragraph carries next to the boxes: Word keeps
    // the anchor's flow line, so render the break chip as a stray line (nonzero
    // height — a zero-height carrier cannot advance the pagination Y coordinate)
    if ((fieldDisplay as FieldDisplay | null)?.kind === 'pageBreak') {
      attrs.class += ' doc-protected-floating-stray'
      const spec = renderFieldSpec(fieldDisplay as FieldDisplay)
      if (spec) children.push(spec)
    }
    return ['div', attrs, moveHandleSpec(t('editorMoveTextbox')), ...children]
  }
  // empty section-break paragraphs (page-per-section converter output): Word
  // shows nothing here, so render a near-invisible strip (hover reveals it)
  if (label === 'Section break paragraph' && !previewText) {
    attrs.class += ' doc-protected-sectbreak'
    return ['div', attrs, ['span', { class: 'doc-sectbreak-label' }, t('editorSectionBreak')]]
  }
  // TOC field boundary paragraphs (fldChar begin + instruction / lone fldChar
  // end) have no visible result; Word shows nothing there either, so they get
  // the same near-invisible strip (hover/selection reveals the label)
  if (
    !previewText &&
    !fieldDisplay &&
    (label === 'Auto TOC (updates when opened in Word)' || label === 'Field end marker')
  ) {
    attrs.class += ' doc-protected-sectbreak'
    return ['div', attrs, ['span', { class: 'doc-sectbreak-label' }, String(label)]]
  }
  if (blockType === 'image' && imageDataUrl) {
    const {
      imageWidthPx,
      imageHeightPx,
      imageAlign,
      imageWrap,
      imageCrop,
      imageFillRect,
      imageRotDeg,
    } = node.attrs
    // clipboard round-trip payload (r136): parseHTML rebuilds the image from
    // the inner img src plus these display attrs; without it a copied picture
    // pasted back as an attribute-less "protected content" shell
    attrs['data-image-meta'] = imageMetaJson(node.attrs)
    if (imageAlign === 'center' || imageAlign === 'right') {
      attrs['style'] = `text-align:${imageAlign}`
    }
    if (imageWrap) attrs.class += ` img-wrap-${String(imageWrap)}`
    const imageLeadingText = String(node.attrs.imageLeadingText ?? '')
    const cjkFixedLeadingSpaces =
      !imageWrap &&
      /^[ ]+$/.test(imageLeadingText) &&
      !!node.attrs.imageLeadingFont &&
      isCjkFontName(String(node.attrs.imageLeadingFont))
    // paragraph indents place the picture like its (possibly empty) first line;
    // anchored pictures position from the column instead and ignore them
    if (!imageWrap) {
      const paragraphLayout = [
        node.attrs.imageParagraphIndentLeft
          ? `margin-inline-start:${Number(node.attrs.imageParagraphIndentLeft) / 20}pt`
          : '',
        node.attrs.imageParagraphIndentRight
          ? `margin-inline-end:${Number(node.attrs.imageParagraphIndentRight) / 20}pt`
          : '',
        !cjkFixedLeadingSpaces && node.attrs.imageParagraphIndentFirstLine
          ? `text-indent:${Number(node.attrs.imageParagraphIndentFirstLine) / 20}pt`
          : '',
      ].filter(Boolean)
      if (paragraphLayout.length) {
        attrs.style = `${attrs.style ? `${attrs.style};` : ''}${paragraphLayout.join(';')}`
      }
    }
    const imageLeadingStyle = [
      node.attrs.imageLeadingFont
        ? `font-family:${cssFontFamily(String(node.attrs.imageLeadingFont))}`
        : '',
    ]
      .filter(Boolean)
      .join(';')
    const imageLeadingSpecs: DomSpec[] =
      imageLeadingText && !cjkFixedLeadingSpaces
        ? [
            [
              'span',
              {
                class: 'doc-image-leading-space',
                ...(imageLeadingStyle ? { style: imageLeadingStyle } : {}),
              },
              imageLeadingText,
            ],
          ]
        : []
    // no-wrap / behind-text anchors leave the flow like floating textboxes:
    // zero-height wrapper (doc-img-float), absolutely positioned inner wrap
    // (Word overlays them on the text instead of reserving a line)
    const explicitSpaceWidthPx = Number(node.attrs.imageLeadingExplicitSpaceWidthPx ?? 0)
    const implicitSpaceCount = Number(
      node.attrs.imageLeadingImplicitSpaceCount ??
        (explicitSpaceWidthPx > 0 ? 0 : imageLeadingText.length),
    )
    let imgWrapTransform = cjkFixedLeadingSpaces
      ? `margin-left:calc(${Number(node.attrs.imageParagraphIndentFirstLine ?? 0) / 15 + explicitSpaceWidthPx}px + ${implicitSpaceCount * 0.5}em)`
      : ''
    let imgFloatPos = ''
    // the vertical posOffset margin must not be clobbered by a wrap-distance
    // margin-top below (distT is clearance, the offset is position — position wins)
    let hasOffsetTopMargin = false
    if (imageWrap === 'front' || imageWrap === 'behind') {
      attrs.class += ' doc-img-float'
      // z-index bands keep behind-text pictures under the body text and
      // front pictures over it, while imageZOrder ranks overlapping anchors
      // within each band (Word bring-forward / send-back).
      const z = node.attrs.imageZOrder != null ? Number(node.attrs.imageZOrder) : 0
      // behind band: negative (below text). front band: >=1 (above text; the
      // text layer sits at auto/0). Parse compresses wild relativeHeight
      // values to compact ranks, but the floor still guards the band: the
      // wrap semantics always win over the rank. No ceiling — the editor
      // content root is isolated (styles.css), so ranks can never climb
      // above editor chrome outside it (table handles, menus).
      const zi = imageWrap === 'behind' ? Math.min(-1, -1000 + z) : Math.max(1, 2 + z)
      const imgZIndexCss = `;z-index:${Math.round(zi)}`
      const posH = node.attrs.imagePosH
      const tx =
        node.attrs.imageOffsetXEmu != null ? Number(node.attrs.imageOffsetXEmu) / EMU_PER_PX : 0
      const ty =
        node.attrs.imageOffsetYEmu != null ? Number(node.attrs.imageOffsetYEmu) / EMU_PER_PX : 0
      if (posH === 'center') {
        imgFloatPos = `left:50%;top:${ty.toFixed(1)}px${imgZIndexCss}`
        imgWrapTransform = 'transform:translateX(-50%)'
      } else if (posH === 'right') {
        imgFloatPos = `right:0;top:${ty.toFixed(1)}px${imgZIndexCss}`
      } else {
        imgFloatPos = `left:${tx.toFixed(1)}px;top:${ty.toFixed(1)}px${imgZIndexCss}`
      }
    } else if (imageWrap) {
      // In-flow wraps (square/tight/through/topBottom) honor a numeric
      // posOffset so a dragged picture stays where it was dropped (Word
      // WYSIWYG): X measures from the column start, Y from the anchor
      // paragraph top — matching the saved relativeFrom column/paragraph.
      const wrapperCss: string[] = []
      if (node.attrs.imageOffsetYEmu != null) {
        const ty = Number(node.attrs.imageOffsetYEmu) / EMU_PER_PX
        // a negative offset lifts via the inner wrap so the flow band keeps
        // its height (Word: logo above its anchor line must not push)
        if (ty < 0) imgWrapTransform = `margin-top:${ty.toFixed(1)}px`
        else if (ty > 0) {
          wrapperCss.push(`margin-top:${ty.toFixed(1)}px`)
          hasOffsetTopMargin = true
        }
      }
      if (node.attrs.imageOffsetXEmu != null) {
        const tx = Number(node.attrs.imageOffsetXEmu) / EMU_PER_PX
        const w = Number(imageWidthPx ?? 0)
        if (imageWrap === 'topBottom') {
          // an explicit X replaces the centered slot
          wrapperCss.push('text-align:left')
          imgWrapTransform =
            (imgWrapTransform ? `${imgWrapTransform};` : '') + `margin-left:${tx.toFixed(1)}px`
        } else if (String(imageWrap).endsWith('-right') && w > 0) {
          // right floats position from the right edge: colW − x − width; the
          // 60% float clamp would shift the math, and Word never shrinks a
          // freely positioned picture
          wrapperCss.push(`margin-right:calc(100% - ${(tx + w).toFixed(1)}px)`, 'max-width:none')
        } else {
          wrapperCss.push(`margin-left:${tx.toFixed(1)}px`, 'max-width:none')
        }
      }
      if (wrapperCss.length) {
        attrs['style'] = `${attrs['style'] ? `${attrs['style']};` : ''}${wrapperCss.join(';')}`
      }
    }
    // wrap distances apply to in-flow wraps only: wrapNone (front/behind)
    // anchors ignore them in Word, and margins on the zero-height wrapper
    // would displace the following flow content
    if (imageWrap && imageWrap !== 'front' && imageWrap !== 'behind') {
      const distancePx = (attr: string): number | null =>
        node.attrs[attr] != null ? Number(node.attrs[attr]) / EMU_PER_PX : null
      const top = distancePx('imageWrapDistTopEmu')
      const bottom = distancePx('imageWrapDistBottomEmu')
      const left = distancePx('imageWrapDistLeftEmu')
      const right = distancePx('imageWrapDistRightEmu')
      const distances = [
        !hasOffsetTopMargin && top != null ? `margin-top:${top.toFixed(1)}px` : '',
        bottom != null ? `margin-bottom:${bottom.toFixed(1)}px` : '',
        String(imageWrap).endsWith('-right') && left != null
          ? `margin-left:${left.toFixed(1)}px`
          : '',
        String(imageWrap).endsWith('-left') && right != null
          ? `margin-right:${right.toFixed(1)}px`
          : '',
      ].filter(Boolean)
      if (distances.length) {
        attrs.style = `${attrs.style ? `${attrs.style};` : ''}${distances.join(';')}`
      }
    }
    const imgAttrs: Record<string, string> = {
      src: String(imageDataUrl),
      class: 'doc-protected-img',
    }
    if (imageWidthPx) {
      imgAttrs['style'] =
        `width:${Number(imageWidthPx)}px;` +
        (imageHeightPx ? `height:${Number(imageHeightPx)}px` : 'height:auto')
    }
    // picture outline (document data, not chrome): border adds outside the
    // extent, approximating Word's centered stroke
    const ib = node.attrs.imageBorder as { color: string; widthPt: number } | null
    const borderCss = ib
      ? `border:${((ib.widthPt * 96) / 72).toFixed(1)}px solid #${String(ib.color).replace(/[^0-9A-Fa-f]/g, '')}`
      : ''
    // DrawingML order: flip mirrors the source, rot turns the result
    // (CSS applies right-to-left, so scale sits last)
    const xf: string[] = []
    if (imageRotDeg) xf.push(`rotate(${Number(imageRotDeg)}deg)`)
    if (node.attrs.imageFlipH) xf.push('scaleX(-1)')
    if (node.attrs.imageFlipV) xf.push('scaleY(-1)')
    // a:srcRect source crop / a:fillRect fill placement: an overflow-hidden
    // window at the declared extent over a scaled and offset image
    const rect = (imageCrop ?? imageFillRect) as {
      l: number
      t: number
      r: number
      b: number
    } | null
    if (rect && imageWidthPx && imageHeightPx) {
      const W = Number(imageWidthPx)
      const H = Number(imageHeightPx)
      const span = (a: number, b: number) => Math.max(0.01, 1 - a - b)
      let sw: number, sh: number, dx: number, dy: number
      if (imageCrop) {
        // crop: the window shows the (1-l-r)×(1-t-b) slice of the source
        sw = W / span(rect.l, rect.r)
        sh = H / span(rect.t, rect.b)
        dx = -rect.l * sw
        dy = -rect.t * sh
      } else {
        // fillRect: the image occupies the inset (negative = bleeding) sub-rect
        sw = W * (1 - rect.l - rect.r)
        sh = H * (1 - rect.t - rect.b)
        dx = rect.l * W
        dy = rect.t * H
      }
      imgAttrs['style'] =
        `position:absolute;left:${dx.toFixed(1)}px;top:${dy.toFixed(1)}px;` +
        `width:${sw.toFixed(1)}px;height:${sh.toFixed(1)}px;max-width:none`
      // rot/flip turn the whole crop window, not the source inside it
      const wrapXf = [
        ...(imgWrapTransform.startsWith('transform:')
          ? [imgWrapTransform.slice('transform:'.length)]
          : []),
        ...xf,
      ]
      return [
        'div',
        attrs,
        moveHandleSpec(t('editorMoveImage')),
        ...(imageWrap ? [imageAnchorMarkerSpec()] : []),
        ...imageLeadingSpecs,
        [
          'span',
          {
            class: 'doc-img-wrap doc-img-crop',
            style: `position:${imgFloatPos ? `absolute;${imgFloatPos}` : 'relative'};display:inline-block;width:${W}px;height:${H}px${wrapXf.length ? `;transform:${wrapXf.join(' ')}` : ''}${imgWrapTransform && !imgWrapTransform.startsWith('transform:') ? `;${imgWrapTransform}` : ''}${borderCss ? `;${borderCss}` : ''}`,
          },
          [
            'span',
            {
              class: 'doc-img-crop-viewport',
              style: 'position:absolute;inset:0;overflow:hidden',
            },
            ['img', imgAttrs],
          ],
          ...imageSelectionControlsSpec(),
        ],
      ]
    }
    if (xf.length) {
      imgAttrs['style'] =
        `${imgAttrs['style'] ? `${imgAttrs['style']};` : ''}transform:${xf.join(' ')}`
    }
    if (borderCss) {
      imgAttrs['style'] = `${imgAttrs['style'] ? `${imgAttrs['style']};` : ''}${borderCss}`
    }
    return [
      'div',
      attrs,
      moveHandleSpec(t('editorMoveImage')),
      ...(imageWrap ? [imageAnchorMarkerSpec()] : []),
      ...imageLeadingSpecs,
      [
        'span',
        {
          class: 'doc-img-wrap',
          ...(imgFloatPos || imgWrapTransform
            ? {
                style: `${imgFloatPos ? `position:absolute;${imgFloatPos};` : ''}display:inline-block${imgWrapTransform ? `;${imgWrapTransform}` : ''}`,
              }
            : {}),
        },
        ['img', imgAttrs],
        ...imageSelectionControlsSpec(),
      ],
    ]
  }
  if (blockType === 'table' && table && (table as TableModel).rows?.length) {
    return [
      'div',
      attrs,
      moveHandleSpec(t('editorMoveTable')),
      renderTableSpec(table as TableModel),
    ]
  }
  if (fieldDisplay) {
    const spec = renderFieldSpec(fieldDisplay as FieldDisplay)
    if (spec) {
      attrs.class += ' doc-protected-field'
      return ['div', attrs, spec]
    }
  }
  if ((formulaDisplay as FormulaDisplay | null)?.tokens?.length) {
    attrs.class += ' doc-protected-formula'
    if ((formulaDisplay as FormulaDisplay).mathml) attrs.class += ' doc-protected-formula-display'
    return [
      'div',
      attrs,
      moveHandleSpec(t('editorMoveEquation')),
      renderFormulaSpec(formulaDisplay as FormulaDisplay),
    ]
  }
  if ((chartDisplay as ChartDisplay | null)?.series?.length) {
    attrs.class += ' doc-protected-chart'
    return [
      'div',
      attrs,
      moveHandleSpec(t('editorMoveChart')),
      renderChartSpec(chartDisplay as ChartDisplay),
      ['span', { class: 'box-resize-handle', contenteditable: 'false' }],
    ]
  }
  // SmartArt with a precomputed drawing part: absolutely positioned shapes
  // (picture fills, solid fills, centered texts) at Word's resolved geometry.
  // All colors are document data (theme-resolved at parse), hence inline.
  const diagram = node.attrs.diagramDisplay as DiagramDisplay | null
  if (diagram?.shapes?.length) {
    attrs.class += ' doc-protected-diagram'
    if (diagram.floating) {
      attrs.class += ' doc-protected-floating'
    } else if (diagram.offsetXEmu != null || diagram.offsetYEmu != null) {
      attrs.style =
        `transform:translate(${Number(diagram.offsetXEmu ?? 0) / EMU_PER_PX}px,` +
        `${Number(diagram.offsetYEmu ?? 0) / EMU_PER_PX}px)`
    }
    return ['div', attrs, moveHandleSpec(t('editorMoveImage')), diagramSpecOf(diagram)]
  }
  // Broken picture (missing rel/media): empty frame at the declared extent
  // with centered alt text. Frame/text colors stand in for document content
  // (must look identical in both themes), hence hardcoded inline.
  if (node.attrs.brokenImage) {
    attrs.class += ' doc-protected-broken-img'
    const { imageWidthPx, imageHeightPx, imageAlign } = node.attrs
    if (imageAlign === 'center' || imageAlign === 'right') {
      attrs.style = `text-align:${imageAlign}`
    }
    let style = 'border:1px solid #999;color:#888;'
    if (imageWidthPx) style += `width:${Number(imageWidthPx)}px;`
    if (imageHeightPx) style += `height:${Number(imageHeightPx)}px;`
    return [
      'div',
      attrs,
      ['span', { class: 'doc-broken-img-frame', style }, String(previewText || label || '')],
    ]
  }
  // OLE embed with a packaged preview picture: Word draws just the preview at
  // its declared size (Icon previews carry their own caption inside the
  // metafile) — the friendly type name moves to a hover tooltip
  const oleCaption = label === 'Embedded object' ? oleTypeLabel(node.attrs.oleProgId) : null
  if (imageDataUrl && blockType === 'passthrough') {
    attrs.class += ' doc-protected-ole'
    attrs.title = oleCaption ?? String(label)
    const { imageWidthPx, imageHeightPx, imageAlign } = node.attrs
    if (imageAlign === 'center' || imageAlign === 'right') {
      attrs.style = `text-align:${imageAlign}`
    }
    let imgStyle = ''
    if (imageWidthPx) imgStyle += `width:${Number(imageWidthPx)}px;`
    if (imageHeightPx) imgStyle += `height:${Number(imageHeightPx)}px;`
    return [
      'div',
      attrs,
      [
        'span',
        { class: 'doc-ole-wrap' },
        ['img', { src: String(imageDataUrl), class: 'doc-ole-img', style: imgStyle }],
      ],
    ]
  }
  const children: unknown[] = [
    [
      'span',
      { class: 'doc-protected-label' },
      oleCaption ?? String(label || t('editorProtectedContent')),
    ],
  ]
  if (previewText) children.push(['span', { class: 'doc-protected-preview' }, String(previewText)])
  return ['div', attrs, ...children]
}

/** o:OLEObject ProgID → localized friendly kind */
function oleTypeLabel(progId: unknown): string {
  const id = typeof progId === 'string' ? progId : ''
  if (id.startsWith('Excel.')) return t('editorOleExcel')
  if (id.startsWith('Word.')) return t('editorOleWord')
  if (id.startsWith('PowerPoint.')) return t('editorOlePpt')
  if (id.startsWith('AcroExch')) return t('editorOlePdf')
  return id ? `${t('editorOleGeneric')} (${id.split('.')[0]})` : t('editorOleGeneric')
}

function moveHandleSpec(label: string): DomSpec {
  return [
    'span',
    {
      class: 'doc-move-handle',
      title: label,
      'aria-label': label,
      contenteditable: 'false',
    },
    '↕',
  ]
}

type ImageResizeHandle = 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w'

const IMAGE_RESIZE_HANDLES: readonly ImageResizeHandle[] = [
  'nw',
  'n',
  'ne',
  'e',
  'se',
  's',
  'sw',
  'w',
]

function imageSelectionControlsSpec(): DomSpec[] {
  return IMAGE_RESIZE_HANDLES.map((direction): DomSpec => [
    'span',
    {
      class: `img-resize-handle img-resize-handle-${direction}`,
      'data-resize-handle': direction,
      contenteditable: 'false',
      draggable: 'false',
      'aria-hidden': 'true',
    },
  ])
}

function imageAnchorMarkerSpec(): DomSpec {
  return [
    'span',
    {
      class: 'doc-image-anchor-marker',
      contenteditable: 'false',
      'aria-hidden': 'true',
    },
    '⚓',
  ]
}

export function buildProtectedDom(node: PmNode): HTMLElement {
  const { dom } = DOMSerializer.renderSpec(document, protectedDomSpec(node) as never)
  const el = dom as HTMLElement
  const mathml = (node.attrs.formulaDisplay as FormulaDisplay | null)?.mathml
  const mathHost = el.querySelector?.('.doc-formula-math')
  if (mathml && mathHost) mathHost.innerHTML = mathml
  return el
}

export interface ProtectedContentEditor {
  setEditable(editable: boolean): void
  commit(): void
}

const EDITABLE_PROTECTED_SELECTOR =
  'td, .doc-textbox, .doc-toc-title, .doc-toc-page, .doc-field-text, .doc-formula-token, ' +
  '.doc-formula-math, .doc-chart-title, .doc-chart-cell'

/** Object mode (single click/drag) and text mode (double click). */
function wireProtectedInteractionMode(
  dom: HTMLElement,
  getPos: () => number | undefined,
  view: EditorView,
  contentEditor: ProtectedContentEditor | null,
): (() => void) | null {
  const handle = dom.querySelector('.doc-move-handle') as HTMLElement | null
  if (!handle && !contentEditor) return null

  const selectObject = () => {
    const pos = getPos()
    if (typeof pos !== 'number') return
    view.dispatch(view.state.tr.setSelection(NodeSelection.create(view.state.doc, pos)))
  }
  const setEditing = (editing: boolean) => {
    if (!contentEditor) editing = false
    if (editing === dom.classList.contains('doc-content-editing')) {
      contentEditor?.setEditable(editing)
      dom.draggable = !!handle && !editing
      return
    }
    if (!editing) contentEditor?.commit()
    contentEditor?.setEditable(editing)
    dom.classList.toggle('doc-content-editing', editing)
    dom.draggable = !!handle && !editing
  }
  const onMouseDown = (event: MouseEvent) => {
    if (event.button !== 0) return
    const target = event.target as HTMLElement | null
    if (!target) return
    if (target.closest('.doc-move-handle')) {
      setEditing(false)
      selectObject()
      return
    }
    const content = target.closest(EDITABLE_PROTECTED_SELECTOR)
    if (content && dom.contains(content)) {
      if (!dom.classList.contains('doc-content-editing')) selectObject()
      dom.draggable = !!handle && !dom.classList.contains('doc-content-editing')
      return
    }
    if (dom.classList.contains('doc-content-editing')) setEditing(false)
    selectObject()
  }
  const onDoubleClick = (event: MouseEvent) => {
    if (!contentEditor) return
    const target = event.target as HTMLElement | null
    const content = target?.closest(EDITABLE_PROTECTED_SELECTOR)
    if (!content || !dom.contains(content)) return
    setEditing(true)
  }
  const onDocumentMouseDown = (event: MouseEvent) => {
    const target = event.target
    if (
      target instanceof HTMLElement &&
      !dom.contains(target) &&
      dom.classList.contains('doc-content-editing')
    ) {
      setEditing(false)
    }
  }
  const onKeyDown = (event: KeyboardEvent) => {
    if (event.key !== 'Escape' || !dom.classList.contains('doc-content-editing')) return
    setEditing(false)
    selectObject()
    dom.focus()
  }

  setEditing(false)
  dom.addEventListener('mousedown', onMouseDown, true)
  dom.addEventListener('dblclick', onDoubleClick, true)
  document.addEventListener('mousedown', onDocumentMouseDown, true)
  dom.addEventListener('keydown', onKeyDown, true)
  return () => {
    dom.removeEventListener('mousedown', onMouseDown, true)
    dom.removeEventListener('dblclick', onDoubleClick, true)
    document.removeEventListener('mousedown', onDocumentMouseDown, true)
    dom.removeEventListener('keydown', onKeyDown, true)
  }
}

/** split a contenteditable cell back into paragraph strings */
function tdParas(td: HTMLElement): string[] {
  const text = (td.innerText ?? td.textContent ?? '').replace(/\u00a0/g, ' ').replace(/\n+$/, '')
  const paras = text.split('\n')
  if (paras.length === 1 && paras[0].trim() === '') return ['']
  return paras
}

/**
 * In-place cell editing: cells become contenteditable islands and
 * their text is committed back into the node's TableModel when focus leaves
 * the table (or when App broadcasts 'ai-docs-commit-tables' before saving).
 */
function wireTableEditing(
  dom: HTMLElement,
  getNode: () => PmNode,
  getPos: () => number | undefined,
  view: EditorView,
): (ProtectedContentEditor & { cleanup(): void }) | null {
  const node = getNode()
  if (node.attrs.blockType !== 'table' || !node.attrs.table) return null
  const setEditable = (editable: boolean) => {
    for (const td of Array.from(dom.querySelectorAll('td'))) {
      td.setAttribute('contenteditable', editable ? 'true' : 'false')
    }
  }

  const commit = () => {
    const current = getNode()
    const model = current.attrs.table as TableModel
    const domTds = Array.from(dom.querySelectorAll('td'))
    let k = 0
    let changed = false
    const rows = model.rows.map((row) =>
      row.map((cell) => {
        if (cell.vMerge === 'continue') return cell
        const td = domTds[k++]
        if (!td) return cell
        const paras = tdParas(td as HTMLElement)
        if (paras.join('\n') === cell.paras.join('\n')) return cell
        changed = true
        return { ...cell, paras }
      }),
    )
    if (!changed) return
    const pos = getPos()
    if (typeof pos !== 'number') return
    view.dispatch(
      view.state.tr.setNodeMarkup(pos, undefined, { ...current.attrs, table: { ...model, rows } }),
    )
  }

  dom.addEventListener('focusout', (e) => {
    const next = (e as FocusEvent).relatedTarget as HTMLElement | null
    if (next && dom.contains(next)) return // moving between cells: not yet
    commit()
  })
  window.addEventListener('ai-docs-commit-tables', commit)
  return {
    setEditable,
    commit,
    cleanup: () => window.removeEventListener('ai-docs-commit-tables', commit),
  }
}

export function protectedText(element: HTMLElement): string {
  return (element.innerText ?? element.textContent ?? '').replace(/\u00a0/g, '')
}

export function preventProtectedLineBreak(event: KeyboardEvent) {
  if (event.key === 'Enter') event.preventDefault()
}

/** Edit cached visible field results without exposing field instructions. */
function wireFieldEditing(
  dom: HTMLElement,
  getNode: () => PmNode,
  getPos: () => number | undefined,
  view: EditorView,
): (ProtectedContentEditor & { cleanup(): void }) | null {
  const field = getNode().attrs.fieldDisplay as FieldDisplay | null
  if (!field || field.kind === 'pageBreak') return null
  const targets = Array.from(
    dom.querySelectorAll<HTMLElement>('.doc-toc-title, .doc-toc-page, .doc-field-text'),
  )
  if (targets.length === 0) return null

  const setEditable = (editable: boolean) => {
    for (const target of targets)
      target.setAttribute('contenteditable', editable ? 'true' : 'false')
  }
  const commit = () => {
    const current = getNode()
    const currentField = current.attrs.fieldDisplay as FieldDisplay | null
    if (!currentField) return
    const next: FieldDisplay = { ...currentField }
    if (currentField.kind === 'tocLine') {
      const left = dom.querySelector<HTMLElement>('.doc-toc-title')
      const right = dom.querySelector<HTMLElement>('.doc-toc-page')
      if (left) next.left = protectedText(left)
      if (right) next.right = protectedText(right)
    } else {
      const text = dom.querySelector<HTMLElement>('.doc-field-text')
      if (text) next.left = protectedText(text)
    }
    if (JSON.stringify(next) === JSON.stringify(currentField)) return
    const pos = getPos()
    if (typeof pos !== 'number') return
    view.dispatch(
      view.state.tr.setNodeMarkup(pos, undefined, { ...current.attrs, fieldDisplay: next }),
    )
  }
  for (const target of targets) target.addEventListener('keydown', preventProtectedLineBreak)
  window.addEventListener('ai-docs-commit-tables', commit)
  return {
    setEditable,
    commit,
    cleanup: () => {
      for (const target of targets) target.removeEventListener('keydown', preventProtectedLineBreak)
      window.removeEventListener('ai-docs-commit-tables', commit)
    },
  }
}

/** hover button on display formulas whose LaTeX was recovered: full re-edit */
function wireFormulaLatexEdit(
  dom: HTMLElement,
  getNode: () => PmNode,
  getPos: () => number | undefined,
): (() => void) | null {
  const formula = getNode().attrs.formulaDisplay as FormulaDisplay | null
  if (!formula?.latex) return null
  const host = dom.querySelector('.doc-formula-wrap') ?? dom
  const button = document.createElement('button')
  button.className = 'doc-formula-edit'
  button.title = t('editorEditFormulaLatex')
  button.textContent = t('editorEdit')
  button.setAttribute('contenteditable', 'false')
  button.addEventListener('mousedown', (e) => {
    e.preventDefault()
    e.stopPropagation()
  })
  button.addEventListener('click', (e) => {
    e.preventDefault()
    e.stopPropagation()
    const pos = getPos()
    const latex = (getNode().attrs.formulaDisplay as FormulaDisplay | null)?.latex
    if (typeof pos === 'number' && latex) {
      window.dispatchEvent(
        new CustomEvent('ai-docs-edit-inline-math', {
          detail: { pos, latex, kind: 'block' },
        }),
      )
    }
  })
  host.appendChild(button)
  return () => button.remove()
}

/** Edit OMML leaf tokens while keeping formula structure outside the editor. */
function wireFormulaEditing(
  dom: HTMLElement,
  getNode: () => PmNode,
  getPos: () => number | undefined,
  view: EditorView,
): (ProtectedContentEditor & { cleanup(): void }) | null {
  const formula = getNode().attrs.formulaDisplay as FormulaDisplay | null
  if (!formula?.tokens.length) return null
  const targets = Array.from(dom.querySelectorAll<HTMLElement>('.doc-formula-token'))
  if (targets.length !== formula.tokens.length) return null

  const setEditable = (editable: boolean) => {
    for (const target of targets)
      target.setAttribute('contenteditable', editable ? 'true' : 'false')
  }
  const commit = () => {
    const current = getNode()
    const currentFormula = current.attrs.formulaDisplay as FormulaDisplay | null
    if (!currentFormula || currentFormula.tokens.length !== targets.length) return
    const tokens = targets.map(protectedText)
    if (tokens.every((token, i) => token === currentFormula.tokens[i])) return
    const pos = getPos()
    if (typeof pos !== 'number') return
    // re-derive the 2D preview (and, for editor-created formulas, the OOXML
    // to be saved) from the patched OMML source
    const omml = currentFormula.omml ? patchMathTokens(currentFormula.omml, tokens) : undefined
    const nextFormula: FormulaDisplay = omml
      ? { tokens, omml, mathml: ommlToMathML(omml) }
      : { tokens }
    const attrs: Record<string, unknown> = { ...current.attrs, formulaDisplay: nextFormula }
    if (current.attrs.genXml) {
      attrs.genXml = patchMathTokens(String(current.attrs.genXml), tokens)
    }
    view.dispatch(view.state.tr.setNodeMarkup(pos, undefined, attrs))
  }
  for (const target of targets) target.addEventListener('keydown', preventProtectedLineBreak)
  window.addEventListener('ai-docs-commit-tables', commit)
  return {
    setEditable,
    commit,
    cleanup: () => {
      for (const target of targets) target.removeEventListener('keydown', preventProtectedLineBreak)
      window.removeEventListener('ai-docs-commit-tables', commit)
    },
  }
}

/** node attrs equality ignoring one key (identity per key is enough here) */
function attrsEqualExcept(
  a: Record<string, unknown>,
  b: Record<string, unknown>,
  skip: string,
): boolean {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)])
  for (const key of keys) {
    if (key !== skip && !Object.is(a[key], b[key])) return false
  }
  return true
}

type TextboxPara = TextboxDisplay['paras'][number]

/** ProseMirror doc JSON for one textbox's rich content */
function textboxDocJson(box: TextboxDisplay): Record<string, unknown> {
  const paras = box.paras.map((para) => ({
    type: 'docParagraph',
    attrs: {
      styleId: para.styleId ?? null,
      align: para.align ?? null,
      lineSpacing: para.lineSpacing ?? null,
      lineRule: para.lineRule ?? null,
      lineRawTwips: para.lineRawTwips ?? null,
      snapToGrid: para.snapToGrid ?? null,
      indentLeft: para.indentLeft ?? null,
      indentRight: para.indentRight ?? null,
      indentFirstLine: para.indentFirstLine ?? null,
      spaceBefore: para.spaceBefore ?? null,
      spaceAfter: para.spaceAfter ?? null,
      spaceBeforeAuto: para.spaceBeforeAuto ?? null,
      spaceAfterAuto: para.spaceAfterAuto ?? null,
      shadingFill: para.shadingFill ?? null,
      borders: para.borders ?? null,
    },
    content: runsToInline(para.runs),
  }))
  // a shape with no w:txbxContent yet gets Word's centered authoring default,
  // so the live preview matches the jc="center" the inject save path writes
  const fresh = box.txbxIndex === undefined && box.shapeId !== undefined && !box.readOnly
  const emptyPara = fresh
    ? { type: 'docParagraph', attrs: { align: 'center' } }
    : { type: 'docParagraph' }
  return { type: 'doc', content: paras.length > 0 ? paras : [emptyPara] }
}

/** TextboxDisplay paragraphs from a sub-editor's current doc */
function subEditorParas(sub: Editor): TextboxPara[] {
  return ((sub.getJSON().content ?? []) as PmJson[]).map((p) => {
    const para: TextboxPara = { runs: inlineToRuns(p.content ?? []) }
    const attrs = p.attrs ?? {}
    const keys = [
      'styleId',
      'align',
      'lineSpacing',
      'lineRule',
      'lineRawTwips',
      'snapToGrid',
      'indentLeft',
      'indentRight',
      'indentFirstLine',
      'spaceBefore',
      'spaceAfter',
      'spaceBeforeAuto',
      'spaceAfterAuto',
      'shadingFill',
      'borders',
    ] as const
    for (const key of keys) {
      const value = attrs[key]
      if (value !== null && value !== undefined) Object.assign(para, { [key]: value })
    }
    return para
  })
}

/**
 * Rich textbox editing: each rendered box hosts a full nested
 * Tiptap editor sharing the main schema's marks, so ribbon formatting (color,
 * bold, size, ...) works inside the box. Content commits back into the node's
 * TextboxDisplay model when focus leaves the block (or before saving); the
 * save path regenerates only the changed paragraphs inside w:txbxContent.
 */
function mountTextboxEditors(
  dom: HTMLElement,
  getNode: () => PmNode,
  getPos: () => number | undefined,
  view: EditorView,
):
  | (ProtectedContentEditor & {
      cleanup: () => void
      sync: (boxes: TextboxDisplay[] | null) => void
    })
  | null {
  let knownBoxes = getNode().attrs.textboxes as TextboxDisplay[] | null
  if (!knownBoxes || knownBoxes.length === 0) return null

  const editors: Editor[] = []
  const boxEls = Array.from(dom.querySelectorAll('.doc-textbox')) as HTMLElement[]
  const minHeights = knownBoxes.map((box) => box.minHeightPx ?? box.heightPx)
  const measuredHeights = knownBoxes.map((box) => box.heightPx)
  const resizeFrames: Array<number | undefined> = []
  // wrapTopAndBottom band on the wrapper must follow autogrow, or the text
  // below would overlap a box that outgrew its parse-time height
  const refreshBand = () => {
    if (!knownBoxes || !dom.classList.contains('doc-protected-floating')) return
    const bottoms = knownBoxes.map((b, i) => textboxBandBottom(b, measuredHeights[i]))
    const band = Math.max(0, ...bottoms)
    if (band > 0) {
      // the band data drives syncAnchorBands: refresh it too, or the next
      // remeasure would restore the stale parse-time band over the autogrow
      dom.dataset.band = String(Math.round(band))
      dom.dataset.bands = knownBoxes
        .map((b, i) =>
          bottoms[i] > 0
            ? `${Math.max(0, Math.round(b.bandTopPx ?? 0))}:${Math.round(bottoms[i])}`
            : null,
        )
        .filter(Boolean)
        .join(' ')
      // a run-adjusted wrapper keeps its syncAnchorBands layout — writing the
      // own-band value here would break the whole run mid-edit; the next
      // remeasure re-lays the run out from the refreshed band data (page
      // slicing only updates then anyway)
      if (dom.dataset.bandAdj === undefined) dom.style.minHeight = `${band}px`
    }
  }
  const measureBox = (index: number) => {
    const el = boxEls[index]
    const minHeight = minHeights[index]
    if (!el || !minHeight) return
    const borderHeight = el.offsetHeight - el.clientHeight
    el.style.height = 'auto'
    const naturalHeight = Math.ceil(el.scrollHeight + borderHeight)
    const nextHeight = Math.max(minHeight, naturalHeight)
    el.style.height = `${nextHeight}px`
    measuredHeights[index] = nextHeight
    refreshBand()
  }
  const scheduleMeasure = (index: number) => {
    if (resizeFrames[index] !== undefined) cancelAnimationFrame(resizeFrames[index]!)
    resizeFrames[index] = requestAnimationFrame(() => {
      resizeFrames[index] = undefined
      measureBox(index)
    })
  }
  boxEls.forEach((el, i) => {
    const box = knownBoxes![i]
    if (!box) return
    // boxes whose content flattens tables / content controls into display lines
    // keep the static spec: a sub-editor commit would corrupt that structure
    if (box.readOnly) return
    el.replaceChildren() // the static spec children are replaced by the live editor
    const sub: Editor = new Editor({
      element: el,
      extensions: textboxSubExtensions,
      content: textboxDocJson(box),
      editorProps: {
        attributes: { class: 'doc-textbox-editor', spellcheck: 'false' },
      },
      onFocus: () => setActiveSubEditor(sub),
      onTransaction: ({ transaction }) => {
        notifySubEditorState(transaction.docChanged)
        if (transaction.docChanged) scheduleMeasure(i)
      },
    })
    // TipTap initializes the host element and may clear attributes emitted by
    // the static DOM spec, so reapply the shape geometry after mounting.
    el.setAttribute('style', textboxBoxStyle(box))
    editors[i] = sub
  })
  if (editors.length === 0) return null

  const setEditable = (editable: boolean) => {
    for (const sub of editors) {
      if (sub && !sub.isDestroyed) sub.setEditable(editable)
    }
  }

  const commit = () => {
    const current = getNode()
    const model = current.attrs.textboxes as TextboxDisplay[] | null
    if (!model) return
    let changed = false
    const next = model.map((box, i) => {
      const sub = editors[i]
      if (!sub || sub.isDestroyed) return box
      const paras = subEditorParas(sub)
      // the sub-editor of a paras:[] ink box always holds one seeded empty
      // paragraph — without text that is still "no content", not an edit, and
      // any measured height is a transient of the emptied text: commit nothing
      if (box.paras.length === 0 && paras.every((p) => p.runs.every((r) => r.text === ''))) {
        return box
      }
      const same =
        paras.length === box.paras.length &&
        paras.every((p, j) => textboxParaSignature(p) === textboxParaSignature(box.paras[j]))
      const measuredHeight = minHeights[i] ? measuredHeights[i] : box.heightPx
      const sameHeight = measuredHeight === box.heightPx
      if (same && sameHeight) return box
      changed = true
      return { ...box, paras, heightPx: measuredHeight }
    })
    if (!changed) return
    const pos = getPos()
    if (typeof pos !== 'number') return
    knownBoxes = next
    view.dispatch(
      view.state.tr.setNodeMarkup(pos, undefined, { ...current.attrs, textboxes: next }),
    )
  }

  /** external model change (undo of a commit, AI edit): re-feed the sub-editors */
  const sync = (boxes: TextboxDisplay[] | null) => {
    if (!boxes || boxes === knownBoxes) return
    knownBoxes = boxes
    boxes.forEach((box, i) => {
      const sub = editors[i]
      if (sub && !sub.isDestroyed) sub.commands.setContent(textboxDocJson(box))
      const el = boxEls[i]
      if (el) el.setAttribute('style', textboxBoxStyle(box))
      // corner resize only rewrites the attrs; without refreshing the minimum
      // the next autofit would shrink the box back below the resized height
      minHeights[i] = box.minHeightPx ?? box.heightPx
      measuredHeights[i] = box.heightPx
    })
    refreshBand()
  }

  dom.addEventListener('focusout', (e) => {
    const next = (e as FocusEvent).relatedTarget as HTMLElement | null
    if (next && dom.contains(next)) return // moving between boxes: not yet
    commit()
  })
  window.addEventListener('ai-docs-commit-tables', commit)
  const cleanup = () => {
    window.removeEventListener('ai-docs-commit-tables', commit)
    for (const frame of resizeFrames) {
      if (frame !== undefined) cancelAnimationFrame(frame)
    }
    for (const sub of editors) {
      if (!sub) continue
      dropActiveSubEditor(sub)
      sub.destroy()
    }
  }
  return { cleanup, sync, setEditable, commit }
}

/** drag the corner handle of a selected image to resize it */
function imageResizePlugin(): Plugin {
  return new Plugin({
    props: {
      handleDOMEvents: {
        mousedown: (view, event) => {
          const target = event.target as HTMLElement
          if (target.classList?.contains('box-resize-handle')) {
            const boxWrapper = target.closest('.doc-protected') as HTMLElement | null
            const isChart = !!boxWrapper?.classList.contains('doc-protected-chart')
            const boxEl = boxWrapper?.querySelector(
              isChart ? '.doc-chart-canvas svg' : '.doc-textbox',
            ) as HTMLElement | null
            if (!boxWrapper || !boxEl) return false
            let boxPos = -1
            view.state.doc.descendants((node, p) => {
              if (boxPos !== -1) return false
              if (node.type.name === 'docProtected' && view.nodeDOM(p) === boxWrapper) boxPos = p
              return boxPos === -1
            })
            if (boxPos === -1) return false
            const attrs = view.state.doc.nodeAt(boxPos)?.attrs
            const boxes = attrs?.textboxes as TextboxDisplay[] | null
            const chart = attrs?.chartDisplay as ChartDisplay | null
            if (!isChart && (!Array.isArray(boxes) || boxes.length !== 1)) return false
            if (isChart && !chart) return false
            event.preventDefault()
            view.dispatch(view.state.tr.setSelection(NodeSelection.create(view.state.doc, boxPos)))

            const zoomEl = document.querySelector('.doc-zoom') as HTMLElement | null
            const zoom = zoomEl ? parseFloat(getComputedStyle(zoomEl).zoom || '1') || 1 : 1
            const startRect = boxEl.getBoundingClientRect()
            const startW = isChart
              ? startRect.width / zoom
              : parseFloat(getComputedStyle(boxEl).width) || boxes![0].widthPx || 189
            const startH = isChart
              ? startRect.height / zoom
              : parseFloat(getComputedStyle(boxEl).height) || boxes![0].heightPx || 113
            const startX = event.clientX
            const startY = event.clientY

            // horizontal lines resize in length only (their saved extent is zero-height)
            const lockH = !isChart && isStraightLineKind(boxes![0].prst)
            const minW = isChart ? 120 : 24
            const minH = isChart ? 80 : 8
            // charts never draw wider than the render cap, so don't let the model exceed it
            const maxW = isChart ? CHART_MAX_WIDTH_PX : Infinity
            const sizeAt = (e: MouseEvent) => ({
              w: Math.min(maxW, Math.max(minW, startW + (e.clientX - startX) / zoom)),
              h: lockH ? startH : Math.max(minH, startH + (e.clientY - startY) / zoom),
            })
            const onMove = (e: MouseEvent) => {
              const { w, h } = sizeAt(e)
              boxEl.style.width = `${w}px`
              boxEl.style.height = `${h}px`
            }
            const onUp = (e: MouseEvent) => {
              window.removeEventListener('mousemove', onMove)
              window.removeEventListener('mouseup', onUp)
              const { w, h } = sizeAt(e)
              const node = view.state.doc.nodeAt(boxPos)
              if (!node) return
              if (isChart) {
                const display = node.attrs.chartDisplay as ChartDisplay | null
                if (!display) return
                view.dispatch(
                  view.state.tr.setNodeMarkup(boxPos, undefined, {
                    ...node.attrs,
                    chartDisplay: {
                      ...display,
                      widthPx: Math.round(w),
                      // the handle measures the plot SVG; heightPx spans title row + plot
                      heightPx:
                        Math.round(h) + (display.title !== undefined ? CHART_TITLE_ROW_PX : 0),
                    },
                  }),
                )
                return
              }
              const box = (node.attrs.textboxes as TextboxDisplay[] | null)?.[0]
              if (!box) return
              // straight lines keep their zero-height extent: never give them a heightPx
              const next = lockH
                ? { ...box, widthPx: Math.round(w) }
                : {
                    ...box,
                    widthPx: Math.round(w),
                    heightPx: Math.round(h),
                    minHeightPx: Math.round(h),
                  }
              view.dispatch(
                view.state.tr.setNodeMarkup(boxPos, undefined, {
                  ...node.attrs,
                  textboxes: [next],
                }),
              )
            }
            window.addEventListener('mousemove', onMove)
            window.addEventListener('mouseup', onUp)
            return true
          }
          const handle = target.closest('.img-resize-handle') as HTMLElement | null
          const direction = handle?.dataset.resizeHandle as ImageResizeHandle | undefined
          if (!handle || !direction || !IMAGE_RESIZE_HANDLES.includes(direction)) return false
          const wrapper = handle.closest('.doc-protected') as HTMLElement | null
          const imageBox = handle.closest('.doc-img-wrap') as HTMLElement | null
          const img = wrapper?.querySelector('img.doc-protected-img') as HTMLImageElement | null
          if (!wrapper || !imageBox || !img) return false
          event.preventDefault()
          event.stopPropagation()

          let pos = -1
          view.state.doc.descendants((node, p) => {
            if (pos !== -1) return false
            if (node.type.name === 'docProtected' && view.nodeDOM(p) === wrapper) pos = p
            return pos === -1
          })
          if (pos === -1) return false

          view.dispatch(view.state.tr.setSelection(NodeSelection.create(view.state.doc, pos)))
          view.focus()

          // CSS `zoom` scales client coordinates; divide it back out
          const zoomEl = document.querySelector('.doc-zoom') as HTMLElement | null
          const zoom = zoomEl ? parseFloat(getComputedStyle(zoomEl).zoom || '1') || 1 : 1
          // Layout-box measurements: getBoundingClientRect would include the
          // rotation/flip transform, swapping width/height for 90°-rotated images
          const selectedNode = view.state.doc.nodeAt(pos)
          const modelW = Number(selectedNode?.attrs.imageWidthPx)
          const modelH = Number(selectedNode?.attrs.imageHeightPx)
          const startW = modelW > 0 ? modelW : imageBox.offsetWidth || img.offsetWidth
          const startH = modelH > 0 ? modelH : imageBox.offsetHeight || img.offsetHeight
          if (!(startW > 0) || !(startH > 0)) return false
          const priorBoxStyle = imageBox.getAttribute('style')
          const priorImgStyle = img.getAttribute('style')
          const cropped = imageBox.classList.contains('doc-img-crop')
          const startImgW = parseFloat(img.style.width) || img.offsetWidth || startW
          const startImgH = parseFloat(img.style.height) || img.offsetHeight || startH
          const startImgLeft = parseFloat(img.style.left) || 0
          const startImgTop = parseFloat(img.style.top) || 0
          const pxLeft = /^-?\d+(?:\.\d+)?px$/.test(imageBox.style.left)
            ? parseFloat(imageBox.style.left)
            : null
          const pxTop = /^-?\d+(?:\.\d+)?px$/.test(imageBox.style.top)
            ? parseFloat(imageBox.style.top)
            : null
          const shiftsInFlow = imageBox.style.position !== 'absolute'
          const startX = event.clientX
          const startY = event.clientY
          const west = direction.includes('w')
          const east = direction.includes('e')
          const north = direction.includes('n')
          const south = direction.includes('s')

          const geometryAt = (e: MouseEvent) => {
            const dx = (e.clientX - startX) / zoom
            const dy = (e.clientY - startY) / zoom
            let w = startW
            let h = startH
            if ((west || east) && (north || south)) {
              // Project the pointer onto the aspect-ratio diagonal. Corner
              // handles keep picture proportions, matching Word's default.
              const sx = west ? -1 : 1
              const sy = north ? -1 : 1
              const delta =
                (dx * sx * startW + dy * sy * startH) /
                Math.max(1, startW * startW + startH * startH)
              const minScale = Math.max(24 / startW, 24 / startH)
              const scale = Math.max(minScale, 1 + delta)
              w = startW * scale
              h = startH * scale
            } else if (west || east) {
              w = Math.max(24, startW + (west ? -dx : dx))
            } else if (north || south) {
              h = Math.max(24, startH + (north ? -dy : dy))
            }
            return {
              w,
              h,
              shiftX: west ? startW - w : 0,
              shiftY: north ? startH - h : 0,
            }
          }

          const restorePreview = () => {
            if (priorBoxStyle === null) imageBox.removeAttribute('style')
            else imageBox.setAttribute('style', priorBoxStyle)
            if (priorImgStyle === null) img.removeAttribute('style')
            else img.setAttribute('style', priorImgStyle)
          }
          const onMove = (e: MouseEvent) => {
            const { w, h, shiftX, shiftY } = geometryAt(e)
            imageBox.style.width = `${w}px`
            imageBox.style.height = `${h}px`
            if (pxLeft !== null) imageBox.style.left = `${pxLeft + shiftX}px`
            else if (west && shiftsInFlow) imageBox.style.left = `${shiftX}px`
            if (pxTop !== null) imageBox.style.top = `${pxTop + shiftY}px`
            else if (north && shiftsInFlow) imageBox.style.top = `${shiftY}px`
            if (cropped) {
              const sx = w / startW
              const sy = h / startH
              img.style.left = `${startImgLeft * sx}px`
              img.style.top = `${startImgTop * sy}px`
              img.style.width = `${startImgW * sx}px`
              img.style.height = `${startImgH * sy}px`
            } else {
              img.style.width = `${w}px`
              img.style.height = `${h}px`
            }
          }
          const onUp = (e: MouseEvent) => {
            window.removeEventListener('mousemove', onMove)
            window.removeEventListener('mouseup', onUp)
            // A plain click on the handle must not rewrite the stored size
            if (Math.abs(e.clientX - startX) < 2 && Math.abs(e.clientY - startY) < 2) {
              restorePreview()
              return
            }
            const node = view.state.doc.nodeAt(pos)
            if (!node) {
              restorePreview()
              return
            }
            const geometry = geometryAt(e)
            const w = Math.round(geometry.w)
            const h = Math.round(geometry.h)
            const attrs: Record<string, unknown> = {
              ...node.attrs,
              imageWidthPx: w,
              imageHeightPx: h,
            }
            if (west && node.attrs.imageOffsetXEmu != null) {
              attrs.imageOffsetXEmu =
                Number(node.attrs.imageOffsetXEmu) + Math.round((startW - w) * EMU_PER_PX)
            }
            if (north && node.attrs.imageOffsetYEmu != null) {
              attrs.imageOffsetYEmu =
                Number(node.attrs.imageOffsetYEmu) + Math.round((startH - h) * EMU_PER_PX)
            }
            view.dispatch(view.state.tr.setNodeMarkup(pos, undefined, attrs))
          }
          window.addEventListener('mousemove', onMove)
          window.addEventListener('mouseup', onUp)
          return true
        },
      },
    },
  })
}

const EMU_PER_PX = 9525

/**
 * Drag floating images and textbox shapes (wp:anchor) to update posOffset.
 * Only handles images with numeric posOffset (imageOffsetXEmu/YEmu set).
 * Inline images (no imageWrap) are auto-converted to anchor on drag start
 * with square wrap and the initial offset derived from the drag delta.
 */
/** Is the point on an actual text glyph (not just inside a text block's box)? */
function pointOnTextGlyph(x: number, y: number): boolean {
  const range = document.caretRangeFromPoint(x, y)
  const tn = range?.startContainer
  // `Node` in this module is TipTap's node class, so use the DOM Text check
  if (!range || !(tn instanceof Text)) return false
  const probe = document.createRange()
  probe.setStart(tn, Math.max(0, range.startOffset - 1))
  probe.setEnd(tn, Math.min(tn.length, range.startOffset + 1))
  for (const r of probe.getClientRects()) {
    if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return true
  }
  return false
}

/**
 * Word parity: a press on empty text area falls through to the floating
 * picture painted below. Behind-text images are covered by the text layer's
 * hit box, so plain DOM hit-testing can never reach them; glyphs still win
 * (clicking on a character places the caret, like Word).
 */
export function findFloatImageAt(x: number, y: number): HTMLElement | null {
  if (pointOnTextGlyph(x, y)) return null
  for (const el of document.elementsFromPoint(x, y)) {
    if (!(el instanceof HTMLElement)) continue
    const wrap = el.classList.contains('doc-img-wrap')
      ? el
      : (el.closest('.doc-img-wrap') as HTMLElement | null)
    if (wrap && wrap.closest('.doc-img-float')) return wrap
  }
  return null
}

interface ImageParagraphAnchor {
  pos: number
  node: PmNode
  dom: HTMLElement
  rect: DOMRect
}

const IMAGE_ANCHOR_NODE_TYPES = new Set(['docParagraph', 'docHeading', 'docListItem'])

function imageParagraphAnchors(view: EditorView, imagePos: number): ImageParagraphAnchor[] {
  const anchors: ImageParagraphAnchor[] = []
  view.state.doc.forEach((node, pos) => {
    if (pos === imagePos || !IMAGE_ANCHOR_NODE_TYPES.has(node.type.name)) return
    const dom = view.nodeDOM(pos)
    if (!(dom instanceof HTMLElement)) return
    anchors.push({ pos, node, dom, rect: dom.getBoundingClientRect() })
  })
  return anchors
}

function pickImageParagraphAnchor(
  anchors: ImageParagraphAnchor[],
  x: number,
  y: number,
): ImageParagraphAnchor | null {
  let best: ImageParagraphAnchor | null = null
  let bestScore = Infinity
  for (const anchor of anchors) {
    const rect = anchor.dom.getBoundingClientRect()
    anchor.rect = rect
    const dy = y < rect.top ? rect.top - y : y > rect.bottom ? y - rect.bottom : 0
    const dx = x < rect.left ? rect.left - x : x > rect.right ? x - rect.right : 0
    // Vertical proximity determines the paragraph; horizontal proximity only
    // breaks ties for multi-column lines at a similar Y.
    const score = dy * 10000 + dx
    // Stacked paragraphs share a bottom/top edge. At that exact boundary,
    // prefer the paragraph beginning there instead of the one that just ended.
    if (score < bestScore || (score === bestScore && rect.top > (best?.rect.top ?? -Infinity))) {
      best = anchor
      bestScore = score
    }
  }
  return best
}

function floatingObjectDragPlugin(): Plugin {
  return new Plugin({
    props: {
      handleDOMEvents: {
        mousedown: (view, event) => {
          if (event.button !== 0) return false
          const target = event.target as HTMLElement | null
          if (!target) return false
          // Activate on the move handle of an image block, anywhere on the
          // image body (Word parity: grab the picture itself), or on a
          // textbox/shape body — its text isn't edited in place, so the
          // body gesture is unambiguous
          const handle = target.closest('.doc-move-handle') as HTMLElement | null
          const body = handle ? null : (target.closest('.doc-textbox') as HTMLElement | null)
          let imgBody: HTMLElement | null = null
          if (
            !handle &&
            !body &&
            !target.closest('.img-resize-handle') &&
            !document.body.classList.contains('docs-crop-active')
          ) {
            imgBody = target.closest('.doc-img-wrap') as HTMLElement | null
            // behind-text pictures sit under the text layer: a press that
            // hits no glyph falls through to the picture painted below
            if (!imgBody) imgBody = findFloatImageAt(event.clientX, event.clientY)
          }
          if (!handle && !body && !imgBody) return false
          const wrapper = (handle ?? body ?? imgBody)!.closest(
            '.doc-protected',
          ) as HTMLElement | null
          if (!wrapper) return false

          // Find the ProseMirror node position
          let pos = -1
          view.state.doc.descendants((node, p) => {
            if (pos !== -1) return false
            if (node.type.name === 'docProtected' && view.nodeDOM(p) === wrapper) pos = p
            return pos === -1
          })
          if (pos === -1) return false
          const node = view.state.doc.nodeAt(pos)
          if (!node) return false
          const isImage = node.attrs.blockType === 'image'
          const isTextbox = Array.isArray(node.attrs.textboxes) && node.attrs.textboxes.length > 0
          if (!isImage && !isTextbox) return false
          // Body activation is for prst shapes and pictures: plain text
          // boxes keep click-to-type
          const isShapeBody = isTextbox && !!(node.attrs.textboxes as TextboxDisplay[])[0]?.prst
          if (!handle && !isShapeBody && !(imgBody && isImage)) return false

          event.preventDefault()
          event.stopPropagation()
          view.dispatch(view.state.tr.setSelection(NodeSelection.create(view.state.doc, pos)))
          // preventDefault suppressed the native focus: restore it, or
          // keyboard follow-ups (Delete, undo, arrows) go nowhere
          view.focus()

          const zoomEl = document.querySelector('.doc-zoom') as HTMLElement | null
          const zoom = zoomEl ? parseFloat(getComputedStyle(zoomEl).zoom || '1') || 1 : 1
          const startX = event.clientX
          const startY = event.clientY
          // Start position of the picture in its offset space (px). When the
          // attrs carry no numeric offset (fresh floats, align presets,
          // inline pictures) derive it from the rendered slot, so the drop
          // lands exactly where the user let go instead of jumping.
          const innerWrap = wrapper.querySelector('.doc-img-wrap') as HTMLElement | null
          const startVisualRect = (innerWrap ?? wrapper).getBoundingClientRect()
          const wrapperStartRect = wrapper.getBoundingClientRect()
          const anchorLocked = !!node.attrs.imageAnchorLocked
          const paragraphAnchors = isImage && !anchorLocked ? imageParagraphAnchors(view, pos) : []
          let paragraphAnchor: ImageParagraphAnchor | null = null
          const wrapMode = (node.attrs.imageWrap as string | null) ?? null
          const isSideFloat = !!wrapMode && /^(?:square|tight|through)-/.test(wrapMode)
          const imgW = innerWrap?.offsetWidth || Number(node.attrs.imageWidthPx ?? 0) || 0
          // the containing block the offsets resolve against (column width)
          let colW = wrapper.clientWidth
          if (isSideFloat && wrapper.parentElement) {
            const pcs = getComputedStyle(wrapper.parentElement)
            colW =
              wrapper.parentElement.clientWidth -
              (parseFloat(pcs.paddingLeft) || 0) -
              (parseFloat(pcs.paddingRight) || 0)
          }
          const attrX = node.attrs.imageOffsetXEmu
          const attrY = node.attrs.imageOffsetYEmu
          let startPxX: number
          if (attrX != null) {
            startPxX = Number(attrX) / EMU_PER_PX
          } else if (!wrapMode && innerWrap) {
            // inline picture: measure the visual spot inside its paragraph
            const wr = wrapper.getBoundingClientRect()
            const ir = innerWrap.getBoundingClientRect()
            startPxX = (ir.left - wr.left) / zoom
          } else {
            const posH = node.attrs.imagePosH as string | null
            const slot = wrapMode?.endsWith('-right')
              ? 'right'
              : wrapMode === 'topBottom' || posH === 'center'
                ? 'center'
                : posH === 'right'
                  ? 'right'
                  : 'left'
            startPxX =
              slot === 'center'
                ? Math.max(0, (colW - imgW) / 2)
                : slot === 'right'
                  ? Math.max(0, colW - imgW)
                  : 0
          }
          const startPxY = attrY != null ? Number(attrY) / EMU_PER_PX : 0

          // Visual feedback: apply CSS translate during drag. Cropped pictures put
          // rot/flip (and the front/behind offset) on the overflow-hidden crop
          // wrapper — translate that, or the image slides inside the fixed window
          const visual = wrapper.querySelector(
            isTextbox ? '.doc-textbox' : '.doc-img-crop, .doc-protected-img',
          ) as HTMLElement | null
          // Images may already carry a rotation/flip transform: the drag translate
          // must compose with it (prepended = applied in screen space) and the
          // original must come back on mouseup, or the orientation vanishes
          const baseTransform = visual?.style.transform ?? ''
          const anchorMarker = isImage
            ? (wrapper.querySelector('.doc-image-anchor-marker') as HTMLElement | null)
            : null
          const anchorMarkerTransform = anchorMarker?.style.transform ?? ''
          const anchorMarkerLeft = anchorMarker?.style.left ?? ''

          // 3px threshold keeps plain clicks (select, first click of a
          // double-click-to-edit) from nudging the object
          let dragging = false
          const onMove = (e: MouseEvent) => {
            const dx = (e.clientX - startX) / zoom
            const dy = (e.clientY - startY) / zoom
            if (!dragging && Math.abs(dx) < 3 && Math.abs(dy) < 3) return
            dragging = true
            if (visual) {
              visual.style.transform =
                `translate(${dx}px, ${dy}px)` + (baseTransform ? ` ${baseTransform}` : '')
            }
            if (isImage) {
              const clientDx = e.clientX - startX
              const clientDy = e.clientY - startY
              paragraphAnchor = pickImageParagraphAnchor(
                paragraphAnchors,
                startVisualRect.left + clientDx,
                startVisualRect.top + clientDy,
              )
              if (anchorMarker && paragraphAnchor) {
                const markerY = (paragraphAnchor.rect.top - wrapperStartRect.top) / zoom
                const markerX = (paragraphAnchor.rect.left - wrapperStartRect.left) / zoom - 32
                anchorMarker.style.transform = `translateY(${markerY.toFixed(1)}px)`
                anchorMarker.style.left = `${markerX.toFixed(1)}px`
                anchorMarker.dataset.anchorTargetPos = String(paragraphAnchor.pos)
              }
            }
          }

          const onUp = (e: MouseEvent) => {
            window.removeEventListener('mousemove', onMove)
            window.removeEventListener('mouseup', onUp)
            if (visual) visual.style.transform = baseTransform
            if (anchorMarker) {
              anchorMarker.style.transform = anchorMarkerTransform
              anchorMarker.style.left = anchorMarkerLeft
              delete anchorMarker.dataset.anchorTargetPos
            }

            const dx = (e.clientX - startX) / zoom
            const dy = (e.clientY - startY) / zoom
            // Only commit a real drag (past the threshold)
            if (!dragging) return

            // Word allows negative offsets (into the page margin / above the
            // anchor paragraph): no clamping
            const newX = Math.round((startPxX + dx) * EMU_PER_PX)
            if (isImage) {
              paragraphAnchor = pickImageParagraphAnchor(
                paragraphAnchors,
                startVisualRect.left + (e.clientX - startX),
                startVisualRect.top + (e.clientY - startY),
              )
            }
            const newY = Math.round(
              (paragraphAnchor
                ? (startVisualRect.top + (e.clientY - startY) - paragraphAnchor.rect.top) / zoom
                : startPxY + dy) * EMU_PER_PX,
            )

            const currentNode = view.state.doc.nodeAt(pos)
            if (!currentNode) return
            if (isTextbox) {
              view.dispatch(
                view.state.tr.setNodeMarkup(pos, undefined, {
                  ...currentNode.attrs,
                  imageWrap: currentNode.attrs.imageWrap ?? 'square-left',
                  imageOffsetXEmu: newX,
                  imageOffsetYEmu: newY,
                  imagePosH: null,
                  imagePosV: null,
                }),
              )
            } else {
              // pictures keep their wrap kind, but square/tight/through (and
              // fresh inline conversions) re-pick the wrap side from the drop
              // position — Word wraps text on the open side of the picture
              const prev = (currentNode.attrs.imageWrap as string | null) ?? null
              const kindMatch = prev ? /^(square|tight|through)-(?:left|right)$/.exec(prev) : null
              let nextWrap = prev ?? 'square-left'
              if (!prev || kindMatch) {
                const kind = kindMatch?.[1] ?? 'square'
                const centerX = startPxX + dx + imgW / 2
                nextWrap = `${kind}-${colW > 0 && centerX > colW / 2 ? 'right' : 'left'}`
              }
              const attrs = {
                ...currentNode.attrs,
                imageWrap: nextWrap,
                imageOffsetXEmu: newX,
                imageOffsetYEmu: newY,
                imagePosH: null,
                imagePosV: null,
              }
              if (
                paragraphAnchor &&
                !currentNode.attrs.imageAnchorLocked &&
                !currentNode.attrs.blockRevision
              ) {
                // A floating picture's top-level atom is its OOXML anchor
                // paragraph. Move that atom immediately before the paragraph
                // selected by the drag, preserving docxIndex as the patch
                // identity and rebasing Y to the new paragraph above.
                const movedNode = currentNode.type.create(
                  attrs,
                  currentNode.content,
                  currentNode.marks,
                )
                const tr = view.state.tr.delete(pos, pos + currentNode.nodeSize)
                const insertPos = tr.mapping.map(paragraphAnchor.pos)
                tr.insert(insertPos, movedNode)
                tr.setSelection(NodeSelection.create(tr.doc, insertPos))
                view.dispatch(tr)
              } else {
                view.dispatch(view.state.tr.setNodeMarkup(pos, undefined, attrs))
              }
            }
          }

          window.addEventListener('mousemove', onMove)
          window.addEventListener('mouseup', onUp)
          return true
        },
      },
    },
  })
}

export type DomSpec = [string, Record<string, string>, ...unknown[]]

/**
 * Paragraph node for textbox sub-editors. Named docParagraph on purpose so
 * ribbon paragraph commands (updateAttributes('docParagraph', ...)) work
 * unchanged whether they target the main editor or a textbox.
 */
const TextboxParagraph = Node.create({
  name: 'docParagraph',
  group: 'block',
  content: 'inline*',
  addAttributes() {
    return {
      styleId: { default: null as string | null },
      align: { default: null as string | null },
      lineSpacing: { default: null as number | null },
      lineRule: { default: null as string | null },
      lineRawTwips: { default: null as number | null },
      snapToGrid: { default: null as boolean | null },
      indentLeft: { default: null as number | null },
      indentRight: { default: null as number | null },
      indentFirstLine: { default: null as number | null },
      spaceBefore: { default: null as number | null },
      spaceAfter: { default: null as number | null },
      spaceBeforeAuto: { default: null as boolean | null },
      spaceAfterAuto: { default: null as boolean | null },
      shadingFill: { default: null as string | null },
      borders: { default: null as string | null },
    }
  },
  parseHTML() {
    return [{ tag: 'div.doc-textbox-para' }, { tag: 'p' }]
  },
  renderHTML({ node }) {
    // same line strut rules as the main editor's blockAttrs (Word applies the
    // typed line grid inside textboxes too; w:snapToGrid=0 opts out): without
    // them every CJK textbox line inherited the body's grid pixel value
    const lineRule = (node.attrs.lineRule as 'auto' | 'atLeast' | 'exact' | null) ?? undefined
    const lineRawTwips =
      node.attrs.lineRawTwips != null ? Number(node.attrs.lineRawTwips) : undefined
    const lineSpacing = node.attrs.lineSpacing ? Number(node.attrs.lineSpacing) : undefined
    const classes = ['doc-textbox-para']
    if (node.content.size === 0) classes.push('doc-textbox-para-empty')
    if ((lineRule === 'exact' && lineRawTwips) || lineRule === 'atLeast')
      classes.push('doc-lh-fixed')
    if (node.attrs.snapToGrid === false) classes.push('doc-nosnap')
    const attrs: Record<string, string> = { class: classes.join(' ') }
    if (node.attrs.styleId) attrs['data-style'] = String(node.attrs.styleId)
    const fontStyles: string[] = []
    if (node.textContent) {
      fontStyles.push(`--doc-line-factor:${paraLineFactor(node)}`)
      const fam = paraDeclaredFontFamily(node)
      if (fam) fontStyles.push(`font-family:${fam}`)
      const strut = explicitStrutHalfPoints(node)
      if (strut)
        fontStyles.push(`--doc-strut:${strut / 2}pt`, 'font-size:min(var(--doc-strut), 1em)')
    }
    const mult = cssAutoLineMult(lineRule, lineRawTwips, lineSpacing)
    const styles = [
      node.attrs.align
        ? `text-align:${node.attrs.align === 'distribute' ? 'justify' : node.attrs.align}`
        : '',
      ...fontStyles,
      cssLineHeight(lineRule, lineRawTwips, lineSpacing)
        ? `line-height:${cssLineHeight(lineRule, lineRawTwips, lineSpacing)}`
        : '',
      // explicit single (mult 1) still overrides an inherited style/doc multiple
      mult ? `--doc-line-mult:${mult}` : '',
      node.attrs.snapToGrid === false ? '--doc-grid-pitch:0.0001px' : '',
      node.attrs.indentLeft ? `margin-left:${Number(node.attrs.indentLeft) / 20}pt` : '',
      node.attrs.indentRight ? `margin-right:${Number(node.attrs.indentRight) / 20}pt` : '',
      node.attrs.indentFirstLine ? `text-indent:${Number(node.attrs.indentFirstLine) / 20}pt` : '',
      node.attrs.spaceBeforeAuto
        ? `margin-top:${WORD_AUTO_SPACING_PT}pt`
        : node.attrs.spaceBefore != null
          ? `margin-top:${Number(node.attrs.spaceBefore) / 20}pt`
          : '',
      node.attrs.spaceAfterAuto
        ? `margin-bottom:${WORD_AUTO_SPACING_PT}pt`
        : node.attrs.spaceAfter != null
          ? `margin-bottom:${Number(node.attrs.spaceAfter) / 20}pt`
          : '',
      node.attrs.shadingFill ? `background-color:#${node.attrs.shadingFill}` : '',
    ]
      .filter(Boolean)
      .join(';')
    if (styles) attrs.style = styles
    return ['div', attrs, 0]
  },
})

/** shared with the main editor: same mark names, so ribbon commands route 1:1 */
const textboxSubExtensions = [
  Node.create({ name: 'doc', topNode: true, content: 'block+' }),
  DocText,
  DocHardBreak,
  TextboxParagraph,
  TabStopExtension,
  InactiveSelectionExtension,
  BoldMark,
  ItalicMark,
  UnderlineMark,
  StrikeMark,
  LinkMark,
  // research-report sidebars keep PAGE/date/REF fields inside textbox tables;
  // without these marks the whole box fails to load into the sub-editor
  RefFieldMark,
  InstrFieldMark,
  TextStyleMark,
  CommentMark,
  UndoRedo,
]

// ---- find & replace highlighting ----

export interface SearchHighlight {
  ranges: Array<{ from: number; to: number }>
  activeIndex: number
}

export const editorExtensions = [
  DocDocument,
  DocText,
  DocHardBreak,
  DocNoteRef,
  DocXeMark,
  DocRuby,
  DocInlineImage,
  DocInlineMath,
  DocParagraph,
  DocHeading,
  DocListItem,
  DocTable,
  DocTableRow,
  DocTableCell,
  DocTableHeader,
  DocNestedTable,
  DocCellBoxes,
  DocProtected,
  BoldMark,
  ItalicMark,
  UnderlineMark,
  StrikeMark,
  LinkMark,
  RefFieldMark,
  InstrFieldMark,
  RprChangeMark,
  TextStyleMark,
  CommentMark,
  InsMark,
  DelMark,
  UndoRedo,
  SearchHighlightExtension,
  PendingCommentHighlightExtension,
  ResolvedCommentsExtension,
  NativeTableSupport,
  TableHandle,
  TrackChangesExtension,
  LineFactorExtension,
  ListNumberingExtension,
  PaginationGapsExtension,
  InactiveSelectionExtension,
  AiQueueAnchorsExtension,
  PageGapNavExtension,
  ImageCopyExtension,
  EnterReplacesSelection,
  WordEditorShortcuts,
  CaretMarksMemory,
  ColumnLayoutExtension,
  TabStopExtension,
  WsRunLineHeightExtension,
  DropCapExtension,
  ParaBorderMergeExtension,
  SdtExtension,
  MoveRevisionExtension,
  PPrChangeExtension,
  ParaMarkDelExtension,
  RevisionOriginalExtension,
  AutoDirectionExtension,
]

import { useEffect, useRef, useState } from 'react'
import type { Editor } from '@tiptap/core'
import type { Command } from '@tiptap/pm/state'
import { NodeSelection, TextSelection } from '@tiptap/pm/state'
import {
  CellSelection,
  addColumnAfter,
  addColumnBefore,
  addRowAfter,
  addRowBefore,
  deleteColumn,
  deleteRow,
  deleteTable,
  isInTable,
  mergeCells,
  selectedRect,
  splitCell,
} from '@tiptap/pm/tables'
import { platformShortcuts } from '@genoffice/i18n'
import { Dropdown, isSymbolFontFamily, type DropdownOption } from '@genoffice/ui'
import { useI18n, type StringKey } from '../i18n/locale'
import { fontFamiliesFor, isEastAsianFontName } from '../font-list'
import { useSystemFontFamilies } from '../system-fonts'
import { cssFontFamily } from '../line-metrics'
import { setParaAttrs, activeParaAttrs } from './ribbon-tabs'
import { setSelectionAlign } from '../editor/direction'
import { IconSparkle } from './icons'
import { useModalKeys } from './modal-keys'

/**
 * Editor context menu (right click in the document body):
 * Cut/Copy/Paste · Font… · Paragraph… · Synonyms · Translate · Hyperlink… · New Comment.
 */

export interface ContextMenuState {
  x: number
  y: number
}

interface EditorContextMenuProps {
  editor: Editor
  menu: ContextMenuState
  onClose: () => void
  onFontDialog: () => void
  onParagraphDialog: () => void
  onLink: () => void
  onNewComment: () => void
  onAiPreset: (instruction: string) => void
  /** List items: restart numbering / continue numbering (shown when the cursor is on a docListItem) */
  onRestartNumbering?: () => void
  onContinueNumbering?: () => void
  /** F9 update fields (shown when the cursor is on an inline field) */
  onUpdateFields?: () => void
}

/** target languages mirrored from the Review → Translate dropdown; the localized label also goes into the LLM prompt */
const TRANSLATE_TARGETS: Array<{ labelKey: StringKey }> = [
  { labelKey: 'appLangEnglish' },
  { labelKey: 'appLangSimplifiedChinese' },
  { labelKey: 'appLangJapanese' },
  { labelKey: 'appLangKorean' },
  { labelKey: 'appLangFrench' },
  { labelKey: 'appLangGerman' },
  { labelKey: 'appLangSpanish' },
]

const MENU_WIDTH = 240

export function EditorContextMenu({
  editor,
  menu,
  onClose,
  onFontDialog,
  onParagraphDialog,
  onLink,
  onNewComment,
  onAiPreset,
  onRestartNumbering,
  onContinueNumbering,
  onUpdateFields,
}: EditorContextMenuProps) {
  const { t } = useI18n()
  const ref = useRef<HTMLDivElement>(null)
  const [submenu, setSubmenu] = useState<string | null>(null)

  const { from, to } = editor.state.selection
  const hasSelection = from !== to
  const canEdit = editor.isEditable
  const selectedText = hasSelection ? editor.state.doc.textBetween(from, to, ' ').trim() : ''
  // Synonyms targets a word / short phrase, not long selections
  const synonymText = selectedText.length > 0 && selectedText.length <= 20 ? selectedText : ''

  // keep the menu inside the viewport (flip up / clamp left near the edges)
  const [pos, setPos] = useState({ left: menu.x, top: menu.y })
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    let left = menu.x
    let top = menu.y
    if (left + rect.width > window.innerWidth - 8) left = window.innerWidth - rect.width - 8
    if (top + rect.height > window.innerHeight - 8) top = Math.max(8, menu.y - rect.height)
    setPos({ left, top })
  }, [menu])

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) onClose()
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('mousedown', close)
    window.addEventListener('keydown', onKey)
    window.addEventListener('blur', onClose)
    // shell tab-strip presses never reach this document; the preload relays
    // them (app:chrome-pressed) so the menu still dismisses
    const offChrome = window.desktop?.onChromePressed?.(onClose)
    return () => {
      window.removeEventListener('mousedown', close)
      window.removeEventListener('keydown', onKey)
      window.removeEventListener('blur', onClose)
      offChrome?.()
    }
  }, [onClose])

  const run = (action: () => void) => () => {
    onClose()
    action()
  }

  // ---- table section (shown when the cursor is inside a table, Word parity) ----
  // the move handle selects the whole table as a NodeSelection, which isInTable
  // does not treat as "inside" — the menu must still offer the table commands then
  const tableSelected =
    editor.state.selection instanceof NodeSelection &&
    editor.state.selection.node.type.name === 'docTable'
  const inTable = isInTable(editor.state) || tableSelected
  /** cell commands can't run on a whole-table NodeSelection: drop the caret into the first cell */
  const enterFirstCell = () => {
    const sel = editor.state.selection
    if (sel instanceof NodeSelection && sel.node.type.name === 'docTable') {
      editor.view.dispatch(
        editor.state.tr.setSelection(TextSelection.near(editor.state.doc.resolve(sel.from + 1))),
      )
    }
  }
  const runTable = (command: Command) => {
    editor.view.focus()
    enterFirstCell()
    command(editor.state, editor.view.dispatch)
  }
  /** anchor cell of the current selection (top-left of a multi-cell selection) */
  const anchorCellPos = (): number | null => {
    if (!inTable) return null
    enterFirstCell()
    const rect = selectedRect(editor.state)
    return rect.tableStart + rect.map.map[rect.top * rect.map.width + rect.left]
  }
  const selectRowOrColumn = (kind: 'row' | 'column') => {
    const pos = anchorCellPos()
    if (pos === null) return
    const $cell = editor.state.doc.resolve(pos)
    const selection =
      kind === 'row' ? CellSelection.rowSelection($cell) : CellSelection.colSelection($cell)
    editor.view.focus()
    editor.view.dispatch(editor.state.tr.setSelection(selection))
  }
  const selectWholeTable = () => {
    const { $from } = editor.state.selection
    for (let depth = $from.depth; depth >= 1; depth--) {
      if ($from.node(depth).type.name === 'docTable') {
        editor.view.focus()
        editor.view.dispatch(
          editor.state.tr.setSelection(NodeSelection.create(editor.state.doc, $from.before(depth))),
        )
        return
      }
    }
  }

  const protAttrs = editor.getAttributes('docProtected')
  const isImage = protAttrs?.blockType === 'image'
  const isFloating =
    isImage ||
    (Array.isArray(protAttrs?.textboxes) && (protAttrs.textboxes as unknown[]).length > 0)
  const currentWrap = (protAttrs?.imageWrap as string | null) ?? null
  const setWrap = (wrap: string | null) => {
    const clearedPosition =
      wrap === null
        ? { imagePosH: null, imagePosV: null, imageOffsetXEmu: null, imageOffsetYEmu: null }
        : {}
    editor
      .chain()
      .focus()
      .updateAttributes('docProtected', { imageWrap: wrap, ...clearedPosition })
      .run()
  }
  // Stacking order among overlapping floating pictures. z-order only has a
  // visible effect on floating (front/behind) images, so the menu enables it
  // there; a bring-forward on an inline image also floats it (Word parity).
  const currentZOrder = Number((protAttrs?.imageZOrder as number | null) ?? 0)
  const isFloatingWrap = currentWrap === 'front' || currentWrap === 'behind'
  const setZOrder = (z: number) => {
    const attrs: Record<string, unknown> = { imageZOrder: z }
    // an inline image has no paint order; floating it (in front) makes the
    // reorder meaningful, matching Word's "Bring to Front" on an inline picture
    if (!isFloatingWrap) attrs.imageWrap = 'front'
    editor.chain().focus().updateAttributes('docProtected', attrs).run()
  }
  /** z-order of every floating anchor in the document (Word's to-front/to-back are document-global) */
  const floatingZOrders = (): number[] => {
    const zs: number[] = [currentZOrder]
    editor.state.doc.descendants((n) => {
      if (
        n.type.name === 'docProtected' &&
        (n.attrs.imageWrap === 'front' || n.attrs.imageWrap === 'behind')
      )
        zs.push(Number(n.attrs.imageZOrder ?? 0))
    })
    return zs
  }
  const bringToFront = () => setZOrder(Math.max(...floatingZOrders()) + 1)
  const sendToBack = () => setZOrder(Math.min(...floatingZOrders()) - 1)
  const bringForward = () => setZOrder(currentZOrder + 1)
  const sendBackward = () => setZOrder(currentZOrder - 1)

  /** Plain-text insertion: no HTML parsing (insertContent(string) would treat < > as tags) */
  const insertPlainText = (text: string) => {
    const lines = text.replace(/\r/g, '').split('\n')
    if (lines.length === 1) {
      editor.chain().focus().insertContent({ type: 'text', text: lines[0] }).run()
      return
    }
    editor
      .chain()
      .focus()
      .insertContent(
        lines.map((line) => ({
          type: 'docParagraph',
          ...(line ? { content: [{ type: 'text', text: line }] } : {}),
        })),
      )
      .run()
  }

  const clipboard = async (action: 'cut' | 'copy' | 'paste' | 'pastePlain') => {
    if (action === 'paste') {
      // rich paste: prefer HTML (parsed by editor paste rules, keeps formatting), otherwise plain text
      try {
        const items = await navigator.clipboard.read()
        for (const item of items) {
          if (item.types.includes('text/html')) {
            const html = await (await item.getType('text/html')).text()
            editor
              .chain()
              .focus()
              .insertContent(html, { parseOptions: { preserveWhitespace: true } })
              .run()
            return
          }
        }
      } catch {
        /* clipboard.read unavailable (permission/format): fall back to plain text */
      }
      const text = await navigator.clipboard.readText()
      if (text) insertPlainText(text)
    } else if (action === 'pastePlain') {
      const text = await navigator.clipboard.readText()
      if (text) insertPlainText(text)
    } else {
      editor.commands.focus()
      document.execCommand(action)
    }
  }

  const item = (
    label: string,
    opts: {
      key?: string
      disabled?: boolean
      onClick?: () => void
      submenuKey?: string
      ai?: boolean
    },
  ) => (
    <button
      className="ctx-item"
      disabled={opts.disabled}
      data-tip={opts.ai ? t('appAiBadgeTip') : undefined}
      onMouseEnter={() => setSubmenu(opts.submenuKey ?? null)}
      onClick={opts.submenuKey ? undefined : opts.onClick}
    >
      <span className="ctx-label">{label}</span>
      {opts.ai && (
        <span className="copilot-badge copilot-badge-menu">
          <IconSparkle size={10} />
        </span>
      )}
      {opts.key && <span className="ctx-key">{platformShortcuts(opts.key)}</span>}
      {opts.submenuKey && <span className="ctx-arrow">›</span>}
    </button>
  )

  return (
    <div
      ref={ref}
      className="ctx-menu"
      style={{ left: pos.left, top: pos.top, minWidth: MENU_WIDTH }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {item(t('appCut'), {
        key: '⌘X',
        disabled: !hasSelection || !canEdit,
        onClick: run(() => void clipboard('cut')),
      })}
      {item(t('appCopy'), {
        key: '⌘C',
        disabled: !hasSelection,
        onClick: run(() => void clipboard('copy')),
      })}
      {item(t('appPaste'), {
        key: '⌘V',
        disabled: !canEdit,
        onClick: run(() => void clipboard('paste')),
      })}
      {item(t('appPastePlain'), {
        disabled: !canEdit,
        onClick: run(() => void clipboard('pastePlain')),
      })}
      <div className="ctx-sep" />
      {item(t('appFontMenu'), { key: '⌘D', onClick: run(onFontDialog) })}
      {item(t('appParagraphMenu'), { key: '⌥⌘M', onClick: run(onParagraphDialog) })}
      {inTable && (
        <>
          <div className="ctx-sep" />
          <div className="ctx-item-wrap" onMouseLeave={() => setSubmenu(null)}>
            {item(t('ribbonInsert'), { submenuKey: 'tableInsert', disabled: !canEdit })}
            {submenu === 'tableInsert' && canEdit && (
              <div className="ctx-submenu">
                {(
                  [
                    ['ribbonInsertAbove', addRowBefore],
                    ['ribbonInsertBelow', addRowAfter],
                    ['ribbonInsertLeft', addColumnBefore],
                    ['ribbonInsertRight', addColumnAfter],
                  ] as Array<[StringKey, Command]>
                ).map(([labelKey, command]) => (
                  <button
                    key={labelKey}
                    className="ctx-item"
                    onClick={run(() => runTable(command))}
                  >
                    <span className="ctx-label">{t(labelKey)}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="ctx-item-wrap" onMouseLeave={() => setSubmenu(null)}>
            {item(t('ribbonTableDeleteMenu'), { submenuKey: 'tableDelete', disabled: !canEdit })}
            {submenu === 'tableDelete' && canEdit && (
              <div className="ctx-submenu">
                {(
                  [
                    ['ribbonDeleteRow', deleteRow],
                    ['ribbonDeleteColumn', deleteColumn],
                    ['ribbonDeleteTable', deleteTable],
                  ] as Array<[StringKey, Command]>
                ).map(([labelKey, command]) => (
                  <button
                    key={labelKey}
                    className="ctx-item"
                    onClick={run(() => runTable(command))}
                  >
                    <span className="ctx-label">{t(labelKey)}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="ctx-item-wrap" onMouseLeave={() => setSubmenu(null)}>
            {item(t('ribbonSelect'), { submenuKey: 'tableSelect' })}
            {submenu === 'tableSelect' && (
              <div className="ctx-submenu">
                <button className="ctx-item" onClick={run(() => selectRowOrColumn('row'))}>
                  <span className="ctx-label">{t('ribbonSelectRow')}</span>
                </button>
                <button className="ctx-item" onClick={run(() => selectRowOrColumn('column'))}>
                  <span className="ctx-label">{t('ribbonSelectColumn')}</span>
                </button>
                <button className="ctx-item" onClick={run(selectWholeTable)}>
                  <span className="ctx-label">{t('ribbonSelectTable')}</span>
                </button>
              </div>
            )}
          </div>
          {item(t('ribbonMergeCells'), {
            disabled: !canEdit || !mergeCells(editor.state),
            onClick: run(() => runTable(mergeCells)),
          })}
          {item(t('ribbonSplitCells'), {
            disabled: !canEdit || !splitCell(editor.state),
            onClick: run(() => runTable(splitCell)),
          })}
        </>
      )}
      {editor.isActive('instrField') && onUpdateFields && (
        <>
          <div className="ctx-sep" />
          {item(t('appUpdateField'), { key: 'F9', onClick: run(() => onUpdateFields()) })}
        </>
      )}
      {editor.isActive('docListItem') && !!editor.getAttributes('docListItem').numId && (
        <>
          <div className="ctx-sep" />
          {item(t('appRestartNumbering'), {
            disabled: !onRestartNumbering,
            onClick: run(() => onRestartNumbering?.()),
          })}
          {item(t('appContinueNumbering'), {
            disabled: !onContinueNumbering,
            onClick: run(() => onContinueNumbering?.()),
          })}
        </>
      )}
      <div className="ctx-sep" />
      {item(t('appSynonyms'), {
        disabled: !synonymText,
        ai: true,
        onClick: run(() => onAiPreset(t('appSynonymsPrompt', { text: synonymText }))),
      })}
      <div className="ctx-item-wrap" onMouseLeave={() => setSubmenu(null)}>
        {item(t('appTranslate'), { disabled: !hasSelection, submenuKey: 'translate', ai: true })}
        {submenu === 'translate' && hasSelection && (
          <div className="ctx-submenu">
            {TRANSLATE_TARGETS.map((target) => (
              <button
                key={target.labelKey}
                className="ctx-item"
                onClick={run(() =>
                  onAiPreset(
                    t('appTranslateSelectionPrompt', {
                      lang: t(target.labelKey),
                      text: selectedText,
                    }),
                  ),
                )}
              >
                <span className="ctx-label">
                  {t('appTranslateTo', { lang: t(target.labelKey) })}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
      {isFloating && (
        <>
          <div className="ctx-sep" />
          <div className="ctx-item-wrap" onMouseLeave={() => setSubmenu(null)}>
            {item(t('appWrapTextMenu'), { submenuKey: 'wrap' })}
            {submenu === 'wrap' && (
              <div className="ctx-submenu">
                {WRAP_OPTIONS.map((opt) => (
                  <button
                    key={String(opt.value)}
                    className="ctx-item"
                    onClick={run(() => setWrap(opt.value))}
                  >
                    <span className="ctx-label">
                      {currentWrap === opt.value ? '✓ ' : ''}
                      {t(opt.labelKey)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="ctx-item-wrap" onMouseLeave={() => setSubmenu(null)}>
            {item(t('appArrangeMenu'), { submenuKey: 'arrange' })}
            {submenu === 'arrange' && (
              <div className="ctx-submenu">
                <button className="ctx-item" onClick={run(bringToFront)}>
                  <span className="ctx-label">{t('appBringToFront')}</span>
                </button>
                <button className="ctx-item" onClick={run(bringForward)}>
                  <span className="ctx-label">{t('appBringForward')}</span>
                </button>
                <button className="ctx-item" onClick={run(sendBackward)}>
                  <span className="ctx-label">{t('appSendBackward')}</span>
                </button>
                <button className="ctx-item" onClick={run(sendToBack)}>
                  <span className="ctx-label">{t('appSendToBack')}</span>
                </button>
              </div>
            )}
          </div>
        </>
      )}
      <div className="ctx-sep" />
      {item(t('appHyperlinkMenu'), { key: '⌘K', onClick: run(onLink) })}
      {item(t('appNewComment'), { disabled: !hasSelection, onClick: run(onNewComment) })}
    </div>
  )
}

/** Wrap options from Word's image context menu (inline/square/top-bottom/behind text/in front of text); shared with the Picture Format tab */
export const WRAP_OPTIONS: Array<{ labelKey: StringKey; value: string | null }> = [
  { labelKey: 'appWrapInline', value: null },
  { labelKey: 'appWrapSquareLeft', value: 'square-left' },
  { labelKey: 'appWrapSquareRight', value: 'square-right' },
  { labelKey: 'appWrapTopBottom', value: 'topBottom' },
  { labelKey: 'appWrapBehind', value: 'behind' },
  { labelKey: 'appWrapFront', value: 'front' },
]

/* ================= Font dialog ================= */

const FONT_SIZES = [9, 10, 10.5, 11, 12, 14, 16, 18, 20, 22, 24, 28, 36, 48, 72]

const FONT_STYLES: Array<{ key: string; nameKey: StringKey }> = [
  { key: 'regular', nameKey: 'appFontRegular' },
  { key: 'italic', nameKey: 'appFontItalic' },
  { key: 'bold', nameKey: 'appFontBold' },
  { key: 'boldItalic', nameKey: 'appFontBoldItalic' },
]

export function FontDialog({ editor, onClose }: { editor: Editor; onClose: () => void }) {
  const { t, lang } = useI18n()
  const modalKeys = useModalKeys(onClose)
  const fontFamilies = fontFamiliesFor(lang)
  const { families: systemFontFamilies, load: loadSystemFonts } = useSystemFontFamilies()
  // the dialog opens from a click, so activation is still live here
  useEffect(() => loadSystemFonts(), [loadSystemFonts])
  const textAttrs = editor.getAttributes('docTextStyle')
  const initialStyle = editor.isActive('bold')
    ? editor.isActive('italic')
      ? 'boldItalic'
      : 'bold'
    : editor.isActive('italic')
      ? 'italic'
      : 'regular'

  const [font, setFont] = useState(
    (textAttrs.font as string | null) ?? (textAttrs.fontAscii as string | null) ?? '',
  )
  const [size, setSize] = useState(
    textAttrs.sizeHalfPoints ? Number(textAttrs.sizeHalfPoints) / 2 : 11,
  )
  const [style, setStyle] = useState<string>(initialStyle)
  const [color, setColor] = useState(`#${(textAttrs.color as string | null) ?? '000000'}`)
  const [underline, setUnderline] = useState(editor.isActive('underline'))
  const [strike, setStrike] = useState(editor.isActive('strike'))
  const [vertAlign, setVertAlign] = useState<string>((textAttrs.vertAlign as string | null) ?? '')

  const apply = () => {
    if (!editor.isEditable) {
      onClose()
      return
    }
    const hex = color.replace('#', '').toUpperCase()
    let chain = editor
      .chain()
      .focus()
      .setMark('docTextStyle', {
        color: hex === '000000' ? null : hex,
        sizeHalfPoints: Math.round(size * 2),
        // picks target only their script's rFonts slot; the other slot survives
        ...(!font
          ? { font: null, fontAscii: null }
          : isEastAsianFontName(font)
            ? { font }
            : { fontAscii: font }),
        highlight: textAttrs.highlight ?? null,
        vertAlign: vertAlign || null,
      })
    const wantBold = style === 'bold' || style === 'boldItalic'
    const wantItalic = style === 'italic' || style === 'boldItalic'
    chain = wantBold ? chain.setMark('bold') : chain.unsetMark('bold')
    chain = wantItalic ? chain.setMark('italic') : chain.unsetMark('italic')
    chain = underline ? chain.setMark('underline') : chain.unsetMark('underline')
    chain = strike ? chain.setMark('strike') : chain.unsetMark('strike')
    chain.run()
    onClose()
  }

  return (
    <div
      className="modal-backdrop"
      ref={modalKeys.ref}
      onKeyDown={modalKeys.onKeyDown}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="modal">
        <h2>{t('appFontDialogTitle')}</h2>
        <div className="font-dialog-row">
          <label>
            {t('appFontFamilyLabel')}
            <Dropdown
              value={font}
              ariaLabel={t('appFontFamilyLabel')}
              options={[
                { value: '', label: t('appDefaultBodyFont') } as DropdownOption,
                ...fontFamilies.map((f): DropdownOption => ({
                  value: f,
                  label: f,
                  render: <span style={{ fontFamily: cssFontFamily(f) }}>{f}</span>,
                })),
                ...systemFontFamilies.map((f): DropdownOption => ({
                  value: f,
                  label: f,
                  render: (
                    // symbol fonts would render their own name as pictographs
                    <span
                      style={{
                        fontFamily: isSymbolFontFamily(f) ? undefined : cssFontFamily(f),
                      }}
                    >
                      {f}
                    </span>
                  ),
                })),
                ...(font && !fontFamilies.includes(font) && !systemFontFamilies.includes(font)
                  ? [{ value: font, label: font } as DropdownOption]
                  : []),
              ]}
              onPick={setFont}
            />
          </label>
          <label>
            {t('appFontStyleLabel')}
            <Dropdown
              value={style}
              ariaLabel={t('appFontStyleLabel')}
              options={FONT_STYLES.map((s) => ({ value: s.key, label: t(s.nameKey) }))}
              onPick={setStyle}
            />
          </label>
          <label>
            {t('appFontSizeLabel')}
            <Dropdown
              value={String(size)}
              ariaLabel={t('appFontSizeLabel')}
              options={[
                ...(!FONT_SIZES.includes(size) ? [String(size)] : []),
                ...FONT_SIZES.map(String),
              ].map((s) => ({ value: s, label: s }))}
              onPick={(v) => setSize(Number(v))}
            />
          </label>
        </div>
        <div className="font-dialog-row">
          <label>
            {t('appFontColor')}
            <input
              type="color"
              className="font-color-input"
              value={color}
              onChange={(e) => setColor(e.target.value)}
            />
          </label>
          <label className="font-check">
            <input
              type="checkbox"
              checked={underline}
              onChange={(e) => setUnderline(e.target.checked)}
            />
            {t('appUnderline')}
          </label>
          <label className="font-check">
            <input type="checkbox" checked={strike} onChange={(e) => setStrike(e.target.checked)} />
            {t('appStrikethrough')}
          </label>
          <label className="font-check">
            <input
              type="checkbox"
              checked={vertAlign === 'superscript'}
              onChange={(e) => setVertAlign(e.target.checked ? 'superscript' : '')}
            />
            {t('appSuperscript')}
          </label>
          <label className="font-check">
            <input
              type="checkbox"
              checked={vertAlign === 'subscript'}
              onChange={(e) => setVertAlign(e.target.checked ? 'subscript' : '')}
            />
            {t('appSubscript')}
          </label>
        </div>
        <div
          className="font-preview"
          style={{
            fontFamily: font ? cssFontFamily(font) : undefined,
            fontSize: `${Math.min(size, 28)}pt`,
            fontWeight: style === 'bold' || style === 'boldItalic' ? 600 : 400,
            fontStyle: style === 'italic' || style === 'boldItalic' ? 'italic' : 'normal',
            color,
            textDecoration:
              [underline ? 'underline' : '', strike ? 'line-through' : ''].join(' ').trim() ||
              undefined,
          }}
        >
          {t('appFontPreviewSample')}
        </div>
        <div className="modal-actions">
          <button className="btn-ghost" onClick={onClose}>
            {t('appCancel')}
          </button>
          <button className="btn-primary" onClick={apply}>
            {t('appOk')}
          </button>
        </div>
      </div>
    </div>
  )
}

/* ================= Paragraph dialog ================= */

const PT_PER_TWIP = 1 / 20

type AlignValue = 'left' | 'center' | 'right' | 'justify'

/** visual alignment values; setSelectionAlign resolves them per paragraph direction */
const ALIGN_OPTIONS: Array<{ key: AlignValue; nameKey: StringKey }> = [
  { key: 'left', nameKey: 'appAlignLeft' },
  { key: 'center', nameKey: 'appAlignCenter' },
  { key: 'right', nameKey: 'appAlignRight' },
  { key: 'justify', nameKey: 'appAlignJustify' },
]

const LINE_SPACINGS: Array<{ value: number; nameKey: StringKey }> = [
  { value: 1, nameKey: 'appLineSingle' },
  { value: 1.15, nameKey: 'appLine115' },
  { value: 1.5, nameKey: 'appLine15' },
  { value: 2, nameKey: 'appLineDouble' },
  { value: 2.5, nameKey: 'appLine25' },
  { value: 3, nameKey: 'appLineTriple' },
]

export function ParagraphDialog({ editor, onClose }: { editor: Editor; onClose: () => void }) {
  const { t } = useI18n()
  const modalKeys = useModalKeys(onClose)
  const attrs = activeParaAttrs(editor)
  // unset align means "start": visually left in LTR, right in RTL (same as the ribbon)
  const [align, setAlign] = useState<AlignValue>(
    (attrs.align as AlignValue | null) ?? (attrs.bidi === true ? 'right' : 'left'),
  )
  // Line spacing rule: multiples are the preset select values; 'atLeast'/'exact'
  // take a pt value (w:spacing w:lineRule + w:line, already modeled by parse/save)
  const rawTwips = Number(attrs.lineRawTwips) || 0
  const initRule =
    attrs.lineRule === 'exact' || attrs.lineRule === 'atLeast' ? (attrs.lineRule as string) : ''
  const initMultiple =
    Number(attrs.lineSpacing) || (attrs.lineRule === 'auto' && rawTwips ? rawTwips / 240 : 1)
  const [lineRule, setLineRule] = useState<string>(initRule)
  const [lineSpacing, setLineSpacing] = useState<number>(Math.round(initMultiple * 100) / 100)
  const [linePt, setLinePt] = useState<number>(rawTwips ? Math.round(rawTwips / 2) / 10 : 12)
  const twipsToPt = (v: unknown) => Math.round((Number(v) || 0) * PT_PER_TWIP)
  const [indentLeft, setIndentLeft] = useState(twipsToPt(attrs.indentLeft))
  const [indentRight, setIndentRight] = useState(twipsToPt(attrs.indentRight))
  const [indentFirstLine, setIndentFirstLine] = useState(twipsToPt(attrs.indentFirstLine))
  const [spaceBefore, setSpaceBefore] = useState(twipsToPt(attrs.spaceBefore))
  const [spaceAfter, setSpaceAfter] = useState(twipsToPt(attrs.spaceAfter))

  const apply = () => {
    if (!editor.isEditable) {
      onClose()
      return
    }
    const ptToTwips = (pt: number) => (pt > 0 ? Math.round(pt / PT_PER_TWIP) : null)
    const spacing =
      lineRule === 'exact' || lineRule === 'atLeast'
        ? { lineSpacing: null, lineRule, lineRawTwips: Math.max(20, Math.round(linePt * 20)) }
        : {
            lineSpacing: lineSpacing === 1 ? null : lineSpacing,
            lineRule: null,
            lineRawTwips: null,
          }
    // align goes through setSelectionAlign so each paragraph resolves the
    // visual value against its own direction (null = start side)
    setSelectionAlign(editor, align)
    setParaAttrs(editor, {
      ...spacing,
      indentLeft: ptToTwips(indentLeft),
      indentRight: ptToTwips(indentRight),
      indentFirstLine: ptToTwips(indentFirstLine),
      spaceBefore: ptToTwips(spaceBefore),
      spaceAfter: ptToTwips(spaceAfter),
    })
    onClose()
  }

  const numInput = (label: string, value: number, set: (v: number) => void) => (
    <label>
      {label}
      <span className="para-num">
        <input
          type="number"
          min={0}
          max={400}
          value={value}
          onChange={(e) => set(Math.max(0, Number(e.target.value) || 0))}
        />
        <span className="para-unit">pt</span>
      </span>
    </label>
  )

  return (
    <div
      className="modal-backdrop"
      ref={modalKeys.ref}
      onKeyDown={modalKeys.onKeyDown}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="modal">
        <h2>{t('appParagraph')}</h2>
        <div className="font-dialog-row">
          <label>
            {t('appAlignment')}
            <Dropdown
              value={align}
              ariaLabel={t('appAlignment')}
              options={ALIGN_OPTIONS.map((o) => ({ value: o.key, label: t(o.nameKey) }))}
              onPick={setAlign}
            />
          </label>
          <label>
            {t('appLineSpacingLabel')}
            <Dropdown
              value={lineRule || String(lineSpacing)}
              ariaLabel={t('appLineSpacingLabel')}
              options={[
                ...(!lineRule && !LINE_SPACINGS.some((s) => s.value === lineSpacing)
                  ? [
                      {
                        value: String(lineSpacing),
                        label: t('appLineMultiple', { n: lineSpacing }),
                      },
                    ]
                  : []),
                ...LINE_SPACINGS.map((s) => ({ value: String(s.value), label: t(s.nameKey) })),
                { value: 'atLeast', label: t('appLineAtLeast') },
                { value: 'exact', label: t('appLineExactly') },
              ]}
              onPick={(v) => {
                if (v === 'exact' || v === 'atLeast') {
                  setLineRule(v)
                } else {
                  setLineRule('')
                  setLineSpacing(Number(v))
                }
              }}
            />
          </label>
          {lineRule === 'exact' || lineRule === 'atLeast' ? (
            <label>
              {t('appLineValue')}
              <span className="para-num">
                <input
                  type="number"
                  min={1}
                  max={1584}
                  step={0.5}
                  value={linePt}
                  onChange={(e) => setLinePt(Math.max(0, Number(e.target.value) || 0))}
                />
                <span className="para-unit">pt</span>
              </span>
            </label>
          ) : (
            <label>
              {t('appLineValue')}
              <span className="para-num">
                <input
                  type="number"
                  min={0.06}
                  max={132}
                  step={0.05}
                  value={lineSpacing}
                  onChange={(e) => setLineSpacing(Math.max(0.06, Number(e.target.value) || 1))}
                />
                <span className="para-unit">×</span>
              </span>
            </label>
          )}
        </div>
        <div className="font-dialog-row">
          {numInput(t('appIndentLeft'), indentLeft, setIndentLeft)}
          {numInput(t('appIndentRight'), indentRight, setIndentRight)}
          {numInput(t('appIndentFirstLine'), indentFirstLine, setIndentFirstLine)}
        </div>
        <div className="font-dialog-row">
          {numInput(t('appSpaceBefore'), spaceBefore, setSpaceBefore)}
          {numInput(t('appSpaceAfter'), spaceAfter, setSpaceAfter)}
        </div>
        <div className="modal-actions">
          <button className="btn-ghost" onClick={onClose}>
            {t('appCancel')}
          </button>
          <button className="btn-primary" onClick={apply}>
            {t('appOk')}
          </button>
        </div>
      </div>
    </div>
  )
}

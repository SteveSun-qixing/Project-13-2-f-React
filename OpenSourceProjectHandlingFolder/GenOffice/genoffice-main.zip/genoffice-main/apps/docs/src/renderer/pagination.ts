/**
 * Pagination slicing: greedy page breaking over the continuous-flow render result, by top-level block.
 * Pure functions; all coordinates are content-area Y at 100% zoom (px, 0 = top of page 1 content).
 */
import type { HeaderFooter, HfPartInfo, SectionInfo, SectionSettings } from '@genoffice/docx-engine'

export interface BlockBox {
  top: number
  height: number
  /** paragraph pageBreakBefore: force a page break before the block */
  breakBefore?: boolean
  /** breakBefore comes from a leading w:br (real break character, not the
   *  pageBreakBefore property): honored even on the document's blank first page */
  breakBeforeBr?: boolean
  /** block contains a page-break field (w:br type=page): force a page break after it */
  breakAfter?: boolean
  /** zero-height break carrier (floating-textbox anchor): the break survives a blank page */
  breakForce?: boolean
  /** block contains a column break (w:br type=column): force a column change after it (new page on last column) */
  colBreakAfter?: boolean
  /** source DOM block (filled during canvas measurement, used to position page-gap decorations) */
  el?: HTMLElement
  /** the block's docxIndex (DOM data-idx; new unsaved blocks lack one) */
  docxIndex?: number
  /** owning section index (filled by assignSections) */
  section?: number
  /** CSS-floated block (square/tight/through image wrap, w:tblpPr table): the
   *  wrapped text beside it carries the vertical extent, so it consumes no
   *  column height itself (block boxes in normal flow stack ignoring floats) */
  floated?: boolean
  /** in-block line boundaries (relative to block top, ascending, each = a line's starting Y): used to split page-crossing blocks by line */
  lineOffsets?: number[]
  /** min lines kept on each side of a split (widow/orphan control): paragraphs 2, table rows 1 (default) */
  splitMinLines?: number
  /** no visible text/image (empty paragraph mark): flows but doesn't count toward column-balance quotas */
  emptyPara?: boolean
  /** non-reflowable block's rendered width (tables, protected textboxes/objects):
   *  such a block never advances into a narrower column (Word turns the page instead) */
  fixedWidthPx?: number

  // ── F2 line-level page-split extensions ─────────────────────────────────
  /**
   * Paragraph line-box list (from computeLineMetrics, for line-level page splitting).
   * When absent, degrades to F1 block-level greedy placement.
   */
  lineBoxes?: Array<{ offsetInBlock: number; height: number }>
  /** space before (px), from line-metrics output */
  spaceBeforePx?: number
  /** space after (px), from line-metrics output */
  spaceAfterPx?: number
  /** footnote reservation folded into spaceAfterPx by applyBlockMeta (not a
   *  paragraph space: page-bottom exemptions must not hand it back) */
  footnoteExtraPx?: number
  /** break-only paragraph (page-break field, no other content): single line's height, drives absorb-vs-blank-page placement */
  breakOnlyLineH?: number

  // ── F2 pagination constraints ───────────────────────────────────────────
  /** keepLines: all lines of the paragraph must be on the same page */
  keepLines?: boolean
  /** keepNext: the paragraph and the next paragraph's first line must be on the same page */
  keepNext?: boolean
  /** widowControl: false = widow/orphan protection off (Word default on) */
  widowControl?: boolean

  // ── F2 table row-level page-split extensions ─────────────────────────────
  /**
   * Table row data (from parseDocx).
   * When present, table rows become the page-split unit (instead of hard pixel cuts).
   */
  tableRows?: TableRowBox[]

  /** virtual endnotes-area block (appended by appendEndnotesBlock; no DOM/docxIndex) */
  isEndnotes?: boolean

  /** virtual trailing block reserving pages for overflowing floating boxes (appendFloatSpillBlock) */
  isFloatSpill?: boolean

  /** table block under Word 2013+ layout rules (see BlockMeta.modernTableHeaders) */
  modernTableHeaders?: boolean
}

/**
 * Table row box (for F2 table row-level page splitting).
 */
export interface TableRowBox {
  /** row height (px) */
  height: number
  /** cantSplit: the row cannot be broken internally (whole row stays on one page) */
  cantSplit?: boolean
  /** tblHeader: the row is a header row, repeated at the top of the next page after a break */
  isHeader?: boolean
  /** vertical merge (vMerge continue): the row continues a merged row; its height is not counted independently */
  vMergeContinue?: boolean
  /** in-row safe cut points (relative to row top, px, ascending): spanning all cells without splitting any text line/image.
   *  Word allows in-row page breaks by default; without cut points or with cantSplit the row is atomic */
  cutYs?: number[]
  /** bottom of the lowest content band (text/image rects) relative to row top (px, 0 = empty row):
   *  lets pagination clip declared-height fill below the content instead of pushing pages */
  contentBottom?: number
  /** declared atLeast trHeight (px): reserved space Word never breaks inside —
   *  when it overflows the page remainder the whole row pushes to the next page */
  minHPx?: number
}

/** One column of a multi-column page: a content range in the continuous flow (in-column break semantics match pages) */
export interface PageColumn {
  start: number
  end: number
  /** table continued into the column: header-row range repeated at column top (virtual coordinates) */
  repeatHeader?: { top: number; height: number }
}

/** A column-flow region within a page (a continuous column-count change can stack multiple regions vertically on one page) */
export interface PageRegion {
  /** region top relative to the page content-area top (px) */
  top: number
  /** available height per column within the region (px) */
  height: number
  /** owning section index of the region (for column count/width) */
  section: number
  /** content ranges per column (ascending; single-column regions have length 1) */
  columns: PageColumn[]
}

/** Content range [start, end) shown on one page; height ≤ the owning section's page content height */
export interface PageSlice {
  start: number
  end: number
  /** owning section index of this page */
  section: number
  /**
   * tblHeader repetition: this page starts mid-table, so the source table's header
   * rows must render first. top/height is the header rows' range in the continuous
   * flow (virtual coordinates); the preview clones and crops accordingly.
   */
  repeatHeader?: { top: number; height: number }
  /**
   * Column flow: provided when this page has cols>1 regions (omitted for single-column
   * pages; consumers use the original path). start/end is still the whole-page flow
   * range (= first column start .. last column end); the span can reach columns × column height.
   */
  regions?: PageRegion[]
  /**
   * Physical content height actually used on a regioned page (last region top +
   * its tallest column). The virtual span (end - start) can exceed the page's
   * content height by stacking columns; canvas gap padding/compression uses this.
   */
  physHeight?: number
}

/**
 * Page owning a page-pinned float: the page its anchor lands on (anchorTop and
 * slices share gapless virtual coordinates); out-of-range anchors clamp.
 */
export function pinnedFloatPage(slices: PageSlice[], anchorTop: number): number {
  const idx = slices.findIndex((s) => anchorTop >= s.start && anchorTop < s.end)
  if (idx >= 0) return idx
  return anchorTop < (slices[0]?.start ?? 0) ? 0 : Math.max(0, slices.length - 1)
}

/** Pagination geometry for one section */
export interface SectionGeom {
  contentHeight: number
  /** content width (px, page width minus side margins); optional so height-only callers/tests can omit it */
  contentWidth?: number
  /** section start forces a page break (nextPage/evenPage/oddPage, or continuous with different page geometry) */
  forceBreak: boolean
  /** section break type: evenPage/oddPage need physical blank pages inserted to align parity */
  startType?: SectionInfo['startType']
  /** equal-width column count (w:cols w:num, default 1): page capacity = columns × column height */
  cols?: number
  /** per-column widths (px, length cols) — differ under w:equalWidth="0" */
  colWidths?: number[]
  /** nextColumn start with the same column count as the previous section: advance one column at the boundary */
  colBreakStart?: boolean
}

export function computePageSlices(
  blocks: BlockBox[],
  contentHeight: number,
  totalHeight: number,
): PageSlice[] {
  return computeSectionedSlices(blocks, [{ contentHeight, forceBreak: false }], totalHeight)
}

/**
 * Line-level cut point for a page-crossing block: the last line boundary before the
 * page limit that satisfies widow/orphan constraints. Constraints: when the block
 * starts on this page, keep ≥ splitMinLines lines at the head; keep ≥ splitMinLines
 * lines in the tail after the cut. Returns null when there are no line boundaries or
 * the constraints fail (caller pushes the whole block / falls back to pixel cut).
 */
function lineCut(block: BlockBox, pageStart: number, limit: number): number | null {
  const offs = block.lineOffsets
  if (!offs || offs.length === 0) return null
  const minLines = block.splitMinLines ?? 1
  const headMinIdx = block.top >= pageStart ? minLines - 1 : 0
  const tailMaxIdx = offs.length - minLines
  let cut: number | null = null
  for (let k = headMinIdx; k <= tailMaxIdx; k++) {
    const y = block.top + offs[k]
    if (y > limit) break
    if (y > pageStart) cut = y
  }
  return cut
}

export function computeSectionedSlices(
  blocks: BlockBox[],
  geoms: SectionGeom[],
  totalHeight: number,
): PageSlice[] {
  const total = Math.max(totalHeight, 0)
  // see computeSectionedSlicesF2: block-less sections (lone sectPr chips)
  // still claim their own pages ahead of true page starts
  const sectionHasBlocks = new Set<number>()
  for (const b of blocks) sectionHasBlocks.add(b.section ?? 0)
  const firstSection = blocks[0]?.section ?? 0
  if (geoms.length === 0 || geoms.every((g) => g.contentHeight <= 0)) {
    return [{ start: 0, end: total, section: firstSection }]
  }
  const geomOf = (s: number) => geoms[Math.max(0, Math.min(s, geoms.length - 1))]
  const emptySectionClaimsPage = (s: number) => {
    // only true page starts keep a blank page for an empty preceding section;
    // a promoted nextColumn (single-column, n#750255) or a continuous size
    // change absorbs it (Word skips the blank first page there)
    const st = geomOf(s).startType
    return (
      (st === undefined || st === 'nextPage' || st === 'evenPage' || st === 'oddPage') &&
      !sectionHasBlocks.has(s - 1)
    )
  }
  const initSection = firstSection > 0 && emptySectionClaimsPage(1) ? 0 : firstSection

  const starts: Array<{ y: number; section: number }> = [{ y: 0, section: initSection }]
  let pageStart = 0
  let curSection = initSection
  let contentH = Math.max(geomOf(curSection).contentHeight, 1)
  let pendingBreak = false
  const newPage = (y: number, section: number) => {
    pageStart = y
    starts.push({ y, section })
  }
  for (const block of blocks) {
    const bSection = block.section ?? curSection
    if (bSection !== curSection) {
      for (let s = curSection + 1; s <= bSection; s++) {
        const gs = geomOf(s)
        if (gs.forceBreak && (block.top > pageStart || emptySectionClaimsPage(s))) {
          newPage(block.top, s)
        }
      }
      curSection = bSection
      contentH = Math.max(geomOf(curSection).contentHeight, 1)
    }
    if ((pendingBreak || block.breakBefore) && block.top > pageStart) {
      newPage(block.top, curSection)
    }
    pendingBreak = false
    const bottom = block.top + block.height
    // page-crossing block: with line boundaries, cut in place (with widow/orphan
    // constraints); if not cuttable, push the whole block (or the cuttable block's
    // start) to the next page; blocks with no line boundaries taller than a page fall back to hard pixel cuts
    while (bottom > pageStart + contentH) {
      const cut = lineCut(block, pageStart, pageStart + contentH)
      if (cut !== null) {
        newPage(cut, curSection)
      } else if (block.top > pageStart && (block.height <= contentH || block.lineOffsets?.length)) {
        newPage(block.top, curSection)
      } else {
        newPage(pageStart + contentH, curSection)
      }
    }
    if (block.breakAfter) pendingBreak = true
  }
  if (pendingBreak) newPage(Math.max(total, pageStart), curSection)

  const end = Math.max(total, pageStart)
  return starts.map((s, i) => ({
    start: s.y,
    end: i + 1 < starts.length ? starts[i + 1].y : end,
    section: s.section,
  }))
}

const twipsToPx = (twips: number) => (twips / 1440) * 96

/** Physical section page box shared by editor and pagination preview. */
export function sectionPageBox(set: SectionSettings): {
  width: number
  height: number
  contentWidth: number
  headerDist: number
  footerDist: number
} {
  return {
    width: twipsToPx(set.pageWidth),
    height: twipsToPx(set.pageHeight),
    contentWidth: twipsToPx(set.pageWidth - set.marginLeft - set.marginRight),
    headerDist: twipsToPx(set.headerDist ?? 720),
    footerDist: twipsToPx(set.footerDist ?? 720),
  }
}

// ── F2 line-level page splitting + Word pagination constraints ───────────────

/**
 * F2: line-level page splitting + Word pagination constraint solving (incl. column flow).
 *
 * Coordinates:
 *   - block.top: absolute Y in the content flow (px)
 *   - pageStart: starting Y of the current page in the content flow
 *   - usedInCol: height already placed in the current column (single-column doc = height used on the page)
 *   - fits(h): usedInCol + h <= colH + 0.01
 *
 * Columns (SectionGeom.cols>1): three levels, page → region → column. Each column
 * is a "mini page" (column height = content height − region top); overflow moves to
 * the next column, the last column turns the page; forced page breaks turn the page directly.
 * A continuous section changing column count opens a new region on the same page
 * (section capacity = columns × remaining height).
 *
 * Constraint priority: pageBreakBefore > keepNext chain > keepLines > widowControl
 */
export function computeSectionedSlicesF2(
  blocks: BlockBox[],
  geoms: SectionGeom[],
  totalHeight: number,
): PageSlice[] {
  const total = Math.max(totalHeight, 0)
  // sections whose every block collapsed to a zero-height chip (lone sectPr
  // paragraphs) never appear in the measured blocks; they still claim their
  // own (blank) pages ahead of true page starts
  const sectionHasBlocks = new Set<number>()
  for (const b of blocks) sectionHasBlocks.add(b.section ?? 0)
  const firstSection = blocks[0]?.section ?? 0
  if (geoms.length === 0 || geoms.every((g) => g.contentHeight <= 0)) {
    return [{ start: 0, end: total, section: firstSection }]
  }
  const geomOf = (s: number) => geoms[Math.max(0, Math.min(s, geoms.length - 1))]
  const colsOf = (s: number) => Math.max(1, geomOf(s).cols ?? 1)
  const emptySectionClaimsPage = (s: number) => {
    // only true page starts keep a blank page for an empty preceding section;
    // a promoted nextColumn (single-column, n#750255) or a continuous size
    // change absorbs it (Word skips the blank first page there)
    const st = geomOf(s).startType
    return (
      (st === undefined || st === 'nextPage' || st === 'evenPage' || st === 'oddPage') &&
      !sectionHasBlocks.has(s - 1)
    )
  }
  const initSection = firstSection > 0 && emptySectionClaimsPage(1) ? 0 : firstSection

  type ColEntry = { y: number; repeatHeader?: { top: number; height: number } }
  type Region = { top: number; height: number; section: number; cols: number; entries: ColEntry[] }
  const pages: Array<{ section: number; regions: Region[] }> = []

  let pageStart = 0 // starting Y of the current page (absolute)
  let curSection = initSection
  let contentH = Math.max(geomOf(curSection).contentHeight, 1)
  let regionTop = 0 // current region top (relative to page content-area top)
  let colCount = 1 // column count of the current region
  let colH = contentH // column height of the current region
  let colIdx = 0 // current column index
  let usedInCol = 0 // height used in the current column
  let pendingBreak = false
  let pendingForce = false
  let pendingColBreak = false

  // Safety net: a document legitimately needs at most a few column turns per
  // block (forced breaks, line/row splits) — far beyond that means a placement
  // loop stopped converging. Degrade by treating everything as fitting (the
  // rest piles onto the current page, with a warning) instead of looping forever.
  const maxColumnTurns = Math.max(65536, blocks.length * 8)
  let columnTurns = 0
  let runaway = false

  // first block index of the current region (balancing walks this range for line boundaries)
  let regionStartBi = 0
  // an explicit column break inside the region disqualifies it from balancing
  // ("any effective page breaks stop the balancing act"); natural overflow turns
  // are re-distributed by the balance pass
  let regionBroke = false
  // main-loop block index, visible to the region closures for regionStartBi bookkeeping
  let curBi = 0

  const pushColumn = (y: number, headerH = 0, headerTop = 0) => {
    if (++columnTurns > maxColumnTurns && !runaway) {
      runaway = true
      console.warn(
        `[pagination] column-turn limit ${maxColumnTurns} exceeded at y=${y}; placing remaining content without page breaks`,
      )
    }
    const page = pages[pages.length - 1]
    page.regions[page.regions.length - 1].entries.push({
      y,
      ...(headerH > 0 ? { repeatHeader: { top: headerTop, height: headerH } } : {}),
    })
    usedInCol = headerH
  }
  // open a new region at the current page's regionTop (column count/height per section)
  const openRegion = (y: number, section: number, headerH = 0, headerTop = 0) => {
    colCount = colsOf(section)
    colH = Math.max(contentH - regionTop, 1)
    colIdx = 0
    regionStartBi = curBi
    regionBroke = false
    pages[pages.length - 1].regions.push({
      top: regionTop,
      height: colH,
      section,
      cols: colCount,
      entries: [],
    })
    pushColumn(y, headerH, headerTop)
  }
  const startPage = (y: number, section: number, headerH = 0, headerTop = 0) => {
    pageStart = y
    regionTop = 0
    pages.push({ section, regions: [] })
    openRegion(y, section, headerH, headerTop)
  }
  // advance on overflow: change column if not the last, turn the page on the last (headerH/headerTop: table header repeated at column top after a table break)
  const newColumn = (y: number, section: number, headerH = 0, headerTop = 0) => {
    if (colIdx + 1 < colCount) {
      colIdx += 1
      pushColumn(y, headerH, headerTop)
    } else {
      startPage(y, section, headerH, headerTop)
    }
  }

  /**
   * Word column balancing: a multi-column region closed mid-page by a continuous
   * column-count change redistributes its single-column content across the columns.
   * Word fills line quotas left to right — target = ceil(visible lines / cols) per
   * column, empty paragraph marks flow but don't count, and widow/orphan atomicity
   * keeps short paragraphs whole (trailing columns may stay empty). Explicit column
   * breaks disable it ("any effective page breaks stop the balancing act"), as do
   * tables (row structure, v1). Mutates the current region's entries/height;
   * returns the balanced region height, or null when not applicable.
   */
  const tryBalanceRegion = (endBi: number, endY: number): number | null => {
    const page = pages[pages.length - 1]
    const region = page.regions[page.regions.length - 1]
    if (region.cols <= 1 || regionBroke || runaway) return null
    const startY = region.entries[0]?.y
    if (startY === undefined || region.entries[0].repeatHeader) return null
    // boundary units: block tops always cuttable; in-block line starts cuttable
    // per widow/orphan atomicity. Each unit carries the counted content height of
    // its piece (0 for empty paragraph marks — they flow but don't add quota)
    type Unit = { y: number; h: number; cut: boolean }
    const units: Unit[] = []
    // trailing whitespace before the closing block (space-after / inter-section
    // spacing) must not inflate the last column's extent
    let contentEnd = startY
    for (let i = regionStartBi; i < endBi; i++) {
      const b = blocks[i]
      if (b.tableRows) return null
      if (b.floated) continue
      if (b.top + b.height < startY + 0.01 || b.top > endY - 0.01) continue
      const bottom = Math.min(b.top + b.height, endY)
      // trailing empty paragraph marks are absorbed (they don't extend the region)
      if (!b.emptyPara) contentEnd = Math.max(contentEnd, bottom)
      const minKeep = b.widowControl !== false ? 2 : 1
      const lbs = b.lineBoxes && b.lineBoxes.length > 0 ? b.lineBoxes : null
      const n = lbs ? lbs.length : 1
      for (let k = 0; k < n; k++) {
        // a block split across the page boundary contributes only its lines within
        // the region (clip to startY); its clipped head is not a cut point
        const rawY = lbs ? b.top + lbs[k].offsetInBlock : b.top
        if (rawY > endY - 0.01) break
        const next = lbs && k + 1 < n ? Math.min(b.top + lbs[k + 1].offsetInBlock, bottom) : bottom
        if (next < startY + 0.01) continue
        const y = Math.max(rawY, startY)
        units.push({
          y,
          h: b.emptyPara ? 0 : Math.max(next - y, 0),
          cut: rawY >= startY - 0.01 && (k === 0 || (k >= minKeep && n - k >= minKeep)),
        })
      }
    }
    const countedH = units.reduce((s, u) => s + u.h, 0)
    if (countedH <= 0.01 || contentEnd - startY <= 0.01) return null
    const target = countedH / region.cols
    const cuts: number[] = []
    let acc = 0
    let prevCut = startY
    for (const u of units) {
      if (cuts.length >= region.cols - 1) break
      if (acc >= target - 0.01 && u.cut && u.y > prevCut + 0.01) {
        cuts.push(u.y)
        prevCut = u.y
        acc = 0
      }
      acc += u.h
    }
    while (cuts.length < region.cols - 1) cuts.push(endY) // trailing empty columns
    region.entries = [region.entries[0], ...cuts.map((y) => ({ y }))]
    // column extents measured to the content end (trailing whitespace excluded)
    const cutEdges = [startY, ...cuts, endY].map((y) => Math.min(y, contentEnd))
    let maxExtent = 0
    for (let k = 1; k < cutEdges.length; k++)
      maxExtent = Math.max(maxExtent, cutEdges[k] - cutEdges[k - 1])
    region.height = maxExtent
    return maxExtent
  }

  // whether height h fits in the current column (runaway degrade: everything fits)
  const fits = (h: number): boolean => runaway || usedInCol + h <= colH + 0.01
  // whether the current column is empty (just changed columns or at column top)
  const colEmpty = () => usedInCol <= 0.01
  // whether the current page is entirely blank (guards forced breaks against empty pages)
  const pageBlank = () => colIdx === 0 && regionTop <= 0.01 && usedInCol <= 0.01
  // place height h (unconditional accumulation)
  let anyContent = false
  const place = (h: number) => {
    usedInCol += h
    anyContent = true
  }

  startPage(0, initSection)

  // precompute keepNext chains (runs of consecutive keepNext blocks; the last block closes the chain)
  // chainStart[i] = chain start index (-1 when not in a chain)
  const chainStart = new Int32Array(blocks.length).fill(-1)
  for (let i = 0; i < blocks.length; i++) {
    if (blocks[i].keepNext) {
      let j = i
      while (j < blocks.length - 1 && blocks[j].keepNext) j++
      for (let k = i; k <= j; k++) chainStart[k] = i
      i = j
    }
  }

  // ── Main loop ───────────────────────────────────────────────────────────────
  for (let bi = 0; bi < blocks.length; bi++) {
    const block = blocks[bi]
    curBi = bi

    // section change
    const bSection = block.section ?? curSection
    if (bSection !== curSection) {
      // sections crossed without any measured block (a lone sectPr paragraph
      // renders as a zero-height chip) still claim their own page in Word:
      // break once per crossed next-page boundary
      for (let s = curSection + 1; s < bSection; s++) {
        const gs = geomOf(s)
        if (gs.forceBreak && (block.top > pageStart || emptySectionClaimsPage(s))) {
          contentH = Math.max(gs.contentHeight, 1)
          startPage(block.top, s)
        }
      }
      const g = geomOf(bSection)
      const newCols = colsOf(bSection)
      curSection = bSection
      contentH = Math.max(g.contentHeight, 1)
      if (g.forceBreak && (block.top > pageStart || emptySectionClaimsPage(bSection))) {
        startPage(block.top, bSection)
      } else if (newCols !== colCount) {
        // continuous section changing column count: balance the closed multi-column
        // region (Word), then open a new region in the remaining page height; if the
        // page is used up, turn the page. An unbalanced region ends at its
        // tallest column's content, NOT the full column height: a short
        // letterhead row split by an explicit column break must not eat the
        // page (prod100r3/45 lost its whole first page to a 2-line region) —
        // natural overflow still yields a full first-column segment.
        const balancedH = tryBalanceRegion(bi, block.top)
        const entries = pages[pages.length - 1].regions.at(-1)?.entries ?? []
        const segMax = entries.length
          ? Math.max(
              ...entries.map(
                (e, i) => (i + 1 < entries.length ? entries[i + 1].y : block.top) - e.y,
              ),
            )
          : usedInCol
        const regionBottom = regionTop + (balancedH ?? Math.min(Math.max(segMax, 0), colH))
        if (regionBottom >= contentH - 1) {
          startPage(block.top, bSection)
        } else {
          regionTop = regionBottom
          openRegion(block.top, bSection)
        }
      } else {
        // column count unchanged (continuous flow continues on the same page): update column height per the new section's content height
        colH = Math.max(contentH - regionTop, 1)
        const page = pages[pages.length - 1]
        page.regions[page.regions.length - 1].height = colH
        // nextColumn into a same-count section: advance one column at the boundary (no-op at a column top)
        if (g.colBreakStart && !colEmpty()) {
          regionBroke = true
          newColumn(block.top, bSection)
        }
      }
    }

    // pageBreakBefore (highest priority: force a new page before this block; mid-column breaks also turn the page directly)
    // a pending w:br plus this block's own leading w:br are two distinct break
    // characters: both turn the page, leaving a deliberate blank sheet between
    const doubleBreak = pendingBreak && block.breakBeforeBr && !pageBlank()
    if (doubleBreak) startPage(block.top, curSection)
    // a leading w:br on the document's first content still breaks (Word keeps the
    // blank first page); breaks landing on a later blank page stay suppressed
    if (
      (pendingBreak || block.breakBefore) &&
      (doubleBreak ||
        pendingForce ||
        !pageBlank() ||
        (block.breakBeforeBr && !anyContent && pages.length === 1))
    ) {
      startPage(block.top, curSection)
    }
    pendingBreak = false
    pendingForce = false
    // column break: change column (turn the page on the last column); no-op at column top
    if (pendingColBreak && !colEmpty()) {
      regionBroke = true
      newColumn(block.top, curSection)
    }
    pendingColBreak = false

    // overflow advancement for this block: a non-reflowable block (table/textbox)
    // never advances into a column narrower than itself — Word turns the page
    // instead (explicit column breaks above are honored regardless)
    const advance =
      block.fixedWidthPx === undefined
        ? newColumn
        : (y: number, section: number, headerH = 0, headerTop = 0) => {
            const ws = geomOf(section).colWidths
            if (
              colIdx + 1 < colCount &&
              ws &&
              (ws[colIdx + 1] ?? Infinity) < block.fixedWidthPx! - 0.5
            ) {
              startPage(y, section, headerH, headerTop)
            } else {
              newColumn(y, section, headerH, headerTop)
            }
          }

    // CSS-floated block (wrapped image / w:tblpPr table): following block boxes
    // stack ignoring it (only their line boxes shorten), so it consumes no column
    // height — counting it would double-book the overlap and break pages early
    if (block.floated) {
      if (!fits(block.height) && !colEmpty()) advance(block.top, curSection)
      place(0)
      if (block.breakAfter) {
        pendingBreak = true
        if (block.breakForce) pendingForce = true
      }
      if (block.colBreakAfter) pendingColBreak = true
      continue
    }

    // break-only paragraph: absorbed at the page bottom (overflowing the bottom margin)
    // unless less than half its line height remains — then it opens a Word-style
    // deliberate blank page. The half-line tolerance far exceeds the ±few-px page-fill
    // drift that a plain fit-check turned into spurious mid-document blanks. Word drops
    // a trailing space-after at the page bottom, so the previous block's folded-in
    // trailing space is handed back before judging the fit.
    if (block.breakOnlyLineH !== undefined) {
      // paragraph space only: footnote reservations keep consuming capacity
      const prevTrailing =
        bi > 0 && !blocks[bi - 1].floated
          ? Math.max(0, (blocks[bi - 1].spaceAfterPx ?? 0) - (blocks[bi - 1].footnoteExtraPx ?? 0))
          : 0
      if (!fits(block.breakOnlyLineH * 0.5 - prevTrailing) && !pageBlank())
        startPage(block.top, curSection)
      place(block.height)
      if (block.breakAfter) {
        pendingBreak = true
        if (block.breakForce) pendingForce = true
      }
      if (block.colBreakAfter) pendingColBreak = true
      continue
    }

    // ── Tables: row-level page breaking ────────────────────────────────────
    if (block.tableRows && block.tableRows.length > 0) {
      _placeTable(
        block,
        block.tableRows,
        colH,
        fits,
        place,
        () => Math.max(colH - usedInCol, 0),
        colEmpty,
        advance,
        curSection,
      )
      if (block.spaceAfterPx) place(block.spaceAfterPx) // space after the table (may overflow into the bottom margin)
      if (block.breakAfter) {
        pendingBreak = true
        if (block.breakForce) pendingForce = true
      }
      if (block.colBreakAfter) pendingColBreak = true
      continue
    }

    // ── Paragraph line-level placement ────────────────────────────────────
    const lineBoxes = block.lineBoxes
    const hasLines = lineBoxes && lineBoxes.length > 0
    const widowOn = block.widowControl !== false
    const spaceBeforePx = block.spaceBeforePx ?? 0
    const spaceAfterPx = block.spaceAfterPx ?? 0

    // keepNext chain (a keepNext on the document's last block has no anchor — plain placement)
    // checked before keepLines: Word heading styles carry both, and the chain decides the page push
    if (block.keepNext && chainStart[bi] === bi && bi < blocks.length - 1) {
      // chain tail: the last keepNext=true block (excluding the anchor block)
      const chainEnd = (() => {
        let j = bi
        while (j < blocks.length - 1 && blocks[j].keepNext) j++
        // j is now the first non-keepNext block (the anchor)
        // the chain tail is j-1 (the last keepNext block), while j is the anchor (next paragraph)
        // note: the while loop stops at j < length-1, so if the chain tail is at document end, j = length-1
        return j
      })()
      // chainEnd now points at the first non-keepNext block (the anchor), e.g. block[56]
      // the actual keepNext chain is bi..chainEnd-1; the anchor is chainEnd
      const lastKeepNextIdx = chainEnd - 1 // last keepNext block
      const anchorBlock = blocks[chainEnd] // anchor block (first non-keepNext)

      // a pageBreakBefore inside the chain truncates it (highest priority)
      let effectiveChainEnd = lastKeepNextIdx
      for (let k = bi + 1; k <= lastKeepNextIdx; k++) {
        if (blocks[k].breakBefore) {
          effectiveChainEnd = k - 1
          break
        }
      }
      // check whether the anchor has breakBefore (if so, the anchor is handled independently)
      const anchorHasBreak = anchorBlock?.breakBefore ?? false

      // compute the chain height (keepNext blocks) + the anchor's demand
      let chainH = 0
      for (let k = bi; k <= effectiveChainEnd; k++) chainH += blocks[k].height

      // anchor demand: the chain keeps only with the anchor's first line (first 2
      // with widow control on — Word's orphan minimum); the anchor is not part of
      // the atomic unit and flows normally after the chain. Exceptions: keepLines
      // anchors follow whole; table anchors count their first row (Word keeps the
      // heading with the table head, not the whole table)
      let anchorNeedH = 0
      if (!anchorHasBreak && anchorBlock) {
        const aLines = anchorBlock.lineBoxes
        if (anchorBlock.keepLines) anchorNeedH = anchorBlock.height
        else if (anchorBlock.tableRows?.length) anchorNeedH = anchorBlock.tableRows[0].height
        else if (aLines?.length) {
          const need = anchorBlock.widowControl !== false ? Math.min(2, aLines.length) : 1
          anchorNeedH = anchorBlock.spaceBeforePx ?? 0
          for (let li = 0; li < need; li++) anchorNeedH += aLines[li].height
        } else {
          anchorNeedH = anchorBlock.height // no line data yet (first pass): conservative
        }
      }
      const chainPlusAnchorH = chainH + anchorNeedH

      if (chainH <= colH) {
        // whole chain (keepNext blocks) fits on a page: the chain + anchor demand
        // must share a page (keepNext semantics); if it doesn't fit, push the whole chain
        // to the next page (Word behavior; corpus 04 evidence: section 3.2 chain pushed).
        // Only abandon the constraint when chain + anchor demand can't fit even an
        // empty page (no solution; avoids infinite loops).
        if (!fits(chainPlusAnchorH) && !colEmpty() && chainPlusAnchorH <= colH) {
          advance(block.top, curSection)
        }
        // place chain head through chain tail (the keepNext blocks)
        for (let k = bi; k <= effectiveChainEnd; k++) place(blocks[k].height)
        bi = effectiveChainEnd
        if (blocks[effectiveChainEnd].breakAfter) {
          pendingBreak = true
          if (blocks[effectiveChainEnd].breakForce) pendingForce = true
        }
        if (blocks[effectiveChainEnd].colBreakAfter) pendingColBreak = true
        continue
      }

      // chain exceeds one page: only guarantee the chain head + anchor demand share a page (minimum guarantee)
      const headH = block.height + anchorNeedH
      if (!fits(headH) && !colEmpty()) {
        advance(block.top, curSection)
      }
      if (!block.keepLines) {
        // place the chain head block
        _placeParaBlock(
          block,
          hasLines ? lineBoxes! : null,
          widowOn,
          spaceBeforePx,
          spaceAfterPx,
          colH,
          fits,
          place,
          colEmpty,
          advance,
          curSection,
        )
        if (block.breakAfter) {
          pendingBreak = true
          if (block.breakForce) pendingForce = true
        }
        if (block.colBreakAfter) pendingColBreak = true
        continue
      }
      // keepLines head falls through to the keepLines branch (must not split)
    }

    // keepLines: the whole paragraph must stay on one page (one column in multi-column layout)
    if (block.keepLines) {
      if (!fits(block.height) && block.height <= colH && !colEmpty()) {
        advance(block.top, curSection)
      }
      if (!fits(block.height)) {
        // paragraph exceeds one page: hard line-level cut (best effort)
        if (hasLines) {
          _hardCutLines(
            block,
            lineBoxes!,
            spaceBeforePx,
            spaceAfterPx,
            fits,
            place,
            colEmpty,
            advance,
            curSection,
          )
        } else {
          // no line data: hard pixel cuts consuming the remainder column by
          // column. (Retesting the full block height after each turn never
          // fits a block taller than one column and used to loop forever.)
          let offset = 0
          while (block.height - offset > colH - usedInCol + 0.01 && !runaway) {
            offset += Math.max(colH - usedInCol, 1)
            advance(block.top + Math.min(offset, block.height), curSection)
          }
          place(block.height - offset)
        }
      } else {
        place(block.height)
      }
      if (block.breakAfter) {
        pendingBreak = true
        if (block.breakForce) pendingForce = true
      }
      if (block.colBreakAfter) pendingColBreak = true
      continue
    }

    // ordinary block (incl. mid/tail keepNext chain blocks; chain constraints were handled by the chain head)
    _placeParaBlock(
      block,
      hasLines ? lineBoxes! : null,
      widowOn,
      spaceBeforePx,
      spaceAfterPx,
      colH,
      fits,
      place,
      colEmpty,
      advance,
      curSection,
    )
    if (block.breakAfter) {
      pendingBreak = true
      if (block.breakForce) pendingForce = true
    }
    if (block.colBreakAfter) pendingColBreak = true
  }

  // a trailing page break keeps its deliberate blank last page (Word: the final
  // paragraph mark lands after the break; LO dropping it is tdf#99090); a trailing
  // column break advances the same way (new page when the last column is used)
  if (pendingBreak) startPage(Math.max(total, pageStart), curSection)
  else if (pendingColBreak && !colEmpty()) newColumn(Math.max(total, pageStart), curSection)

  // ── Output: flatten column starts into ranges, aggregate by page (pages with cols>1 regions get regions attached) ──
  const flat: ColEntry[] = []
  for (const p of pages) for (const r of p.regions) for (const e of r.entries) flat.push(e)
  const flowEnd = Math.max(total, pageStart)
  const endOf = new Map<ColEntry, number>()
  flat.forEach((e, i) => endOf.set(e, i + 1 < flat.length ? flat[i + 1].y : flowEnd))

  return pages.map((p) => {
    const entries = p.regions.flatMap((r) => r.entries)
    const first = entries[0]
    const multiCol = p.regions.length > 1 || p.regions.some((r) => r.cols > 1)
    const last = p.regions[p.regions.length - 1]
    const lastExtent = Math.min(
      last.height,
      Math.max(...last.entries.map((e) => endOf.get(e)! - e.y + (e.repeatHeader?.height ?? 0)), 0),
    )
    return {
      start: first.y,
      end: endOf.get(entries[entries.length - 1])!,
      section: p.section,
      ...(first.repeatHeader ? { repeatHeader: first.repeatHeader } : {}),
      ...(multiCol
        ? {
            regions: p.regions.map((r) => ({
              top: r.top,
              height: r.height,
              section: r.section,
              columns: r.entries.map((e) => ({
                start: e.y,
                end: endOf.get(e)!,
                ...(e.repeatHeader ? { repeatHeader: e.repeatHeader } : {}),
              })),
            })),
            physHeight: last.top + lastExtent,
          }
        : {}),
    }
  })
}

// ── Internal helpers ────────────────────────────────────────────────────────

/**
 * Place a table (row-level page breaking).
 */
function _placeTable(
  block: BlockBox,
  rows: TableRowBox[],
  contentH: number,
  fits: (h: number) => boolean,
  place: (h: number) => void,
  remain: () => number,
  pageEmpty: () => boolean,
  newPage: (y: number, section: number, headerH?: number, headerTop?: number) => void,
  curSection: number,
) {
  // find header rows (the first N consecutive isHeader rows); a header block
  // taller than a full page doesn't repeat (Word probe 2026-08-16: a block at
  // 94% of the page still repeats on every page, so the gate is the full
  // content height, not half of it)
  let headerHeight = 0
  let leadHeaderRows = 0
  for (const r of rows) {
    if (!r.isHeader) break
    headerHeight += r.height
    leadHeaderRows++
  }
  const headerBlockH = headerHeight
  // headerRows drives per-page repetition only; push-whole protection keeps
  // using leadHeaderRows — Word never splits a tblHeader row even when the
  // header block is too tall to repeat
  let headerRows = leadHeaderRows
  if (headerHeight > contentH) {
    headerHeight = 0
    headerRows = 0
  }

  // Word 2013+ layout (compatibilityMode >= 15): a multirow tblHeader block
  // that doesn't fit the remaining space starts the table on a fresh page —
  // even when the block exceeds a full page (probe 2026-08-16, tdf88496 F30/F31;
  // legacy mode instead splits the header block in place)
  if (block.modernTableHeaders && leadHeaderRows > 0 && !pageEmpty() && headerBlockH > remain()) {
    newPage(block.top, curSection)
  }

  let rowCursor = block.top
  let placedHeader = false

  for (let ri = 0; ri < rows.length; ri++) {
    const row = rows[ri]

    if (row.vMergeContinue) {
      rowCursor += row.height
      continue
    }

    // table broken onto a new page: repeat headers only if they already appeared on a prior page (reserve header space at page top)
    const repeatH = placedHeader && ri >= headerRows ? headerHeight : 0

    if (!fits(row.height)) {
      const contentEnd =
        row.contentBottom !== undefined ? Math.min(row.contentBottom, row.height) : row.height
      // in-row page break (Word default): without cantSplit and with safe cut points,
      // place segment by segment at the cut points. If the first segment doesn't fit,
      // turn the page first (equivalent to pushing the whole row)
      // Word probe (2026-08-13): a plain first row has no special rule — it splits
      // like any row. Only tblHeader/cantSplit rows push whole. Over-page header/
      // cantSplit rows Word overflow-clips instead; we split them (DOM clipping is
      // costly) — a deliberate deviation.
      // Declared atLeast height is reserved space, not breakable content: when
      // the declared minimum overflows the page remainder, Word starts the row
      // on a fresh page instead of splitting into the remainder (near-empty
      // TOC pages, prod100r3/50; Word probe 2026-08-23). Rows taller than a
      // full page still split afterwards — from the fresh page.
      let turnedForMinH = false
      if (row.minHPx !== undefined && row.minHPx > remain() + 0.01 && !pageEmpty()) {
        newPage(rowCursor, curSection, repeatH, block.top)
        turnedForMinH = true
      }
      const keepWhole = row.isHeader && ri < leadHeaderRows && row.height <= contentH + 0.01
      let cuts = !row.cantSplit && !keepWhole && row.cutYs ? [...row.cutYs] : []
      const placeSegments = (bounds: number[]) => {
        let prev = 0
        for (const cut of bounds) {
          const seg = cut - prev
          if (seg <= 0.5) continue
          if (!fits(seg) && !pageEmpty()) newPage(rowCursor + prev, curSection, repeatH, block.top)
          place(seg)
          prev = cut
        }
        return prev
      }
      // Only rows taller than a page get their declared-height fill clipped to the
      // page remainder (Word truncates over-tall rows within the page). Page-sized
      // rows keep the fill glued to the last segment: a clipped fill would desync
      // bookkeeping from DOM height, leaking shading/empty rows past the page edge.
      if (row.height > contentH + 0.01) {
        if (!row.cantSplit && contentEnd > contentH) {
          // A fixed-height row can be taller than a page while containing only one
          // text band, so DOM line sampling may provide too few natural cuts. Keep
          // every segment page-sized; natural inter-band cuts remain preferred and
          // a hard content-band cut is only inserted where no legal cut advances.
          const bounded: number[] = []
          let previous = 0
          for (const candidate of [...cuts, contentEnd]) {
            while (candidate - previous > contentH + 0.01) {
              previous += contentH
              bounded.push(previous)
            }
            if (candidate < row.height - 0.5 && candidate > previous + 0.5) {
              bounded.push(candidate)
              previous = candidate
            }
          }
          cuts = bounded
        }
        cuts = cuts.filter((c) => c < contentEnd - 0.01)
        if (cuts.length > 0 || contentEnd < row.height - 0.5) {
          const prev = placeSegments([...cuts, contentEnd])
          const fill = row.height - prev
          if (fill > 0.5) place(Math.min(fill, remain()))
          rowCursor += row.height
          if (row.isHeader && ri < headerRows) placedHeader = true
          continue
        }
      } else if (cuts.length > 0) {
        placeSegments([...cuts, row.height])
        rowCursor += row.height
        if (row.isHeader && ri < headerRows) placedHeader = true
        continue
      }
      // cantSplit / empty / no cut points: the row is atomic; turn the page
      // first if it doesn't fit. A repeated header keeps the fresh page
      // non-empty, so the minH turn above must not double up here.
      if (!pageEmpty() && !turnedForMinH) newPage(rowCursor, curSection, repeatH, block.top)
    }
    place(row.height)
    rowCursor += row.height
    if (row.isHeader && ri < headerRows) placedHeader = true
  }
}

/**
 * Place a paragraph block (with widowControl).
 * With lineBoxes = null, degrades to F1 block-level placement.
 */
function _placeParaBlock(
  block: BlockBox,
  lineBoxes: Array<{ offsetInBlock: number; height: number }> | null,
  widowOn: boolean,
  spaceBeforePx: number,
  spaceAfterPx: number,
  contentH: number,
  fits: (h: number) => boolean,
  place: (h: number) => void,
  pageEmpty: () => boolean,
  newPage: (y: number, section: number) => void,
  curSection: number,
) {
  const totalH = block.height

  // whole paragraph fits: place directly. Trailing space doesn't consume capacity (Word breaks by text only; it may overflow into the bottom margin)
  if (fits(totalH - spaceAfterPx)) {
    place(totalH)
    return
  }

  // whole paragraph doesn't fit
  if (!lineBoxes || lineBoxes.length === 0) {
    // F1 block-level placement: push to the next page if it doesn't fit (when <= one page), otherwise F1-style hard cut
    if (totalH <= contentH) {
      if (!pageEmpty()) newPage(block.top, curSection)
    } else {
      // big block over one page (no line data): F1 style — each time reset usedOnPage to "block extends past boundary"
      // equivalent to simulating a page break every contentH
      // usedOnPage is currently u, block height H > contentH
      // needs ceil((u + H) / contentH) - 1 page turns
      // but we have no pageStartY, so we can only simulate
      // simple approach: set usedOnPage to 0 (like a big block), then keep placing
      // in practice we only need to avoid infinite loops: when totalH > contentH, place directly and let the next block trigger the page turn
      // note: the F1 algorithm handles this the same way (falls through after determining it's a big block)
    }
    place(totalH)
    return
  }

  // line-level placement
  const nLines = lineBoxes.length

  if (totalH > contentH) {
    // paragraph exceeds one page: hard line-level cut
    _hardCutLines(
      block,
      lineBoxes,
      spaceBeforePx,
      spaceAfterPx,
      fits,
      place,
      pageEmpty,
      newPage,
      curSection,
    )
    return
  }

  // text part (spaceBefore + all lines) fits, only spaceAfter overflows: Word behavior —
  // the paragraph stays on this page and the trailing space overflows into the bottom
  // margin (Word paginates by text only; corpus 14 PDF measurement: end-of-page text
  // stops at 758.9pt < bottom bound 769.9, and the overflowing space-after doesn't push the paragraph)
  let textH = spaceBeforePx
  for (const lb of lineBoxes) textH += lb.height
  if (fits(textH)) {
    place(totalH)
    return
  }

  // paragraph <= one page but doesn't fit on the current page: widow/orphan decision
  // count how many lines fit on the current page
  let splitLine = -1 // line break point (-1 = push the whole paragraph)

  if (widowOn && nLines >= 2) {
    let sumH = spaceBeforePx
    for (let li = 0; li < nLines; li++) {
      sumH += lineBoxes[li].height
      if (!fits(sumH)) {
        splitLine = li // line li doesn't fit
        break
      }
    }
    if (splitLine === -1) {
      // theoretically unreachable (the textH check covers this); conservative fallback
      place(totalH)
      return
    }

    // widow/orphan adjustment: at least 2 lines at page bottom, at least 2 at page top
    // tailLines = lines on the current page, headLines = lines on the next page
    const tailLines = splitLine // splitLine lines stay on the current page (0..splitLine-1)
    // headLines = nLines - splitLine

    if (tailLines === 0) {
      // not even one line fits: push the whole paragraph
      splitLine = -1
    } else if (tailLines === 1) {
      // orphan at page bottom: drop one line (push line0 to the next page too)
      if (splitLine - 1 <= 0) {
        // nothing left after dropping: push the whole paragraph
        splitLine = -1
      } else {
        splitLine -= 1 // try tailLines = splitLine - 1
      }
    }

    if (splitLine > 0) {
      const newHead = nLines - splitLine
      if (newHead === 1) {
        // widow at page top: give up one line here so the next page gets 2 lines (Word)
        splitLine -= 1
        // fewer than 2 lines left at page bottom would be an orphan: push the whole paragraph
        if (splitLine < 2) splitLine = -1
      }
    }
  } else if (!widowOn) {
    // widowControl off: find the first line that doesn't fit
    let sumH = spaceBeforePx
    for (let li = 0; li < nLines; li++) {
      sumH += lineBoxes[li].height
      if (!fits(sumH)) {
        splitLine = li
        break
      }
    }
  } else {
    // only 1 line: push the whole paragraph
    splitLine = -1
  }

  if (splitLine <= 0) {
    // push the whole paragraph to the next page
    if (!pageEmpty()) newPage(block.top, curSection)
    place(totalH)
  } else {
    // break the page before line splitLine
    if (spaceBeforePx > 0) place(spaceBeforePx)
    for (let li = 0; li < splitLine; li++) place(lineBoxes[li].height)
    // page break (line offsets are element-relative: they start after the space-before)
    newPage(block.top + spaceBeforePx + lineBoxes[splitLine].offsetInBlock, curSection)
    // place remaining lines on the new page
    for (let li = splitLine; li < nLines; li++) place(lineBoxes[li].height)
    if (spaceAfterPx > 0) place(spaceAfterPx)
  }
}

/**
 * Hard-cut lines (best effort when the paragraph exceeds one page).
 */
function _hardCutLines(
  block: BlockBox,
  lineBoxes: Array<{ offsetInBlock: number; height: number }>,
  spaceBeforePx: number,
  spaceAfterPx: number,
  fits: (h: number) => boolean,
  place: (h: number) => void,
  pageEmpty: () => boolean,
  newPage: (y: number, section: number) => void,
  curSection: number,
) {
  if (spaceBeforePx > 0) {
    if (!fits(spaceBeforePx) && !pageEmpty()) {
      newPage(block.top, curSection)
    }
    place(spaceBeforePx)
  }
  for (const lb of lineBoxes) {
    if (!fits(lb.height) && !pageEmpty()) {
      newPage(block.top + spaceBeforePx + lb.offsetInBlock, curSection)
    }
    place(lb.height)
  }
  if (spaceAfterPx > 0) {
    if (!fits(spaceAfterPx) && !pageEmpty()) {
      newPage(block.top + block.height - spaceAfterPx, curSection)
    }
    place(spaceAfterPx)
  }
}

/** Per-section header/footer content heights (px); sectionGeoms uses these to compute body push-down */
export interface SectionHfHeights {
  headerPx: number
  footerPx: number
}

/** Body top = max(marginTop, headerDist + header height) */
export function effectiveTopPx(set: SectionSettings, headerPx: number): number {
  const dist = twipsToPx(set.headerDist ?? 720)
  return Math.max(twipsToPx(set.marginTop), headerPx > 0 ? dist + headerPx : 0)
}

/** Body bottom margin = max(marginBottom, footerDist + footer height) */
export function effectiveBottomPx(set: SectionSettings, footerPx: number): number {
  const dist = twipsToPx(set.footerDist ?? 720)
  return Math.max(twipsToPx(set.marginBottom), footerPx > 0 ? dist + footerPx : 0)
}

/**
 * Uniform typed line grid (w:docGrid type lines/linesAndChars): the pitch in
 * points when EVERY section declares the same typed pitch, else null. Mixed or
 * untyped docs don't snap (matches LO only for the uniform case; per-section
 * pitches would need per-block plumbing, and mixed-grid docs are rare).
 * The value feeds .doc-page { --doc-grid-pitch } which line-height round(up)
 * expressions consume.
 */
export function docGridPitchPt(sections: SectionInfo[]): number | null {
  if (sections.length === 0) return null
  let pitch: number | null = null
  for (const s of sections) {
    const g = s.settings.docGrid
    if (!g || (g.type !== 'lines' && g.type !== 'linesAndChars') || !g.linePitch) return null
    if (pitch === null) pitch = g.linePitch
    else if (pitch !== g.linePitch) return null
  }
  return pitch === null ? null : pitch / 20
}

/** Column count of a section (w:cols w:num; covers equal and explicit-width columns) */
export function sectionColumns(s: SectionInfo): number {
  return Math.max(1, s.settings.columns ?? 1)
}

/** Section column geometry (px). Equal-width columns divide evenly per w:cols
 *  w:space (default 720 twips); w:equalWidth="0" reads the explicit w:col
 *  width/space list (falling back to even division when the list is absent). */
export function sectionColGeom(s: SectionInfo): {
  cols: number
  /** first column's width — the uniform width when equalWidth */
  colWidthPx: number
  gapPx: number
  equalWidth: boolean
  /** per-column widths (length cols) */
  widths: number[]
  /** gap after column k (length cols-1) */
  gaps: number[]
} {
  const set = s.settings
  const contentW = twipsToPx(set.pageWidth - set.marginLeft - set.marginRight)
  const cols = sectionColumns(s)
  const gapPx = twipsToPx(set.colSpace ?? 720)
  const even = cols > 1 ? (contentW - gapPx * (cols - 1)) / cols : contentW
  let equalWidth = true
  let widths = Array.from({ length: cols }, () => even)
  let gaps = Array.from({ length: Math.max(cols - 1, 0) }, () => gapPx)
  if (cols > 1 && /<w:cols[^>]*w:equalWidth="0"/.test(s.sectPrXml ?? '')) {
    const colsXml = /<w:cols\b[^>]*>([\s\S]*?)<\/w:cols>/.exec(s.sectPrXml ?? '')?.[1] ?? ''
    const list = Array.from(colsXml.matchAll(/<w:col\b([^>]*)\/?>/g), (m) => ({
      w: twipsToPx(parseInt(/w:w="(\d+)"/.exec(m[1])?.[1] ?? '0', 10)),
      space: twipsToPx(parseInt(/w:space="(\d+)"/.exec(m[1])?.[1] ?? '0', 10)),
    }))
    if (list.length === cols && list.every((c) => c.w > 0)) {
      equalWidth = false
      widths = list.map((c) => c.w)
      gaps = list.slice(0, -1).map((c) => c.space)
    }
  }
  return { cols, gapPx, colWidthPx: widths[0] ?? contentW, equalWidth, widths, gaps }
}

/** RTL section (sectPr w:bidi): columns fill right-to-left (visual order only; engine indices stay logical) */
export function sectionBidi(s: SectionInfo): boolean {
  return /<w:bidi(?:\s*\/>|\s+w:val="(?:1|true|on)")/.test(s.sectPrXml ?? '')
}

/** One block's mixed-column canvas placement (consumed by editor/column-layout.ts) */
export interface ColumnBlockPlacement {
  el: HTMLElement
  /** column width (px); absent in single-column regions */
  widthPx?: number
  /** owning section's content width (--doc-content-w): tables resolve their spill/centering caps against it */
  contentWPx?: number
  /** owning section's side margins (--doc-margin-left/right overrides) */
  marginLeftPx?: number
  marginRightPx?: number
  dx: number
  dy: number
}

/**
 * Mixed-column canvas placements: for every block on a regioned page, the
 * column width plus a per-column constant translate mapping its stacked
 * single-flow position into the column slot. dy = region top − the column
 * start's offset from the page start (negative for later columns/regions:
 * they pull up over the vacated stacked space). Blocks are placed whole by
 * their top; floated/eless blocks are skipped.
 */
export function columnLayoutSpecs(
  blocks: BlockBox[],
  slices: PageSlice[],
  sections: SectionInfo[],
): ColumnBlockPlacement[] {
  const specs: ColumnBlockPlacement[] = []
  if (blocks.length === 0) return specs
  let bi = 0
  for (const slice of slices) {
    if (!slice.regions) {
      while (bi < blocks.length && blocks[bi].top < slice.end - 0.5) bi++
      continue
    }
    for (const region of slice.regions) {
      const sec = sections[Math.max(0, Math.min(region.section, sections.length - 1))]
      if (!sec) continue
      const geom = sectionColGeom(sec)
      const rtl = geom.cols > 1 && sectionBidi(sec)
      // left edge of each column (LTR): cumulative widths + gaps
      const xs: number[] = []
      let x = 0
      for (let c = 0; c < geom.cols; c++) {
        xs.push(x)
        x += geom.widths[c] + (geom.gaps[c] ?? 0)
      }
      const totalW = x
      for (let c = 0; c < region.columns.length; c++) {
        const col = region.columns[c]
        const w = geom.widths[Math.min(c, geom.widths.length - 1)]
        const dx = geom.cols > 1 ? (rtl ? totalW - (xs[c] ?? 0) - w : (xs[c] ?? 0)) : 0
        const dy = region.top - (col.start - slice.start)
        const widthPx = geom.cols > 1 ? w : undefined
        if (widthPx === undefined && Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) {
          // untouched single-column region at its natural place: no decorations
          while (bi < blocks.length && blocks[bi].top < col.end - 0.5) bi++
          continue
        }
        while (bi < blocks.length && blocks[bi].top < col.end - 0.5) {
          const b = blocks[bi]
          bi++
          if (!b.el || b.floated) continue
          if (b.top < col.start - 0.5) continue
          specs.push({ el: b.el, ...(widthPx !== undefined ? { widthPx } : {}), dx, dy })
        }
      }
    }
  }
  return specs
}

const isTableBlock = (el: HTMLElement) =>
  el.tagName === 'TABLE' || el.getAttribute('data-doc-protected') === 'table'

/**
 * Per-block wrap widths for documents whose sections disagree on content width,
 * e.g. a landscape section in a portrait document. The canvas lays the whole flow
 * on one page width; these placements make each section's blocks wrap at their
 * own content width. Every block gets an explicit width (not just the differing
 * sections'): preview clones render into per-section wrap widths, so any
 * container-relative block would reflow there. Tables keep their inline min()
 * width and get the section geometry via --doc-content-w / --doc-margin-* instead.
 */
export function sectionWidthSpecs(
  blocks: BlockBox[],
  sections: SectionInfo[],
  geoms: SectionGeom[],
): ColumnBlockPlacement[] {
  const canvasW = geoms[0]?.contentWidth
  if (
    canvasW === undefined ||
    !geoms.some((g) => g.contentWidth !== undefined && Math.abs(g.contentWidth - canvasW) > 0.5)
  )
    return []
  const specs: ColumnBlockPlacement[] = []
  for (const b of blocks) {
    if (!b.el || b.floated) continue
    const si = Math.max(0, Math.min(b.section ?? 0, geoms.length - 1))
    const w = geoms[si]?.contentWidth
    if (w === undefined) continue
    const set = sections[si]?.settings
    const spec: ColumnBlockPlacement = {
      el: b.el,
      dx: 0,
      dy: 0,
      contentWPx: w,
      marginLeftPx: set ? twipsToPx(set.marginLeft) : 0,
      marginRightPx: set ? twipsToPx(set.marginRight) : 0,
    }
    // blocks with an own inline width (tables, textboxes) size themselves;
    // paragraphs get the section width minus their indent margins
    if (!isTableBlock(b.el) && !b.el.style.width) {
      const cs = getComputedStyle(b.el)
      spec.widthPx = w - (parseFloat(cs.marginLeft) || 0) - (parseFloat(cs.marginRight) || 0)
    }
    specs.push(spec)
  }
  return specs
}

/**
 * sectPr w:vAlign (center/bottom) page shifts: blocks of a vertically aligned
 * page translate down into the page's free space — purely visual, through the
 * same decoration channel as column placement (the page band already spans the
 * full page height, so shifted blocks stay inside their page). 'both'
 * (justified) keeps top alignment, as does a page where a block crosses either
 * boundary (shifting one half of a split block would tear it) and multi-column
 * pages.
 */
export function vAlignShiftSpecs(
  blocks: BlockBox[],
  slices: PageSlice[],
  sections: SectionInfo[],
  geoms: SectionGeom[],
): ColumnBlockPlacement[] {
  const specs: ColumnBlockPlacement[] = []
  if (!sections.some((s) => s.settings.vAlign === 'center' || s.settings.vAlign === 'bottom'))
    return specs
  for (const slice of slices) {
    const va = sections[slice.section]?.settings.vAlign
    if (va !== 'center' && va !== 'bottom') continue
    if (slice.regions) continue
    const colH = geoms[slice.section]?.contentHeight ?? 0
    const free = colH - (slice.end - slice.start)
    if (free < 1) continue
    const dy = va === 'center' ? free / 2 : free
    const page: ColumnBlockPlacement[] = []
    let whole = true
    for (const b of blocks) {
      if (b.top + b.height <= slice.start + 0.5) continue
      if (b.top >= slice.end - 0.5) break
      if (b.top < slice.start - 0.5 || b.top + b.height > slice.end + 2) {
        whole = false
        break
      }
      if (!b.el || b.floated) continue
      page.push({ el: b.el, dx: 0, dy })
    }
    if (whole) specs.push(...page)
  }
  return specs
}

/** SectionInfo[] → pagination geometry
 *  - continuous with unchanged page geometry: no forced break (content flows on the same page)
 *  - continuous with changed page geometry (width/height change, e.g. landscape → portrait): forced break
 *  - nextPage/evenPage/oddPage: forced break
 *  - with hfHeights, oversized headers/footers squeeze body capacity
 */
export function sectionGeoms(
  sections: SectionInfo[],
  hfHeights?: SectionHfHeights[],
): SectionGeom[] {
  return sections.map((s, i) => {
    const cols = sectionColumns(s)
    let forceBreak = false
    let colBreakStart = false
    if (i > 0) {
      // nextColumn with the same multi-column count advances one column (Word,
      // tdf#135343 c14/c15); a changed count or a single-column layout acts like a
      // page break (tdf#135343 c12v3, n#750255)
      colBreakStart =
        s.startType === 'nextColumn' && cols > 1 && sectionColumns(sections[i - 1]) === cols
      const asContinuous = s.startType === 'continuous' || colBreakStart
      if (!asContinuous) {
        forceBreak = true
      } else {
        // continuous section: force a page break if the page size differs from the previous section (e.g. landscape → portrait)
        const prev = sections[i - 1].settings
        const cur = s.settings
        if (prev.pageWidth !== cur.pageWidth || prev.pageHeight !== cur.pageHeight) {
          forceBreak = true
        }
      }
    }
    const set = s.settings
    const hf = hfHeights?.[i]
    return {
      contentHeight:
        twipsToPx(set.pageHeight) -
        effectiveTopPx(set, hf?.headerPx ?? 0) -
        effectiveBottomPx(set, hf?.footerPx ?? 0),
      contentWidth: twipsToPx(set.pageWidth - set.marginLeft - set.marginRight),
      forceBreak,
      startType: s.startType,
      // colWidths only for explicit-width columns: the narrower-column gate is
      // meaningless when every column is the same width
      ...(cols > 1
        ? {
            cols,
            ...(sectionColGeom(s).equalWidth ? {} : { colWidths: sectionColGeom(s).widths }),
          }
        : {}),
      ...(colBreakStart && !forceBreak ? { colBreakStart: true } : {}),
    }
  })
}

/**
 * evenPage/oddPage sections: insert a zero-height blank page slice when the section's
 * first page has the wrong physical parity. Parity is approximated by physical
 * page order (1-based) — exact when page numbers run from 1.
 */
export function insertParityBlanks(slices: PageSlice[], geoms: SectionGeom[]): PageSlice[] {
  if (!geoms.some((g) => g.startType === 'evenPage' || g.startType === 'oddPage')) return slices
  const out: PageSlice[] = []
  for (const s of slices) {
    const prev = out[out.length - 1]
    if (prev && s.section !== prev.section) {
      const st = geoms[Math.max(0, Math.min(s.section, geoms.length - 1))]?.startType
      const ordinal = out.length + 1
      if ((st === 'evenPage' && ordinal % 2 === 1) || (st === 'oddPage' && ordinal % 2 === 0)) {
        out.push({ start: s.start, end: s.start, section: prev.section })
      }
    }
    out.push(s)
  }
  return out
}

export type HfVariant = 'default' | 'first' | 'even'
export interface SectionHfRefs {
  header: Partial<Record<HfVariant, string>>
  footer: Partial<Record<HfVariant, string>>
}

/** Effective header/footer refs per section: undefined variants inherit from earlier sections */
export function effectiveHfRefs(sections: SectionInfo[]): SectionHfRefs[] {
  const out: SectionHfRefs[] = []
  let prev: SectionHfRefs = { header: {}, footer: {} }
  for (const s of sections) {
    const cur: SectionHfRefs = {
      header: { ...prev.header, ...s.headerRefs },
      footer: { ...prev.footer, ...s.footerRefs },
    }
    out.push(cur)
    prev = cur
  }
  return out
}

function hfHasContent(hf: HeaderFooter | HfPartInfo | null | undefined): boolean {
  if (!hf) return false
  if ((hf as HeaderFooter).pageNumber || (hf as HfPartInfo).hasPageNumber) return true
  if (hf.text.trim()) return true
  if ((hf as HfPartInfo).images?.length) return true
  return (hf.paras ?? []).some((p) => p.runs.some((r) => r.text.trim()))
}

/**
 * Direct (no-preview) PDF export prints the edit canvas, where the header/footer exists
 * once per document instead of once per page — so any printable header/footer must force
 * the preview-merge export path. Empty parts don't count.
 */
export function hasPrintableHeaderFooter(input: {
  /** local edit state: global header/footer, active variants, per-section edits */
  edited: Array<HeaderFooter | null | undefined>
  sections: SectionInfo[]
  hfParts?: Record<string, HfPartInfo>
  evenOddHf?: boolean
}): boolean {
  if (input.edited.some(hfHasContent)) return true
  const refs = effectiveHfRefs(input.sections)
  return refs.some((ref, i) => {
    const variants: HfVariant[] = ['default']
    if (input.sections[i]?.titlePg) variants.push('first')
    if (input.evenOddHf) variants.push('even')
    return variants.some((v) => {
      const h = ref.header[v]
      const f = ref.footer[v]
      return (
        hfHasContent(h ? input.hfParts?.[h] : null) || hfHasContent(f ? input.hfParts?.[f] : null)
      )
    })
  })
}

/** Displayed page number per page: restart at the section's pgNumType w:start, otherwise continue;
 *  evenPage/oddPage section breaks skip a number to fix parity (when not restarting) */
export function pageNumbers(slices: PageSlice[], sections: SectionInfo[]): number[] {
  const nums: number[] = []
  let n = 0
  let prevSection = -1
  for (const slice of slices) {
    if (slice.section !== prevSection) {
      const sec = sections[slice.section]
      const start = sec?.pageNumberStart
      n = start ?? n + 1
      if (start === undefined && prevSection !== -1) {
        if (sec?.startType === 'evenPage' && n % 2 === 1) n += 1
        if (sec?.startType === 'oddPage' && n % 2 === 0) n += 1
      }
      prevSection = slice.section
    } else {
      n += 1
    }
    nums.push(n)
  }
  return nums
}

const ROMAN: Array<[number, string]> = [
  [1000, 'M'],
  [900, 'CM'],
  [500, 'D'],
  [400, 'CD'],
  [100, 'C'],
  [90, 'XC'],
  [50, 'L'],
  [40, 'XL'],
  [10, 'X'],
  [9, 'IX'],
  [5, 'V'],
  [4, 'IV'],
  [1, 'I'],
]

function toRoman(n: number): string {
  let out = ''
  let rest = Math.max(1, Math.floor(n))
  for (const [v, s] of ROMAN) {
    while (rest >= v) {
      out += s
      rest -= v
    }
  }
  return out
}

/** 1→A ... 26→Z, 27→AA (Word letter numbering) */
function toLetters(n: number): string {
  let out = ''
  let rest = Math.max(1, Math.floor(n))
  while (rest > 0) {
    rest -= 1
    out = String.fromCharCode(65 + (rest % 26)) + out
    rest = Math.floor(rest / 26)
  }
  return out
}

function toGreek(n: number, base: number): string {
  if (n < 1) return String(n)
  // 24-letter alphabet (no final sigma); 25 -> αα, skip the ς slot from the 18th letter on
  const idx = ((n - 1) % 24) + 1
  const repeat = Math.floor((n - 1) / 24) + 1
  return String.fromCharCode(base + idx - 1 + (idx >= 18 ? 1 : 0)).repeat(repeat)
}

const CN_DIGITS = '〇一二三四五六七八九'

function toChinese(n: number): string {
  if (n < 10) return CN_DIGITS[n]
  if (n < 20) return `十${n % 10 ? CN_DIGITS[n % 10] : ''}`
  if (n < 100) return `${CN_DIGITS[Math.floor(n / 10)]}十${n % 10 ? CN_DIGITS[n % 10] : ''}`
  return String(n)
    .split('')
    .map((d) => CN_DIGITS[Number(d)])
    .join('')
}

/** Display the page number in the section's number format (w:pgNumType w:fmt) */
export function formatPageNumber(n: number, fmt?: string): string {
  switch (fmt) {
    case 'numberInDash':
      return `- ${n} -`
    case 'lowerLetter':
      return toLetters(n).toLowerCase()
    case 'upperLetter':
      return toLetters(n)
    case 'lowerRoman':
      return toRoman(n).toLowerCase()
    case 'upperRoman':
      return toRoman(n)
    case 'lowerGreek':
      return toGreek(n, 0x3b1)
    case 'upperGreek':
      return toGreek(n, 0x391)
    case 'chineseCounting':
    case 'chineseCountingThousand':
      return toChinese(n)
    default:
      return String(n)
  }
}

/** Whether each page is the first page of its section (for section-level titlePg) */
export function sectionFirstPages(slices: PageSlice[]): boolean[] {
  let prev = -1
  return slices.map((s) => {
    const first = s.section !== prev
    prev = s.section
    return first
  })
}

/**
 * Live section list: when a non-final section's break paragraph (the block at
 * lastBlockIndex) has been deleted from the canvas, that section merges into the
 * next (content before a section break takes the following section's
 * page setup). This is derived and doesn't mutate the authoritative sections state,
 * so undoing the deletion restores naturally; readSections rebuilds after saving.
 */
export function liveSections(
  sections: SectionInfo[],
  blocks: BlockBox[],
  /** boundaries in the DOM but not in the block list (zero-height section-break chips) */
  extraPresent?: Set<number>,
  /** break paragraphs whose mark is a tracked deletion: Word's markup view drops the break */
  trackedDeleted?: Set<number>,
): SectionInfo[] {
  if (sections.length <= 1) return sections
  const present = new Set<number>(extraPresent)
  for (const b of blocks) if (b.docxIndex !== undefined) present.add(b.docxIndex)
  if (trackedDeleted) for (const i of trackedDeleted) present.delete(i)
  const out: SectionInfo[] = []
  let carryFirst: number | null = null
  let changed = false
  sections.forEach((s, i) => {
    const first = carryFirst ?? s.firstBlockIndex
    carryFirst = null
    if (i < sections.length - 1 && !present.has(s.lastBlockIndex)) {
      changed = true
      carryFirst = first
      return
    }
    out.push(first === s.firstBlockIndex ? s : { ...s, firstBlockIndex: first })
  })
  return changed ? out : sections
}

/** Tag each block's owning section by the sections' block ranges (lastBlockIndex); new blocks without docxIndex inherit from the previous block */
export function assignSections(blocks: BlockBox[], sections: SectionInfo[]): void {
  const ends = sections.map((s) => s.lastBlockIndex)
  let prev = 0
  for (const block of blocks) {
    let s = prev
    if (block.docxIndex !== undefined) {
      const i = ends.findIndex((end) => block.docxIndex! <= end)
      s = i >= 0 ? i : ends.length - 1
    }
    block.section = s
    prev = s
  }
}

/** Page containing content-area Y (1-based) */
export function pageAt(slices: PageSlice[], y: number): number {
  let page = 1
  for (let i = 1; i < slices.length; i++) {
    if (y >= slices[i].start) page = i + 1
  }
  return page
}

/**
 * Pages the user can see: an even/odd-section parity blank shares its start with the
 * neighbouring slice and draws no page, so NUMPAGES, the status bar, and the gap
 * header/footer widgets all count only distinct slice starts (up to `upTo` slices).
 */
export function visiblePageCount(slices: PageSlice[], upTo = slices.length): number {
  let n = 0
  for (let i = 0; i < Math.min(upTo, slices.length); i++) {
    // a zero-height predecessor is a deliberate blank page (leading/double w:br,
    // even/odd parity): the page after it is still its own visible page
    if (
      i === 0 ||
      slices[i].start !== slices[i - 1].start ||
      slices[i - 1].end === slices[i - 1].start
    )
      n++
  }
  return n
}

export interface MeasuredContent {
  blocks: BlockBox[]
  totalHeight: number
  /** absolutely-positioned boxes of floating-textbox anchors (virtual coords, shift-neutral) */
  floats: FloatBox[]
  /** docxIndex of section-break chips present in the DOM but excluded from the block
   *  list (zero-height in Word): liveSections must still see their boundaries */
  sectBreaks: Set<number>
}

/** one floating textbox/shape box: DOM element + gapless virtual position */
export interface FloatBox {
  el: HTMLElement
  top: number
  height: number
  /** gapless virtual position of the anchor wrapper (the box's page follows it) */
  anchorTop: number
  /** page-pinned box: `top` is raw page-relative Y, not a flow position */
  pinned: boolean
  /** page/margin-relative V rendered from the anchor: `top` - `anchorTop` is
   *  the page-relative Y; the box belongs at that offset on the anchor's page */
  pageRelV: boolean
}

/** Page-bottom footnote entry (number/text/estimated height): shared by canvas page gaps and the pagination preview */
export interface PageNoteItem {
  no: number
  id: string
  text: string
  height: number
  /** rich display runs (one group per paragraph); omitted for unformatted footnotes, rendering falls back to plain text */
  richParas?: Array<
    Array<{
      text: string
      bold?: boolean
      italic?: boolean
      underline?: boolean
      strike?: boolean
      color?: string
      sizeHalfPoints?: number
      caps?: 'all' | 'small' | 'none'
    }>
  >
}

/**
 * Collect the editor's top-level block boxes (relative to the content-area top,
 * converted back to 100% zoom). origin is the content-area top's screen Y (page
 * rect.top + top margin × zoom). Page-gap decorations (.page-gap) are not content:
 * they are skipped and subtracted from subsequent block coordinates, yielding
 * "gapless continuous flow" virtual coordinates so slicing is independent of the gaps.
 */
export function measureBlocks(
  pm: HTMLElement,
  origin: number,
  zoomFactor: number,
): MeasuredContent {
  const blocks: BlockBox[] = []
  const floats: FloatBox[] = []
  const sectBreaks = new Set<number>()
  let totalHeight = 0
  let gapAccum = 0
  for (const el of Array.from(pm.children) as HTMLElement[]) {
    const rect = el.getBoundingClientRect()
    if (el.classList.contains('page-gap') || el.classList.contains('page-float-host')) {
      gapAccum += rect.height
      continue
    }
    // floating-anchor boxes: absolute children of a zero-height wrapper; record
    // shift-neutral virtual positions so pages can be extended to contain them
    if (el.classList.contains('doc-protected-floating') || el.classList.contains('doc-img-float')) {
      const anchorTop = (rect.top - origin - gapAccum) / zoomFactor
      const pinned = el.classList.contains('doc-protected-pagepinned')
      for (const box of Array.from(
        el.querySelectorAll(':scope > .doc-textbox, :scope > .doc-img-wrap'),
      )) {
        const b = (box as HTMLElement).getBoundingClientRect()
        if (b.height <= 0) continue
        const applied = parseFloat((box as HTMLElement).dataset.pageFloatDy ?? '0') || 0
        floats.push({
          el: box as HTMLElement,
          // pinned boxes position against the page box: gaps never move them
          top: (b.top - origin - (pinned ? 0 : gapAccum)) / zoomFactor - applied,
          height: b.height / zoomFactor,
          anchorTop,
          pinned,
          pageRelV: (box as HTMLElement).dataset.pageRelV === '1',
        })
      }
    }
    // sectPr-only paragraph: the section-break mark itself has no height in Word
    // (its editor chip must not occupy a page or hold a forced break's page open),
    // but its boundary must stay visible to liveSections or the section merges away
    if (el.classList.contains('doc-protected-sectbreak')) {
      const idx = el.getAttribute('data-idx')
      if (idx) sectBreaks.add(parseInt(idx, 10))
      continue
    }
    // Word ignores page-type w:br inside table cells — drop them before deriving flags
    const breakEls = Array.from(el.querySelectorAll('.doc-field-pagebreak, .doc-page-br')).filter(
      (b) => !b.closest('td, th'),
    )
    const hasBreak = breakEls.length > 0
    const hasColBreak = Array.from(el.querySelectorAll('.doc-col-br')).some(
      (b) => !b.closest('td, th'),
    )
    // zero-height blocks are skipped, except a break carrier (e.g. a floating
    // textbox whose anchor paragraph holds a page-type w:br) must still be seen
    if (rect.height <= 0 && !hasBreak) continue
    // in-block gaps from mid-paragraph page breaks: subtract from block height and add to the gap accumulator for later blocks
    const innerGap = innerGapHeight(el)
    const top = (rect.top - origin - gapAccum) / zoomFactor
    const height = (rect.height - innerGap) / zoomFactor
    const idxAttr = el.getAttribute('data-idx')
    // break-only paragraph (br line + ProseMirror trailing-break phantom line): marked
    // for dedicated placement — Word pushes it into a deliberate blank page when its
    // line doesn't fit at the page bottom. Word renders a single break line, but the
    // DOM height spans one line box per <br> (a text-less paragraph lays out exactly
    // brCount line boxes), so the fit height is one line's share.
    const breakOnly = hasBreak && !(el.textContent ?? '').trim() && !el.querySelector('img')
    const brLines = breakOnly ? el.querySelectorAll('br').length : 0
    // a single break with no text before it: Word starts this block's own content
    // on a new page, so it maps to breakBefore (breakAfter only pushes the next block)
    let leadingBreak = false
    if (breakEls.length === 1 && (el.textContent ?? '').trim()) {
      const r = document.createRange()
      r.setStart(el, 0)
      r.setEndBefore(breakEls[0])
      leadingBreak = !r.toString().trim()
    }
    const floated =
      /(?:^|\s)img-wrap-(?:square|tight|through)-(?:left|right)(?:\s|$)/.test(el.className) ||
      el.classList.contains('doc-table-float-left') ||
      el.classList.contains('doc-table-float-right')
    const emptyPara = !(el.textContent ?? '').trim() && !el.querySelector('img')
    // non-reflowable blocks keep their rendered width in any column (tables,
    // anchored/inline textbox shapes; protected text paragraphs still reflow)
    const fixedWidth =
      el.tagName === 'TABLE' ||
      el.classList.contains('doc-protected-textboxes') ||
      !!el.querySelector('table')
    blocks.push({
      top,
      height,
      ...(floated ? { floated: true } : {}),
      ...(emptyPara ? { emptyPara: true } : {}),
      ...(fixedWidth ? { fixedWidthPx: rect.width / zoomFactor } : {}),
      breakBefore: el.classList.contains('page-break-before') || leadingBreak || undefined,
      breakBeforeBr: leadingBreak || undefined,
      breakAfter: (hasBreak && !leadingBreak) || undefined,
      colBreakAfter: hasColBreak || undefined,
      breakForce: (hasBreak && rect.height <= 0) || undefined,
      el,
      ...(breakOnly ? { breakOnlyLineH: brLines > 1 ? height / brLines : height } : {}),
      ...(idxAttr ? { docxIndex: parseInt(idxAttr, 10) } : {}),
    })
    gapAccum += innerGap
    totalHeight = Math.max(totalHeight, top + height)
  }
  // inter-block CSS margin (space after): rect height excludes it, but it occupies
  // vertical layout space. Attribute it to the previous block's spaceAfterPx and add
  // it to the height, so the engine's capacity bookkeeping matches Y coordinates and
  // the "trailing space doesn't consume page capacity" rule (Word breaks by text only) applies.
  for (let i = 0; i + 1 < blocks.length; i++) {
    const gap = blocks[i + 1].top - (blocks[i].top + blocks[i].height)
    if (gap > 0.5) {
      blocks[i].spaceAfterPx = (blocks[i].spaceAfterPx ?? 0) + gap
      blocks[i].height += gap
    }
  }
  // leading offset before the first block (first-paragraph space-before): Word
  // consumes page capacity with it, so fold it in like the inter-block margins
  // (space-before semantics: counted before the block's own lines)
  const first = blocks[0]
  const firstIsTable =
    !!first?.el && (first.el.matches('table') || !!first.el.querySelector('table'))
  if (blocks.length > 0 && first.top > 0.5 && !firstIsTable) {
    const lead = blocks[0].top
    blocks[0].spaceBeforePx = (blocks[0].spaceBeforePx ?? 0) + lead
    blocks[0].height += lead
    blocks[0].top = 0
  }
  return { blocks, totalHeight, floats, sectBreaks }
}

/**
 * Canvas anchor for the endnote area: display-state bottom (layout px, relative to
 * baseTop) of the last visible in-flow block. Word places endnotes right after the
 * last body line, but the canvas paper is padded to a full page, so the area cannot
 * just stack after the editor — it is absolutely positioned at this Y instead.
 */
export function endnotesAnchorY(pm: HTMLElement, baseTop: number, factor: number): number | null {
  for (let i = pm.children.length - 1; i >= 0; i--) {
    const el = pm.children[i] as HTMLElement
    if (el.classList.contains('page-gap') || el.classList.contains('page-float-host')) continue
    const rect = el.getBoundingClientRect()
    if (rect.height <= 0) continue
    return (rect.bottom - baseTop) / factor
  }
  return null
}

/**
 * Endnote layout: endnotes gather at the end of the document
 * (or section) right after the body, flowing to later pages when they don't fit.
 * Before slicing, the endnotes area is appended as a virtual block at flow end: one
 * line box per endnote (separator height merged into the first), widowControl off →
 * page breaks are allowed between any entries. Returns the endnotes area's top Y.
 */
export function appendEndnotesBlock(
  blocks: BlockBox[],
  totalHeight: number,
  items: PageNoteItem[],
  separatorH: number,
): { totalHeight: number; top: number } | null {
  if (items.length === 0) return null
  const top = totalHeight
  const lineBoxes: Array<{ offsetInBlock: number; height: number }> = []
  let off = 0
  for (let i = 0; i < items.length; i++) {
    const h = (i === 0 ? separatorH : 0) + items[i].height
    lineBoxes.push({ offsetInBlock: off, height: h })
    off += h
  }
  blocks.push({
    top,
    height: off,
    lineBoxes,
    widowControl: false,
    isEndnotes: true,
    ...(blocks.length > 0 && blocks[blocks.length - 1].section !== undefined
      ? { section: blocks[blocks.length - 1].section }
      : {}),
  })
  return { totalHeight: top + off, top }
}

/**
 * Floating boxes extending past the flow end (Word: an anchored object that
 * does not fit on its page moves to the next page) need pages to exist there:
 * append a virtual zero-content block spanning to the lowest float bottom so
 * the slicer materializes the trailing page(s). Fine-grained line boxes let it
 * split at any page boundary without widow constraints.
 */
export function appendFloatSpillBlock(
  blocks: BlockBox[],
  totalHeight: number,
  floats: FloatBox[],
  /** allowed overhang into the landing page's bottom margin (px): Word draws
   *  anchored boxes over the margin instead of opening a page for them */
  bottomOverhangPx = 0,
): number | null {
  let bottom = 0
  // page-absolute boxes (pinned / page-relative V) draw on their anchor's
  // page — Word never opens a page for them, and their measured tops are not
  // flow extents (pinned = page coords, pageRelV = anchor + page offset)
  for (const f of floats) {
    if (!f.pinned && !f.pageRelV) bottom = Math.max(bottom, f.top + f.height)
  }
  bottom -= bottomOverhangPx
  if (bottom <= totalHeight + 1) return null
  const top = totalHeight
  const spill = bottom - totalHeight
  const STEP = 24
  const lineBoxes: Array<{ offsetInBlock: number; height: number }> = []
  for (let off = 0; off < spill; off += STEP) {
    lineBoxes.push({ offsetInBlock: off, height: Math.min(STEP, spill - off) })
  }
  blocks.push({
    top,
    height: spill,
    lineBoxes,
    widowControl: false,
    isFloatSpill: true,
    ...(blocks.length > 0 && blocks[blocks.length - 1].section !== undefined
      ? { section: blocks[blocks.length - 1].section }
      : {}),
  })
  return top + spill
}

/**
 * Two-pass slicing: slice by block first, then collect DOM line-box boundaries for
 * blocks crossing page bounds and re-slice. Only blocks that cross a page or exceed
 * one page get line collection (at most one per page, negligible cost).
 * metaOf: docxIndex → parse-layer pagination constraints (keepNext/widow/table row flags).
 */
export function sliceWithLineSplit(
  blocks: BlockBox[],
  geoms: SectionGeom[],
  totalHeight: number,
  zoomFactor: number,
  metaOf?: BlockMetaOf,
): PageSlice[] {
  if (metaOf) applyBlockMeta(blocks, metaOf)
  let slices = computeSectionedSlicesF2(blocks, geoms, totalHeight)
  // re-slicing can surface new candidate blocks (a block pushed to a page top only
  // after an earlier block gained line data) — iterate to a fixed point, bounded
  for (let i = 0; i < 3; i++) {
    const changed = fillLineBoxes(blocks, geoms, zoomFactor, slices, metaOf)
    if (!changed) break
    slices = computeSectionedSlicesF2(blocks, geoms, totalHeight)
  }
  return insertParityBlanks(slices, geoms)
}

/**
 * Collect DOM line-box data for pagination candidate blocks (F2 model): blocks that
 * cross a page bound, exceed one page, or were pushed wholesale to a page top (the
 * second pass may pull lines back to the previous page). Other blocks are skipped, so cost is negligible.
 * Table blocks → tableRows (tr boundaries; never cuts into text lines inside cells); text blocks → lineBoxes.
 * Returns whether any block was filled (true means the caller must re-slice).
 */
/**
 * DOM line/row sampling is the hot path of repeated repagination: the set of
 * page-crossing blocks is stable across edits, so raw samples are cached by
 * element identity plus a cheap content/geometry signature. Entries drop with
 * their element (WeakMap) or when the signature stops matching.
 */
const lineSampleCache = new WeakMap<
  HTMLElement,
  { sig: string; boundaries?: number[]; rows?: TableRowBox[] }
>()

// webfont loads shift line boxes without changing block height (explicit line
// heights), so the geometry/content signature alone cannot see them
let lineSampleFontEpoch = 0

export function bumpLineSampleFontEpoch(): void {
  lineSampleFontEpoch++
}

function lineSampleSig(el: HTMLElement, textH: number): string {
  // djb2 over the text: equal-length edits must still invalidate
  const text = el.textContent ?? ''
  let h = 5381
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0
  // width guards width-only reflows; descendant count guards nested (e.g. table
  // cell) structure changes that keep the direct-child count. A stale miss only
  // costs one re-sample, so quantization errs toward invalidating.
  const w = el.getBoundingClientRect().width
  const nodes = el.getElementsByTagName('*').length
  return `${lineSampleFontEpoch}:${Math.round(textH * 4)}:${Math.round(w * 4)}:${nodes}:${h}`
}

export function fillLineBoxes(
  blocks: BlockBox[],
  geoms: SectionGeom[],
  zoomFactor: number,
  slices?: PageSlice[],
  metaOf?: BlockMetaOf,
): boolean {
  const geomOf = (s: number) => geoms[Math.max(0, Math.min(s, geoms.length - 1))]
  // cut bounds = page bounds + column bounds of multi-column pages (blocks crossing within a column also need line-level splits)
  const breaks: number[] = []
  ;(slices ?? []).forEach((s, i) => {
    if (i > 0) breaks.push(s.start)
    for (const r of s.regions ?? []) {
      for (const c of r.columns) {
        if (c.start > 0.5 && !breaks.includes(c.start)) breaks.push(c.start)
      }
    }
  })
  let changed = false
  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i]
    if (!block.el || block.lineBoxes || block.tableRows) continue
    // Anchored textbox/shape blocks are atomic like Word shapes: their inner
    // text lines (usually inside fixed, clipped boxes) are not page-break
    // points. Left line-less, an over-page block places whole and overlaps the
    // bottom margin; the next block turns the page (Word-like shape overflow).
    if (block.el.classList.contains('doc-protected-textboxes')) continue
    const contentH = geomOf(block.section ?? 0)?.contentHeight ?? 0
    if (contentH <= 0) continue
    const bottom = block.top + block.height
    const crossing = breaks.some((y) => block.top < y && y < bottom)
    const atPageTop = breaks.some((y) => Math.abs(block.top - y) < 0.5)
    if (
      block.height <= contentH &&
      !crossing &&
      !atPageTop &&
      // chain anchors always need line/row data: the chain only keeps with the
      // anchor's first line(s)/row, so the whole-block height is misleading
      !(i > 0 && blocks[i - 1].keepNext && !block.keepNext)
    )
      continue

    // line boxes tile only the text area (block height includes the merged-in
    // space-after and any folded-in leading space-before, which lines must not cover)
    const textH = block.height - (block.spaceAfterPx ?? 0) - (block.spaceBeforePx ?? 0)
    const sig = lineSampleSig(block.el, textH)
    const cached = lineSampleCache.get(block.el)
    const hit = cached?.sig === sig ? cached : null

    if (block.el.querySelector('tr')) {
      // flags mutate the rows, so cached rows are cloned per use
      const rows = hit?.rows
        ? hit.rows.map((r) => ({ ...r }))
        : domTableRows(block.el, textH, zoomFactor)
      if (!hit?.rows) lineSampleCache.set(block.el, { sig, rows: rows.map((r) => ({ ...r })) })
      if (rows.length > 0) {
        const flags =
          block.docxIndex !== undefined ? metaOf?.(block.docxIndex)?.tableRowFlags : undefined
        if (flags)
          rows.forEach((r, i) => {
            // Editable native tables publish an explicit live value on each tr;
            // it must beat the source XML so turning repetition off takes effect
            // before the document is saved and reopened.
            if (r.isHeader === undefined && flags[i]?.isHeader) r.isHeader = true
            if (flags[i]?.cantSplit) r.cantSplit = true
            if (flags[i]?.minHPx) r.minHPx = flags[i].minHPx
          })
        block.tableRows = rows
        changed = true
      }
      continue
    }
    // synthesized over-page cuts below mutate the list, so cached entries are copied out
    const boundaries = hit?.boundaries
      ? [...hit.boundaries]
      : domLineBoundaries(block.el, zoomFactor)
    if (!hit?.boundaries) lineSampleCache.set(block.el, { sig, boundaries: [...boundaries] })
    if (boundaries.length === 0 && block.height > contentH) {
      // over-page block with no text lines (e.g. a large image): synthesize cut points at page height, equivalent to hard pixel cuts
      for (let y = contentH; y < block.height; y += contentH) boundaries.push(y)
    }
    if (boundaries.length > 0) {
      block.lineBoxes = tileBoxes(boundaries, textH)
      changed = true
    }
  }
  return changed
}

/** Boundary list (excluding 0) → line boxes tiling the block height (heights are adjacent-boundary diffs; the first box starts at 0) */
function tileBoxes(
  boundaries: number[],
  blockHeight: number,
): Array<{ offsetInBlock: number; height: number }> {
  const tops = [0, ...boundaries.filter((b) => b > 0.5 && b < blockHeight)]
  return tops.map((top, i) => ({
    offsetInBlock: top,
    height: (i + 1 < tops.length ? tops[i + 1] : blockHeight) - top,
  }))
}

/** Extract each tr's tblHeader/cantSplit/atLeast-trHeight flags from table XML (header repetition across breaks / unsplittable rows / reserved row heights) */
export function tableRowFlags(
  tableXml: string,
): Array<{ isHeader: boolean; cantSplit: boolean; minHPx?: number }> {
  const flags: Array<{ isHeader: boolean; cantSplit: boolean; minHPx?: number }> = []
  for (const m of tableXml.matchAll(/<w:tr[\s>][\s\S]*?(?=<w:tr[\s>]|<\/w:tbl>)/g)) {
    const trPr = m[0].match(/<w:trPr>[\s\S]*?<\/w:trPr>/)?.[0] ?? ''
    // non-exact w:trHeight = atLeast (parse.ts semantics); exact rows keep the
    // split path (deliberate clip deviation, see _placeTable). Clamp mirrors
    // parse.ts (MS-OI29500 2.1.51: 31680 twips / 22in).
    const trH = trPr.match(/<w:trHeight\b[^>]*>/)?.[0] ?? ''
    const val = Number(/w:val="(\d+)"/.exec(trH)?.[1])
    const atLeast = Number.isFinite(val) && val > 0 && !/w:hRule="exact"/.test(trH)
    flags.push({
      isHeader: /<w:tblHeader(?!\s+w:val="(?:0|false)")/.test(trPr),
      cantSplit: /<w:cantSplit(?!\s+w:val="(?:0|false)")/.test(trPr),
      ...(atLeast ? { minHPx: Math.min(val, 31680) / 15 } : {}),
    })
  }
  return flags
}

/** Extract each tr's tblHeader flag from table XML (header repeated at page top after a table break) */
export function tableHeaderFlags(tableXml: string): boolean[] {
  return tableRowFlags(tableXml).map((f) => f.isHeader)
}

/**
 * Block-level pagination constraints (injection channel from parse-layer results into DOM-measured blocks).
 * The canvas/preview measureBlocks only has geometry; semantics like keepNext are attached by docxIndex.
 */
export interface BlockMeta {
  keepNext?: boolean
  keepLines?: boolean
  /** pageBreakBefore (direct or style-level): force a page break before the block */
  breakBefore?: boolean
  /** false only when explicitly disabled (Word default on) */
  widowControl?: false
  /** table blocks: per-tr header/unsplittable/reserved-height flags (applied by fillLineBoxes when collecting rows) */
  tableRowFlags?: Array<{ isHeader: boolean; cantSplit: boolean; minHPx?: number }>
  /** Word 2013+ layout (settings compatibilityMode >= 15): a multirow tblHeader block that doesn't fit the remaining space pushes the table to a fresh page */
  modernTableHeaders?: boolean
  /** page-bottom height reserved for footnote refs inside the block (px): merged into block height and space-after (doesn't consume text capacity) */
  footnoteExtraPx?: number
}

export type BlockMetaOf = (docxIndex: number) => BlockMeta | undefined

/** Inject parse-layer constraints into measured blocks (call before slicing; table row flags are applied by fillLineBoxes) */
export function applyBlockMeta(blocks: BlockBox[], metaOf: BlockMetaOf): void {
  for (const b of blocks) {
    if (b.docxIndex === undefined) continue
    const meta = metaOf(b.docxIndex)
    if (!meta) continue
    if (meta.keepNext) b.keepNext = true
    if (meta.modernTableHeaders) b.modernTableHeaders = true
    if (meta.keepLines) b.keepLines = true
    if (meta.breakBefore) b.breakBefore = true
    if (meta.widowControl === false) b.widowControl = false
    if (meta.footnoteExtraPx) {
      // matches the parity model: footnote height enters the block-height bookkeeping to consume page capacity, and also the space-after
      // (fits' "text fits" check subtracts space-after, so the reservation doesn't affect the paragraph's own line breaking)
      b.height += meta.footnoteExtraPx
      b.spaceAfterPx = (b.spaceAfterPx ?? 0) + meta.footnoteExtraPx
      b.footnoteExtraPx = (b.footnoteExtraPx ?? 0) + meta.footnoteExtraPx
    }
  }
}

/** Table block: one line box per tr, heights tiling the block height (borders folded into first/last rows).
 *  In-table page gaps (table-break decoration rows) don't count as rows; their height is subtracted from the offsets of rows below */
function domTableRows(el: HTMLElement, blockHeight: number, zoomFactor: number): TableRowBox[] {
  const gaps = Array.from(el.querySelectorAll('.page-gap-inline')).map((g) =>
    g.getBoundingClientRect(),
  )
  const gapAbove = (top: number) => gaps.reduce((s, g) => (g.top <= top ? s + g.height : s), 0)
  const elTop = el.getBoundingClientRect().top
  // take only the outer table's real rows: trs of nested tables inside cells
  // (.doc-nested-table) are in-row content, and decoration rows (page gaps /
  // repeated tblHeader clones) are not page-split units — counting them would
  // add phantom boundaries and shift the tableRowFlags index alignment
  const trs = Array.from(el.querySelectorAll('tr')).filter(
    (tr) =>
      !tr.closest('.doc-nested-table') &&
      !tr.classList.contains('page-gap') &&
      !tr.classList.contains('page-repeat-header'),
  )
  const tops: number[] = []
  // skip trs[0]: the first row starts at box 0 by definition — its measured
  // offset is just the collapsed-border half-width (1px at w:sz=12), and
  // letting it through creates a phantom row that shifts the trs[i] pairing
  for (const tr of trs.slice(1)) {
    const trTop = tr.getBoundingClientRect().top
    const off = (trTop - elTop - gapAbove(trTop)) / zoomFactor
    if (off > 0.5) tops.push(off)
  }
  return tileBoxes(tops, blockHeight).map((b, i) => {
    if (!trs[i]) return { height: b.height }
    const { cuts, contentBottom } = rowCutYs(
      trs[i],
      b.offsetInBlock,
      b.height,
      elTop,
      gapAbove,
      zoomFactor,
    )
    return {
      height: b.height,
      contentBottom,
      ...(trs[i].hasAttribute('data-repeat-header')
        ? { isHeader: trs[i].getAttribute('data-repeat-header') === '1' }
        : {}),
      ...(cuts.length > 0 ? { cutYs: cuts } : {}),
    }
  })
}

/** In-row safe cut points (relative to row top, px, ascending): line-level candidates
 *  per cell (Word breaks between any two lines), rejecting cuts that would cross a
 *  line box in another cell. Also reports the lowest content-band bottom. */
function rowCutYs(
  tr: Element,
  rowTop: number,
  rowHeight: number,
  elTop: number,
  gapAbove: (top: number) => number,
  zoomFactor: number,
): { cuts: number[]; contentBottom: number } {
  const cells = Array.from(tr.children).filter((c) => c.tagName === 'TD' || c.tagName === 'TH')
  const range = document.createRange()
  const cellBands: Array<Array<[number, number]>> = []
  for (const cell of cells) {
    const bands: Array<[number, number]> = []
    const add = (r: DOMRect) => {
      if (r.height <= 0 || r.width <= 0) return
      bands.push([
        (r.top - elTop - gapAbove(r.top)) / zoomFactor - rowTop,
        (r.bottom - elTop - gapAbove(r.bottom)) / zoomFactor - rowTop,
      ])
    }
    const walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT)
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (n.parentElement?.closest('.page-gap, .page-float-host')) continue
      range.selectNodeContents(n)
      for (const r of range.getClientRects()) add(r)
    }
    for (const obj of cell.querySelectorAll('img, svg, canvas')) {
      // in-cell gap decorations may carry header/footer images: not row content
      if (obj.closest('.page-gap, .page-float-host')) continue
      add(obj.getBoundingClientRect())
    }
    if (bands.length > 0) cellBands.push(bands)
  }
  const contentBottom = cellBands.reduce(
    (max, bands) => bands.reduce((m, [, b]) => Math.max(m, b), max),
    0,
  )
  return { cuts: cellCutYs(cellBands, rowHeight), contentBottom }
}

/** Rects sharing vertical overlap collapse into one line interval. Same-line rects
 *  overlap near-fully; adjacent tight table rows merely graze (line boxes 1-2px
 *  taller than the row pitch), and chain-merging them would swallow a whole
 *  nested table into one cut-less band (fdo48718), so a merge needs substantial
 *  overlap relative to the smaller band. */
function clusterLineBands(bands: Array<[number, number]>): Array<[number, number]> {
  const sorted = [...bands].sort((a, b) => a[0] - b[0])
  const lines: Array<[number, number]> = []
  for (const [top, bottom] of sorted) {
    const last = lines[lines.length - 1]
    const overlap = last ? last[1] - top : 0
    const minH = last ? Math.min(last[1] - last[0], bottom - top) : 0
    if (last && overlap > 1 && overlap > 0.4 * minH) last[1] = Math.max(last[1], bottom)
    else lines.push([top, bottom])
  }
  return lines
}

/** Pure core of rowCutYs (testable without DOM): per-cell rect bands → safe cut ys.
 *  Candidates are midpoints between a cell's consecutive lines (a zero gap still
 *  counts); a candidate falling inside any cell's line box is unsafe (0.5px
 *  tolerance for sub-pixel jitter). */
export function cellCutYs(cellBands: Array<Array<[number, number]>>, rowHeight: number): number[] {
  const cellLines = cellBands.map(clusterLineBands)
  const candidates: number[] = []
  for (const lines of cellLines) {
    for (let i = 0; i + 1 < lines.length; i++) {
      candidates.push((lines[i][1] + lines[i + 1][0]) / 2)
    }
  }
  candidates.sort((a, b) => a - b)
  const cuts: number[] = []
  for (const y of candidates) {
    if (y <= 2 || y >= rowHeight - 2) continue
    // 2px tolerance: grazing line boxes of tight table rows overlap their row
    // boundary by ~1px, and the between-rows midpoint must stay a legal cut
    if (cellLines.some((lines) => lines.some(([t, b]) => y > t + 2 && y < b - 2))) continue
    if (cuts.length > 0 && y - cuts[cuts.length - 1] < 1) continue
    cuts.push(y)
  }
  return cuts
}

/** Total height of in-block inline gaps (mid-paragraph page-break decorations) (screen px) */
function innerGapHeight(el: HTMLElement): number {
  let sum = 0
  for (const g of el.querySelectorAll('.page-gap-inline')) sum += g.getBoundingClientRect().height
  return sum
}

/**
 * In-block text lines (first rect of each line): offset is the virtual in-block Y
 * after subtracting inline gaps; left/top are screen coordinates; node is the text
 * node owning the line's first rect (DOM anchor for viewport-independent positioning),
 * or an in-flow inline image element when the line holds no text (picture-only lines).
 * Text inside gaps (e.g. footnotes) doesn't count as lines.
 */
type DomLineRect = { offset: number; left: number; top: number; node: Text | Element }
export type DomLineRectsFn = (el: HTMLElement, zoomFactor: number) => DomLineRect[]

/**
 * Per-pass memo for domLineRects: one remeasure can query hundreds of cut anchors
 * against the same block, and each query re-walks every text rect (forced layout
 * reads). Scope the cache to a single pass — DOM/scroll are stable within it.
 */
export function createLineRectsCache(): DomLineRectsFn {
  const memo = new Map<HTMLElement, DomLineRect[]>()
  return (el, zoomFactor) => {
    let lines = memo.get(el)
    if (!lines) {
      lines = domLineRects(el, zoomFactor)
      memo.set(el, lines)
    }
    return lines
  }
}

/** In normal flow inside el (no floated/absolutely-positioned ancestor): only such
 *  content forms text lines — overlays and wrap-floats don't consume flow height. */
function inFlowWithin(node: Element, el: HTMLElement): boolean {
  for (let e: Element | null = node; e && e !== el; e = e.parentElement) {
    const cs = getComputedStyle(e)
    // jsdom leaves unset properties '' — treat as in flow
    if ((cs.float && cs.float !== 'none') || cs.position === 'absolute' || cs.position === 'fixed')
      return false
  }
  return true
}

function domLineRects(el: HTMLElement, zoomFactor: number): DomLineRect[] {
  const gaps = Array.from(el.querySelectorAll('.page-gap-inline')).map((g) =>
    g.getBoundingClientRect(),
  )
  const gapAbove = (top: number) => gaps.reduce((s, g) => (g.top <= top ? s + g.height : s), 0)
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT)
  const range = document.createRange()
  const rects: Array<{ r: DOMRect; node: Text | Element }> = []
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    if (n.parentElement?.closest('.page-gap, .page-float-host')) continue
    range.selectNodeContents(n)
    for (const r of range.getClientRects()) {
      if (r.height > 0 && r.width > 0) rects.push({ r, node: n as Text })
    }
  }
  // in-flow inline pictures form lines too (a picture-only paragraph has no text
  // rect at all, which used to leave over-page image stacks without break points)
  for (const im of Array.from(el.querySelectorAll('img'))) {
    if (im.closest('.page-gap, .page-float-host')) continue
    if (!inFlowWithin(im, el)) continue
    const r = im.getBoundingClientRect()
    if (r.height > 0 && r.width > 0) rects.push({ r, node: im })
  }
  rects.sort((a, b) => a.r.top - b.r.top)
  const elTop = el.getBoundingClientRect().top
  const lines: DomLineRect[] = []
  let lineBottom = -Infinity
  for (const { r, node } of rects) {
    if (r.top >= lineBottom - 1) {
      lines.push({
        offset: (r.top - elTop - gapAbove(r.top)) / zoomFactor,
        left: r.left,
        top: r.top,
        node,
      })
      lineBottom = r.bottom
    } else {
      lineBottom = Math.max(lineBottom, r.bottom)
      const last = lines[lines.length - 1]
      if (last) {
        if (r.left < last.left) last.left = r.left
        // text anchors the line whenever it has any (image rects only stand in
        // on text-less lines; char anchors keep RTL/offset resolution exact)
        if (last.node instanceof Element && !(node instanceof Element)) {
          last.node = node
          last.top = r.top
        }
      }
    }
  }
  return lines
}

function domLineBoundaries(el: HTMLElement, zoomFactor: number): number[] {
  return lineBreakBoundaries(domLineRects(el, zoomFactor).map((ln) => ln.offset))
}

/**
 * Convert DOM text-rect tops into safe line-break boundaries.
 *
 * The first rect is the glyph box inside the first line box, so its top can be
 * a few pixels below the block top. Treating it as a boundary creates a phantom
 * first line and lets pagination clip through glyphs. Only subsequent line
 * starts are valid page-break positions.
 */
export function lineBreakBoundaries(lineOffsets: number[]): number[] {
  return lineOffsets.slice(1).filter((off) => off > 0.5)
}

/** DOM anchor of a line start: the line's first text node + character offset within it
 *  (feed to view.posAtDOM), or the line's inline image element on text-less lines. */
export interface LineAnchor {
  node: Text | Element
  charOffset: number
}

/** Element an anchor hangs off (the element itself, or the text node's parent). */
export function anchorElement(a: LineAnchor): Element | null {
  return a.node instanceof Element ? a.node : a.node.parentElement
}

/**
 * Character offset within a text node where the line whose top is lineTop begins.
 * Uses per-character Range rects (layout data, not viewport hit-testing), so it works
 * for lines scrolled outside the viewport — posAtCoords/caretRangeFromPoint do not:
 * off-screen coordinates resolve to degenerate document positions, which used to drop
 * in-table cut markers before the table's first row where they inflate the canvas
 * table by an anonymous-row line-height and skew all pagination measurement below.
 */
function lineStartCharOffset(node: Text, lineTop: number): number {
  const len = node.length
  if (len === 0) return 0
  const range = document.createRange()
  const topAt = (i: number): number => {
    range.setStart(node, i)
    range.setEnd(node, i + 1)
    for (const r of range.getClientRects()) if (r.height > 0) return r.top
    // collapsed characters (e.g. wrap-point whitespace) have no rect: treat as belonging to an earlier line
    return -Infinity
  }
  // first character at/below the line top (character tops are non-decreasing in flowing text)
  let lo = 0
  let hi = len - 1
  let ans = 0
  while (lo <= hi) {
    const mid = (lo + hi) >> 1
    if (topAt(mid) >= lineTop - 1) {
      ans = mid
      hi = mid - 1
    } else {
      lo = mid + 1
    }
  }
  return ans
}

const toAnchor = (ln: { node: Text | Element; top: number }): LineAnchor =>
  ln.node instanceof Element
    ? { node: ln.node, charOffset: 0 }
    : { node: ln.node, charOffset: lineStartCharOffset(ln.node, ln.top) }

/**
 * DOM anchor of the line start matching an in-block virtual Y (offsetInBlock)
 * (used to position mid-paragraph page-break decorations).
 * Returns null when no matching line is found (non-text block / hard pixel cut point).
 */
export function lineStartAnchor(
  el: HTMLElement,
  offsetInBlock: number,
  zoomFactor: number,
  rectsOf: DomLineRectsFn = domLineRects,
): LineAnchor | null {
  for (const ln of rectsOf(el, zoomFactor)) {
    if (Math.abs(ln.offset - offsetInBlock) < 1.5) return toAnchor(ln)
  }
  return null
}

/** DOM anchor of the first line at or after (≥) a given in-block Y: used by in-row cut points (cuts in inter-line gaps) to locate the next page's first line */
export function nextLineAnchor(
  el: HTMLElement,
  offsetInBlock: number,
  zoomFactor: number,
  rectsOf: DomLineRectsFn = domLineRects,
): LineAnchor | null {
  for (const ln of rectsOf(el, zoomFactor)) {
    if (ln.offset >= offsetInBlock - 1.5) return toAnchor(ln)
  }
  return null
}

/** Screen top of a cut anchor's line (the char rect at the anchor, else its parent box) */
function anchorLineTop(a: LineAnchor): number | null {
  if (a.node instanceof Element) return a.node.getBoundingClientRect().top
  if (a.node.length > 0) {
    const range = document.createRange()
    range.setStart(a.node, Math.min(a.charOffset, a.node.length - 1))
    range.setEnd(a.node, Math.min(a.charOffset + 1, a.node.length))
    // jsdom has no Range.getClientRects: fall through to the parent box
    for (const r of range.getClientRects?.() ?? []) if (r.height > 0) return r.top
  }
  return a.node.parentElement?.getBoundingClientRect().top ?? null
}

/** Bottom (screen px) of a cell's content boxes (direct block children, pagination
 *  widgets excluded); -Infinity when the cell has no measurable content.
 *  Text-less blocks holding only spacer-gif struts (≤2px in one dimension, the
 *  HTML-era invisible layout filler) don't count as content. */
function cellContentBottom(cell: Element): number {
  let bottom = -Infinity
  for (const child of Array.from(cell.children)) {
    if (
      child.classList.contains('page-gap') ||
      child.classList.contains('page-gap-cut') ||
      child.classList.contains('page-float-host')
    )
      continue
    if ((child.textContent ?? '').trim() === '' && !child.querySelector('table, svg')) {
      const imgs = Array.from(child.querySelectorAll('img'))
      const isStrut = (im: Element) => {
        const r = im.getBoundingClientRect()
        return r.width <= 2.5 || r.height <= 2.5
      }
      // img-less empty blocks are NOT skipped: they still take real height
      // (an empty every() would be vacuously true) — measure them below
      if (imgs.length > 0 && imgs.every(isStrut)) continue
    }
    const r = child.getBoundingClientRect()
    if (r.height > 0 || r.width > 0) bottom = Math.max(bottom, r.bottom)
  }
  return bottom
}

/** In-row cut decoration policy: a single-cell row can host a real inline gap band
 *  (one cell spans the whole cut) — returns that cell. A multi-cell row can too when
 *  every other cell's content ends above the cut (nothing at the band's y to
 *  misalign — HTML→docx layout tables put whole articles in one cell next to
 *  spacer-gif sliver cells); otherwise the zero-height cut marker stays (same-y
 *  bands across cells are not modeled) — returns null. */
export function singleCutCell(row: Element | null, anchor?: LineAnchor | null): Element | null {
  const cells = row
    ? Array.from(row.children).filter((c) => c.tagName === 'TD' || c.tagName === 'TH')
    : []
  if (cells.length === 1) return cells[0]
  if (cells.length === 0 || !anchor) return null
  const anchorCell = anchorElement(anchor)?.closest('td, th')
  const host = anchorCell && cells.find((c) => c === anchorCell || c.contains(anchorCell))
  if (!host) return null
  const cutTop = anchorLineTop(anchor)
  if (cutTop === null) return null
  for (const c of cells) {
    if (c !== host && cellContentBottom(c) > cutTop + 1) return null
  }
  return host
}

/**
 * Index of each non-first-page page-leading block (a page gap should be inserted before it).
 * Hard pixel-cut boundaries (inside over-page big blocks, with no matching block) are skipped.
 */
export function pageStartBlocks(blocks: BlockBox[], slices: PageSlice[]): number[] {
  const starts: number[] = []
  for (const slice of slices.slice(1)) {
    const i = blocks.findIndex((b) => Math.abs(b.top - slice.start) < 0.5)
    if (i >= 0) starts.push(i)
  }
  return starts
}
